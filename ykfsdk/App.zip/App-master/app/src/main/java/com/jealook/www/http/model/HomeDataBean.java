package com.jealook.www.http.model;

import java.util.List;

import per.goweii.rxhttp.request.base.BaseBean;

/**
 * @Description: 首页数据Bean
 * @Time:2020/4/20$
 * @Author:pk$
 */
public class HomeDataBean extends BaseBean {
    /**
     * index_ad : {"value":"","type":"","id":"","photo":"","list":{"goods_id":"","search_attr":"","active_id":"","url":"","text":"","id":""}}
     * banner : [{"value":"170","type":"1","id":"17","photo":"http://img.jealook.com/app_img/20200618/20200618183050_87111.jpg","list":{"goods_id":"170","search_attr":"7433|7434","active_id":"","url":"","text":"","id":""}},{"value":"112","type":"4","id":"18","photo":"http://img.jealook.com/app_img/20200618/20200618183035_76293.jpg","list":{"goods_id":"","search_attr":"","active_id":"","url":"","text":"112","id":""}},{"value":"","type":"4","id":"19","photo":"http://img.jealook.com/app_img/20200619/20200619114443_44390.jpg","list":{"goods_id":"","search_attr":"","active_id":"","url":"","text":"","id":""}}]
     * artcle : [{"id":"1","title":"购物须知","content":"","add_time":"2019-10-30 22:58:58","info_url":"http://shop.jealook.com/v1/html/article-info?id=1"}]
     * alert_ad : {"value":"","type":"","id":"","photo":"","list":{"goods_id":"","search_attr":"","active_id":"","url":"","text":"","id":""}}
     * brand : [[{"brand_id":"25","brand_name":"Eyeddict","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093658_99419.png"},{"brand_id":"24","brand_name":"Eyecloset","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093648_53344.png"},{"brand_id":"23","brand_name":"Evercolor","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093630_32943.png"},{"brand_id":"22","brand_name":"eRouge","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093617_23685.png"},{"brand_id":"21","brand_name":"Envie","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093608_76835.png"},{"brand_id":"20","brand_name":"Dorb","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093559_23915.png"},{"brand_id":"19","brand_name":"Bijou","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093547_76195.png"},{"brand_id":"17","brand_name":"Artiral","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093230_79345.png"},{"brand_id":"8","brand_name":"revia","brand_logo":"http://img.jealook.com/app_img/20200521/20200521092924_98378.png"},{"brand_id":"1","brand_name":"naturali","brand_logo":"http://img.jealook.com/app_img/20200521/20200521092638_37779.png"}],[{"brand_id":"25","brand_name":"Eyeddict","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093658_99419.png"},{"brand_id":"24","brand_name":"Eyecloset","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093648_53344.png"},{"brand_id":"1","brand_name":"naturali","brand_logo":"http://img.jealook.com/app_img/20200521/20200521092638_37779.png"},{"brand_id":"8","brand_name":"revia","brand_logo":"http://img.jealook.com/app_img/20200521/20200521092924_98378.png"},{"brand_id":"17","brand_name":"Artiral","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093230_79345.png"},{"brand_id":"19","brand_name":"Bijou","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093547_76195.png"},{"brand_id":"20","brand_name":"Dorb","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093559_23915.png"},{"brand_id":"21","brand_name":"Envie","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093608_76835.png"},{"brand_id":"22","brand_name":"eRouge","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093617_23685.png"},{"brand_id":"23","brand_name":"Evercolor","brand_logo":"http://img.jealook.com/app_img/20200521/20200521093630_32943.png"}]]
     * brand_img : http://img.jealook.com/app_img/20200630/20200630173657_97842.png
     * discount : [{"goods_id":"42","sort_order":"100","is_promote":1,"goods_name":"Luna日抛型 Almond 10枚","virtual_sales":"0","suppliers_id":"2","preferential_price":"65.00","product_price":"85.00","product_id":"4509","search_attr":"1195|1196","color_id":"1195","promote_start_date":"1597128561","promote_end_date":"1597680000","goods_thumb":"http://img.jealook.com/backend/20200401/1585734479_3386.png","surplus_time":542798},{"goods_id":"42","sort_order":"100","is_promote":1,"goods_name":"Luna日抛型 Cacao 10枚","virtual_sales":"0","suppliers_id":"2","preferential_price":"65.00","product_price":"85.00","product_id":"4533","search_attr":"1196|1210","color_id":"1210","promote_start_date":"1597128561","promote_end_date":"1597680000","goods_thumb":"http://img.jealook.com/backend/20200401/1585734480_7482.png","surplus_time":542798},{"goods_id":"42","sort_order":"100","is_promote":1,"goods_name":"Luna日抛型 Aqua 10枚","virtual_sales":"0","suppliers_id":"2","preferential_price":"65.00","product_price":"85.00","product_id":"4581","search_attr":"1196|1202","color_id":"1202","promote_start_date":"1597128561","promote_end_date":"1597680000","goods_thumb":"http://img.jealook.com/backend/20200401/1585734480_5905.png","surplus_time":542798}]
     * discount_img : http://img.jealook.com/app_img/20200630/20200630173800_36486.png
     * shop : [{"id":297,"image":"http://img.jealook.com/app_img/20200630/20200630173716_95162.png","title":"日抛","data":[{"product_price":"108.00","search_attr":"564|588","preferential_price":"88.00","color_id":"588","goods_id":"20","goods_name":"Evercolor日抛型 Aqua beige 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"Evercolor","goods_thumb":"http://img.jealook.com/backend/20200401/1585734282_2780.png"},{"product_price":"145.00","search_attr":"529|555","preferential_price":"125.00","color_id":"555","goods_id":"19","goods_name":"Evercolor日抛型 Chiff on Brown 20枚","virtual_sales":"7","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"Evercolor","goods_thumb":"http://img.jealook.com/backend/20200401/1585733834_1322.png"},{"product_price":"99.00","search_attr":"7251|7285","preferential_price":"68.00","color_id":"7285","goods_id":"166","goods_name":"Seed dreaming 以梦 日抛 Fairymist仙雾蓝 10枚","virtual_sales":"6","suppliers_id":"1","is_promote":1,"promote_start_date":"1597128129","promote_end_date":"1597680000","brand_name":"seed","goods_thumb":"http://img.jealook.com/backend/20200612/1591936019_2028.png"},{"product_price":"105.00","search_attr":"1678|1679","preferential_price":"0.00","color_id":"1678","goods_id":"58","goods_name":"PureNatural 日抛型透明隐形眼镜 透明枚 30枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Purenatural","goods_thumb":"http://img.jealook.com/backend/20200402/1585796034_8900.png"},{"product_price":"108.00","search_attr":"564|597","preferential_price":"88.00","color_id":"597","goods_id":"20","goods_name":"Evercolor日抛型 Shinny hazel 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"Evercolor","goods_thumb":"http://img.jealook.com/backend/20200401/1585734283_8655.png"},{"product_price":"88.00","search_attr":"3698|3699","preferential_price":"59.00","color_id":"3698","goods_id":"101","goods_name":"Jill stuart 吉尔斯图亚特日抛 青榄绿 10枚","virtual_sales":"0","suppliers_id":"1","is_promote":1,"promote_start_date":"1597128337","promote_end_date":"1597680000","brand_name":"Jill Stuart","goods_thumb":"http://img.jealook.com/backend/20200403/1585893062_2796.png"},{"product_price":"99.00","search_attr":"1247|1275","preferential_price":"0.00","color_id":"1275","goods_id":"44","goods_name":"Melange日抛型 Virginalash 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Melange","goods_thumb":"http://img.jealook.com/backend/20200401/1585735949_5740.png"},{"product_price":"105.00","search_attr":"363|389","preferential_price":"0.00","color_id":"389","goods_id":"14","goods_name":"Dorb日抛型 Olive 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Dorb","goods_thumb":"http://img.jealook.com/backend/20200603/1591169461_4219.png"},{"product_price":"105.00","search_attr":"3283|3310","preferential_price":"0.00","color_id":"3310","goods_id":"88","goods_name":"中国版 Naturali日抛 Charming green 10枚","virtual_sales":"0","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"naturali","goods_thumb":"http://img.jealook.com/backend/20200415/1586940085_7375.png"}]},{"id":304,"image":"http://img.jealook.com/app_img/20200630/20200630173729_70791.png","title":"双周抛","data":[{"product_price":"155.00","search_attr":"1546|1565","preferential_price":"0.00","color_id":"1565","goods_id":"54","goods_name":"Neociel双周抛型 Green 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Neocielsight","goods_thumb":"http://img.jealook.com/backend/20200402/1585808733_5866.png"},{"product_price":"145.00","search_attr":"493|505","preferential_price":"125.00","color_id":"505","goods_id":"18","goods_name":"eRouge双周抛型 Clarity Brown 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1596520243","promote_end_date":"1597128427","brand_name":"eRouge","goods_thumb":"http://img.jealook.com/backend/20200603/1591170004_5102.png"},{"product_price":"108.00","search_attr":"3666|3692","preferential_price":"0.00","color_id":"3692","goods_id":"100","goods_name":"Erouge 爱如久双周抛 璀璨金棕 6枚","virtual_sales":"2","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"eRouge","goods_thumb":"http://img.jealook.com/backend/20200618/1592460828_9034.png"},{"product_price":"135.00","search_attr":"1597|1617","preferential_price":"0.00","color_id":"1617","goods_id":"55","goods_name":"Pienage  Barbie双周抛型 Barbie only wish 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Pienage Barbie","goods_thumb":"http://img.jealook.com/backend/20200402/1585795387_7357.png"},{"product_price":"145.00","search_attr":"1169|5135","preferential_price":"0.00","color_id":"5135","goods_id":"41","goods_name":"Lumia双周抛型 Sweet Brown 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Lumia","goods_thumb":"http://img.jealook.com/backend/20200604/1591236710_7545.png"},{"product_price":"145.00","search_attr":"493|522","preferential_price":"125.00","color_id":"522","goods_id":"18","goods_name":"eRouge双周抛型 FlareBrown 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1596520243","promote_end_date":"1597128427","brand_name":"eRouge","goods_thumb":"http://img.jealook.com/backend/20200603/1591170006_1812.png"},{"product_price":"125.00","search_attr":"193|194","preferential_price":"125.00","color_id":"193","goods_id":"8","goods_name":"Artiral 双周抛型 Artiral  Black 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Artiral","goods_thumb":"http://img.jealook.com/backend/20200401/1585727098_8113.png"},{"product_price":"108.00","search_attr":"3666|3696","preferential_price":"0.00","color_id":"3696","goods_id":"100","goods_name":"Erouge 爱如久双周抛 弗朗艳棕 6枚","virtual_sales":"2","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"eRouge","goods_thumb":"http://img.jealook.com/backend/20200618/1592460828_9755.png"},{"product_price":"99.00","search_attr":"1912|1938","preferential_price":"0.00","color_id":"1938","goods_id":"67","goods_name":"Rich standard双周抛型 Relax Brown 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Richstandard","goods_thumb":"http://img.jealook.com/backend/20200402/1585798248_2263.png"}]},{"id":315,"image":"http://img.jealook.com/app_img/20200630/20200630173813_36138.png","title":"月抛","data":[{"product_price":"58.00","search_attr":"332|355","preferential_price":"0.00","color_id":"355","goods_id":"13","goods_name":"Chouchou月抛型 Milkypeach 1枚","virtual_sales":"6","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Chouchou","goods_thumb":"http://img.jealook.com/backend/20200401/1585728472_9326.png"},{"product_price":"66.00","search_attr":"1218|1230","preferential_price":"0.00","color_id":"1230","goods_id":"43","goods_name":"Luna月抛型 Aqua 1枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Luna","goods_thumb":"http://img.jealook.com/backend/20200401/1585734670_7985.png"},{"product_price":"95.00","search_attr":"1017|1018","preferential_price":"0.00","color_id":"1017","goods_id":"35","goods_name":"Lilmoon月抛型 Cream beige 1枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Lilmoon","goods_thumb":"http://img.jealook.com/backend/20200401/1585733266_7458.png"},{"product_price":"98.00","search_attr":"1798|1799","preferential_price":"0.00","color_id":"1798","goods_id":"63","goods_name":"Refrear月抛型透明隐形眼镜 Refrear 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Refrear","goods_thumb":"http://img.jealook.com/backend/20200403/1585904645_8005.png"},{"product_price":"155.00","search_attr":"391|392","preferential_price":"139.50","color_id":"391","goods_id":"15","goods_name":"Dorb月抛型 Black 3枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Dorb","goods_thumb":"http://img.jealook.com/backend/20200401/1585729119_8936.png"},{"product_price":"138.00","search_attr":"3537|3565","preferential_price":"0.00","color_id":"3565","goods_id":"96","goods_name":"Givre 绮芙丽月抛 摩登炫灰 6枚","virtual_sales":"0","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Givre","goods_thumb":"http://img.jealook.com/backend/20200604/1591234093_2225.png"},{"product_price":"188.00","search_attr":"3498|3524","preferential_price":"0.00","color_id":"3524","goods_id":"95","goods_name":"Givre 绮芙丽月抛 榛果裸棕 30枚","virtual_sales":"0","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Givre","goods_thumb":"http://img.jealook.com/backend/20200403/1585896648_2987.png"},{"product_price":"66.00","search_attr":"1218|1244","preferential_price":"0.00","color_id":"1244","goods_id":"43","goods_name":"Luna月抛型 Chai 1枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Luna","goods_thumb":"http://img.jealook.com/backend/20200401/1585734670_6583.png"},{"product_price":"138.00","search_attr":"3402|3431","preferential_price":"0.00","color_id":"3431","goods_id":"92","goods_name":"Femii 妃蜜莉月抛 傲娇褐绿 6枚","virtual_sales":"0","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Femii","goods_thumb":"http://img.jealook.com/backend/20200622/1592807542_3936.png"}]},{"id":0,"image":"http://img.jealook.com/app_img/20200630/20200630173744_68085.png","title":"透明片","data":[{"product_price":"145.00","search_attr":"2152|2153","preferential_price":"125.00","color_id":"2152","goods_id":"76","goods_name":"新加坡版强生双周抛型透明隐形眼镜 透明枚 6枚","virtual_sales":"35","suppliers_id":"2","is_promote":0,"promote_start_date":"1594656000","promote_end_date":"1595260800","brand_name":"强生ACUVUE安视优","goods_thumb":"http://img.jealook.com/backend/20200403/1585902600_5497.png"},{"product_price":"85.00","search_attr":"1771|1772","preferential_price":"0.00","color_id":"1771","goods_id":"62","goods_name":"Refrear双周抛型透明隐形眼镜 Refrear 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Refrear","goods_thumb":"http://img.jealook.com/backend/20200402/1585806442_9746.png"},{"product_price":"99.00","search_attr":"3729|3730","preferential_price":"0.00","color_id":"3729","goods_id":"102","goods_name":"Seed 幻樱日抛20片装 透明隐形眼镜 透明色 20枚","virtual_sales":"35","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"seed","goods_thumb":"http://img.jealook.com/backend/20200403/1585892922_5586.png"},{"product_price":"88.00","search_attr":"759|760","preferential_price":"87.00","color_id":"759","goods_id":"26","goods_name":"Flanmy日抛型20枚透明隐形眼镜 Flanmy Clear  20枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Rohto","goods_thumb":"http://img.jealook.com/backend/20200401/1585731842_4971.png"},{"product_price":"98.00","search_attr":"1798|1799","preferential_price":"0.00","color_id":"1798","goods_id":"63","goods_name":"Refrear月抛型透明隐形眼镜 Refrear 6枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Refrear","goods_thumb":"http://img.jealook.com/backend/20200403/1585904645_8005.png"},{"product_price":"45.00","search_attr":"5286|5287","preferential_price":"16.00","color_id":"5286","goods_id":"133","goods_name":"Alcon日抛型透明隐形眼镜 透明枚 5枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"爱尔康","goods_thumb":"http://img.jealook.com/backend/20200415/1586934654_1259.png"},{"product_price":"105.00","search_attr":"1678|1679","preferential_price":"0.00","color_id":"1678","goods_id":"58","goods_name":"PureNatural 日抛型透明隐形眼镜 透明枚 30枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Purenatural","goods_thumb":"http://img.jealook.com/backend/20200402/1585796034_8900.png"},{"product_price":"228.00","search_attr":"2077|2078","preferential_price":"199.00","color_id":"2077","goods_id":"73","goods_name":"Alcon日抛型透明隐形眼镜 透明枚 30枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"爱尔康","goods_thumb":"http://img.jealook.com/backend/20200403/1585900813_8644.png"},{"product_price":"88.00","search_attr":"1751|1752","preferential_price":"69.00","color_id":"1751","goods_id":"61","goods_name":"Refrear 38%含水日抛型透明隐形眼镜 Refrear 30枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1596520326","promote_end_date":"1597128408","brand_name":"Refrear","goods_thumb":"http://img.jealook.com/backend/20200402/1585797411_7452.png"}]}]
     */

    private IndexAdBean index_ad;
    private AlertAdBean alert_ad;
    private String brand_img;
    private String discount_img;
    private List<BannerBean> banner;
    private List<ArtcleBean> artcle;
    private List<List<BrandBean>> brand;
    private List<DiscountBean> discount;
    private List<ShopBean> shop;

    public IndexAdBean getIndex_ad() {
        return index_ad;
    }

    public void setIndex_ad(IndexAdBean index_ad) {
        this.index_ad = index_ad;
    }

    public AlertAdBean getAlert_ad() {
        return alert_ad;
    }

    public void setAlert_ad(AlertAdBean alert_ad) {
        this.alert_ad = alert_ad;
    }

    public String getBrand_img() {
        return brand_img;
    }

    public void setBrand_img(String brand_img) {
        this.brand_img = brand_img;
    }

    public String getDiscount_img() {
        return discount_img;
    }

    public void setDiscount_img(String discount_img) {
        this.discount_img = discount_img;
    }

    public List<BannerBean> getBanner() {
        return banner;
    }

    public void setBanner(List<BannerBean> banner) {
        this.banner = banner;
    }

    public List<ArtcleBean> getArtcle() {
        return artcle;
    }

    public void setArtcle(List<ArtcleBean> artcle) {
        this.artcle = artcle;
    }

    public List<List<BrandBean>> getBrand() {
        return brand;
    }

    public void setBrand(List<List<BrandBean>> brand) {
        this.brand = brand;
    }

    public List<DiscountBean> getDiscount() {
        return discount;
    }

    public void setDiscount(List<DiscountBean> discount) {
        this.discount = discount;
    }

    public List<ShopBean> getShop() {
        return shop;
    }

    public void setShop(List<ShopBean> shop) {
        this.shop = shop;
    }

    public static class IndexAdBean {
        /**
         * value :
         * type :
         * id :
         * photo :
         * list : {"goods_id":"","search_attr":"","active_id":"","url":"","text":"","id":""}
         */

        private String value;
        private String type;
        private String id;
        private String photo;
        private ListBean list;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public ListBean getList() {
            return list;
        }

        public void setList(ListBean list) {
            this.list = list;
        }

        public static class ListBean {
            /**
             * goods_id :
             * search_attr :
             * active_id :
             * url :
             * text :
             * id :
             */

            private String goods_id;
            private String search_attr;
            private String active_id;
            private String url;
            private String text;
            private String id;

            public String getGoods_id() {
                return goods_id;
            }

            public void setGoods_id(String goods_id) {
                this.goods_id = goods_id;
            }

            public String getSearch_attr() {
                return search_attr;
            }

            public void setSearch_attr(String search_attr) {
                this.search_attr = search_attr;
            }

            public String getActive_id() {
                return active_id;
            }

            public void setActive_id(String active_id) {
                this.active_id = active_id;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }
        }
    }

    public static class AlertAdBean {
        /**
         * value :
         * type :
         * id :
         * photo :
         * list : {"goods_id":"","search_attr":"","active_id":"","url":"","text":"","id":""}
         */

        private String value;
        private String type;
        private String id;
        private String photo;
        private ListBeanX list;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public ListBeanX getList() {
            return list;
        }

        public void setList(ListBeanX list) {
            this.list = list;
        }

        public static class ListBeanX {
            /**
             * goods_id :
             * search_attr :
             * active_id :
             * url :
             * text :
             * id :
             */

            private String goods_id;
            private String search_attr;
            private String active_id;
            private String url;
            private String text;
            private String id;

            public String getGoods_id() {
                return goods_id;
            }

            public void setGoods_id(String goods_id) {
                this.goods_id = goods_id;
            }

            public String getSearch_attr() {
                return search_attr;
            }

            public void setSearch_attr(String search_attr) {
                this.search_attr = search_attr;
            }

            public String getActive_id() {
                return active_id;
            }

            public void setActive_id(String active_id) {
                this.active_id = active_id;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }
        }
    }

    public static class BannerBean {
        /**
         * value : 170
         * type : 1
         * id : 17
         * photo : http://img.jealook.com/app_img/20200618/20200618183050_87111.jpg
         * list : {"goods_id":"170","search_attr":"7433|7434","active_id":"","url":"","text":"","id":""}
         */

        private String value;
        private String type;
        private String id;
        private String photo;
        private ListBeanXX list;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public ListBeanXX getList() {
            return list;
        }

        public void setList(ListBeanXX list) {
            this.list = list;
        }

        public static class ListBeanXX {
            /**
             * goods_id : 170
             * search_attr : 7433|7434
             * active_id :
             * url :
             * text :
             * id :
             */

            private String goods_id;
            private String search_attr;
            private String active_id;
            private String url;
            private String text;
            private String id;

            public String getGoods_id() {
                return goods_id;
            }

            public void setGoods_id(String goods_id) {
                this.goods_id = goods_id;
            }

            public String getSearch_attr() {
                return search_attr;
            }

            public void setSearch_attr(String search_attr) {
                this.search_attr = search_attr;
            }

            public String getActive_id() {
                return active_id;
            }

            public void setActive_id(String active_id) {
                this.active_id = active_id;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }
        }
    }

    public static class ArtcleBean {
        /**
         * id : 1
         * title : 购物须知
         * content :
         * add_time : 2019-10-30 22:58:58
         * info_url : http://shop.jealook.com/v1/html/article-info?id=1
         */

        private String id;
        private String title;
        private String content;
        private String add_time;
        private String info_url;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getAdd_time() {
            return add_time;
        }

        public void setAdd_time(String add_time) {
            this.add_time = add_time;
        }

        public String getInfo_url() {
            return info_url;
        }

        public void setInfo_url(String info_url) {
            this.info_url = info_url;
        }
    }

    public static class BrandBean {
        /**
         * brand_id : 25
         * brand_name : Eyeddict
         * brand_logo : http://img.jealook.com/app_img/20200521/20200521093658_99419.png
         */

        private String brand_id;
        private String brand_name;
        private String brand_logo;

        public String getBrand_id() {
            return brand_id;
        }

        public void setBrand_id(String brand_id) {
            this.brand_id = brand_id;
        }

        public String getBrand_name() {
            return brand_name;
        }

        public void setBrand_name(String brand_name) {
            this.brand_name = brand_name;
        }

        public String getBrand_logo() {
            return brand_logo;
        }

        public void setBrand_logo(String brand_logo) {
            this.brand_logo = brand_logo;
        }
    }

    public static class DiscountBean {
        /**
         * goods_id : 42
         * sort_order : 100
         * is_promote : 1
         * goods_name : Luna日抛型 Almond 10枚
         * virtual_sales : 0
         * suppliers_id : 2
         * preferential_price : 65.00
         * product_price : 85.00
         * product_id : 4509
         * search_attr : 1195|1196
         * color_id : 1195
         * promote_start_date : 1597128561
         * promote_end_date : 1597680000
         * goods_thumb : http://img.jealook.com/backend/20200401/1585734479_3386.png
         * surplus_time : 542798
         */

        private String goods_id;
        private String sort_order;
        private int is_promote;
        private String goods_name;
        private String virtual_sales;
        private String suppliers_id;
        private String preferential_price;
        private String product_price;
        private String product_id;
        private String search_attr;
        private String color_id;
        private String promote_start_date;
        private String promote_end_date;
        private String goods_thumb;
        private int surplus_time;

        public String getGoods_id() {
            return goods_id;
        }

        public void setGoods_id(String goods_id) {
            this.goods_id = goods_id;
        }

        public String getSort_order() {
            return sort_order;
        }

        public void setSort_order(String sort_order) {
            this.sort_order = sort_order;
        }

        public int getIs_promote() {
            return is_promote;
        }

        public void setIs_promote(int is_promote) {
            this.is_promote = is_promote;
        }

        public String getGoods_name() {
            return goods_name;
        }

        public void setGoods_name(String goods_name) {
            this.goods_name = goods_name;
        }

        public String getVirtual_sales() {
            return virtual_sales;
        }

        public void setVirtual_sales(String virtual_sales) {
            this.virtual_sales = virtual_sales;
        }

        public String getSuppliers_id() {
            return suppliers_id;
        }

        public void setSuppliers_id(String suppliers_id) {
            this.suppliers_id = suppliers_id;
        }

        public String getPreferential_price() {
            return preferential_price;
        }

        public void setPreferential_price(String preferential_price) {
            this.preferential_price = preferential_price;
        }

        public String getProduct_price() {
            return product_price;
        }

        public void setProduct_price(String product_price) {
            this.product_price = product_price;
        }

        public String getProduct_id() {
            return product_id;
        }

        public void setProduct_id(String product_id) {
            this.product_id = product_id;
        }

        public String getSearch_attr() {
            return search_attr;
        }

        public void setSearch_attr(String search_attr) {
            this.search_attr = search_attr;
        }

        public String getColor_id() {
            return color_id;
        }

        public void setColor_id(String color_id) {
            this.color_id = color_id;
        }

        public String getPromote_start_date() {
            return promote_start_date;
        }

        public void setPromote_start_date(String promote_start_date) {
            this.promote_start_date = promote_start_date;
        }

        public String getPromote_end_date() {
            return promote_end_date;
        }

        public void setPromote_end_date(String promote_end_date) {
            this.promote_end_date = promote_end_date;
        }

        public String getGoods_thumb() {
            return goods_thumb;
        }

        public void setGoods_thumb(String goods_thumb) {
            this.goods_thumb = goods_thumb;
        }

        public int getSurplus_time() {
            return surplus_time;
        }

        public void setSurplus_time(int surplus_time) {
            this.surplus_time = surplus_time;
        }
    }

    public static class ShopBean {
        /**
         * id : 297
         * image : http://img.jealook.com/app_img/20200630/20200630173716_95162.png
         * title : 日抛
         * data : [{"product_price":"108.00","search_attr":"564|588","preferential_price":"88.00","color_id":"588","goods_id":"20","goods_name":"Evercolor日抛型 Aqua beige 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"Evercolor","goods_thumb":"http://img.jealook.com/backend/20200401/1585734282_2780.png"},{"product_price":"145.00","search_attr":"529|555","preferential_price":"125.00","color_id":"555","goods_id":"19","goods_name":"Evercolor日抛型 Chiff on Brown 20枚","virtual_sales":"7","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"Evercolor","goods_thumb":"http://img.jealook.com/backend/20200401/1585733834_1322.png"},{"product_price":"99.00","search_attr":"7251|7285","preferential_price":"68.00","color_id":"7285","goods_id":"166","goods_name":"Seed dreaming 以梦 日抛 Fairymist仙雾蓝 10枚","virtual_sales":"6","suppliers_id":"1","is_promote":1,"promote_start_date":"1597128129","promote_end_date":"1597680000","brand_name":"seed","goods_thumb":"http://img.jealook.com/backend/20200612/1591936019_2028.png"},{"product_price":"105.00","search_attr":"1678|1679","preferential_price":"0.00","color_id":"1678","goods_id":"58","goods_name":"PureNatural 日抛型透明隐形眼镜 透明枚 30枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Purenatural","goods_thumb":"http://img.jealook.com/backend/20200402/1585796034_8900.png"},{"product_price":"108.00","search_attr":"564|597","preferential_price":"88.00","color_id":"597","goods_id":"20","goods_name":"Evercolor日抛型 Shinny hazel 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","brand_name":"Evercolor","goods_thumb":"http://img.jealook.com/backend/20200401/1585734283_8655.png"},{"product_price":"88.00","search_attr":"3698|3699","preferential_price":"59.00","color_id":"3698","goods_id":"101","goods_name":"Jill stuart 吉尔斯图亚特日抛 青榄绿 10枚","virtual_sales":"0","suppliers_id":"1","is_promote":1,"promote_start_date":"1597128337","promote_end_date":"1597680000","brand_name":"Jill Stuart","goods_thumb":"http://img.jealook.com/backend/20200403/1585893062_2796.png"},{"product_price":"99.00","search_attr":"1247|1275","preferential_price":"0.00","color_id":"1275","goods_id":"44","goods_name":"Melange日抛型 Virginalash 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Melange","goods_thumb":"http://img.jealook.com/backend/20200401/1585735949_5740.png"},{"product_price":"105.00","search_attr":"363|389","preferential_price":"0.00","color_id":"389","goods_id":"14","goods_name":"Dorb日抛型 Olive 10枚","virtual_sales":"0","suppliers_id":"2","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"Dorb","goods_thumb":"http://img.jealook.com/backend/20200603/1591169461_4219.png"},{"product_price":"105.00","search_attr":"3283|3310","preferential_price":"0.00","color_id":"3310","goods_id":"88","goods_name":"中国版 Naturali日抛 Charming green 10枚","virtual_sales":"0","suppliers_id":"1","is_promote":0,"promote_start_date":"0","promote_end_date":"0","brand_name":"naturali","goods_thumb":"http://img.jealook.com/backend/20200415/1586940085_7375.png"}]
         */

        private int id;
        private String image;
        private String title;
        private List<DataBean> data;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<DataBean> getData() {
            return data;
        }

        public void setData(List<DataBean> data) {
            this.data = data;
        }

        public static class DataBean {
            /**
             * product_price : 108.00
             * search_attr : 564|588
             * preferential_price : 88.00
             * color_id : 588
             * goods_id : 20
             * goods_name : Evercolor日抛型 Aqua beige 10枚
             * virtual_sales : 0
             * suppliers_id : 2
             * is_promote : 0
             * promote_start_date : 1594051200
             * promote_end_date : 1594656000
             * brand_name : Evercolor
             * goods_thumb : http://img.jealook.com/backend/20200401/1585734282_2780.png
             */

            private String product_price;
            private String search_attr;
            private String preferential_price;
            private String color_id;
            private String goods_id;
            private String goods_name;
            private String virtual_sales;
            private String suppliers_id;
            private int is_promote;
            private String promote_start_date;
            private String promote_end_date;
            private String brand_name;
            private String goods_thumb;

            public String getProduct_price() {
                return product_price;
            }

            public void setProduct_price(String product_price) {
                this.product_price = product_price;
            }

            public String getSearch_attr() {
                return search_attr;
            }

            public void setSearch_attr(String search_attr) {
                this.search_attr = search_attr;
            }

            public String getPreferential_price() {
                return preferential_price;
            }

            public void setPreferential_price(String preferential_price) {
                this.preferential_price = preferential_price;
            }

            public String getColor_id() {
                return color_id;
            }

            public void setColor_id(String color_id) {
                this.color_id = color_id;
            }

            public String getGoods_id() {
                return goods_id;
            }

            public void setGoods_id(String goods_id) {
                this.goods_id = goods_id;
            }

            public String getGoods_name() {
                return goods_name;
            }

            public void setGoods_name(String goods_name) {
                this.goods_name = goods_name;
            }

            public String getVirtual_sales() {
                return virtual_sales;
            }

            public void setVirtual_sales(String virtual_sales) {
                this.virtual_sales = virtual_sales;
            }

            public String getSuppliers_id() {
                return suppliers_id;
            }

            public void setSuppliers_id(String suppliers_id) {
                this.suppliers_id = suppliers_id;
            }

            public int getIs_promote() {
                return is_promote;
            }

            public void setIs_promote(int is_promote) {
                this.is_promote = is_promote;
            }

            public String getPromote_start_date() {
                return promote_start_date;
            }

            public void setPromote_start_date(String promote_start_date) {
                this.promote_start_date = promote_start_date;
            }

            public String getPromote_end_date() {
                return promote_end_date;
            }

            public void setPromote_end_date(String promote_end_date) {
                this.promote_end_date = promote_end_date;
            }

            public String getBrand_name() {
                return brand_name;
            }

            public void setBrand_name(String brand_name) {
                this.brand_name = brand_name;
            }

            public String getGoods_thumb() {
                return goods_thumb;
            }

            public void setGoods_thumb(String goods_thumb) {
                this.goods_thumb = goods_thumb;
            }
        }
    }
}
