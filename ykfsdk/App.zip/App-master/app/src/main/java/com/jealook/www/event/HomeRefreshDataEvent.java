package com.jealook.www.event;

import com.dm.lib.core.eventbas.BaseEvent;

/**
 * @Description:
 * @Time:2020/8/11$
 * @Author:pk$
 */
public class HomeRefreshDataEvent extends BaseEvent {
    private Boolean refresh;

    public HomeRefreshDataEvent(Boolean refreshs) {
        refresh = refreshs;
    }

    public Boolean getRefresh() {
        return refresh;
    }
}
