package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.StatusBarUtils;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.adapter.SearchAdapter;
import com.jealook.www.surface.adapter.SearchHotAdapter;
import com.jealook.www.surface.bean.SearchListBean;
import com.jealook.www.surface.mvp.presenter.SearchPresenter;
import com.jealook.www.surface.mvp.view.SearchView;
import com.jealook.www.utils.CacheActivity;
import com.jealook.www.utils.SearchHistory;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @Description:搜索页面
 * @Time:2020/4/14 9:45
 * @Author:pk
 */
public class SearchActivity extends BaseActivity<SearchPresenter> implements SearchView {
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.recyclerView1)
    RecyclerView recyclerView1;
    @BindView(R.id.et_search)
    EditText etSearch;
    @BindView(R.id.tv_cancel)
    TextView tvCancel;
    @BindView(R.id.iv_deldet)
    ImageView ivDeldet;
    SearchAdapter searchAdapter1;
    SearchHotAdapter searchAdapter2;
    List<SearchListBean.UserListBean> adapterList_1;
    List<SearchListBean.HotListBean> adapterList_2;
    @BindView(R.id.clear_search_text)
    ImageView clearSearchText;

    public static void startSelf(Context context) {
        Intent intent = new Intent(context, SearchActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_search;
    }

    @Override
    protected SearchPresenter initPresenter() {
        return new SearchPresenter();
    }

    @Override
    protected void initView() {
        CacheActivity.addActivity(SearchActivity.this);
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        searchAdapter1 = new SearchAdapter();//历史搜索
        FlexboxLayoutManager flexboxLayoutManager1 = new FlexboxLayoutManager(getContext());
        recyclerView.setLayoutManager(flexboxLayoutManager1);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(searchAdapter1);
        searchAdapter1.setData(SearchHistory.getSearchHistory());

        searchAdapter1.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                SearchHistory.saveSearchHistory(searchAdapter1.getData().get(position));//保存数据
                SearchListActivity.startSelf(getActivity(), searchAdapter1.getData().get(position));
            }
        });


        searchAdapter2 = new SearchHotAdapter();//热门搜索
        FlexboxLayoutManager flexboxLayoutManager2 = new FlexboxLayoutManager(getContext());
        recyclerView1.setLayoutManager(flexboxLayoutManager2);
        recyclerView1.setHasFixedSize(true);
        recyclerView1.setNestedScrollingEnabled(false);
        recyclerView1.setHasFixedSize(true);
        recyclerView1.setAdapter(searchAdapter2);
        searchAdapter2.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                SearchHistory.saveSearchHistory(adapterList_2.get(position).getKeyword());//保存数据
                SearchListActivity.startSelf(getActivity(), adapterList_2.get(position).getKeyword());
            }
        });

        //搜索按钮
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(etSearch.getText().toString().trim())) {
                    SearchHistory.saveSearchHistory(etSearch.getText().toString().trim());//保存数据
                    SearchListActivity.startSelf(getActivity(), etSearch.getText().toString().trim());
                } else {
                    Toast.makeText(SearchActivity.this, "请先输入先搜索的内容", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //清除搜索框内容
        clearSearchText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etSearch.setText("");
            }
        });


    }

    @Override
    protected void loadData() {
        presenter.getSearchData();//下载首页数据

    }

    @Override
    protected void onResume() {
        super.onResume();
        searchAdapter1.setData(SearchHistory.getSearchHistory());
    }

    /**
     * 列表数据下载成功
     *
     * @param code
     * @param data
     */
    @Override
    public void getSearchDataSuccess(int code, SearchListBean data) {


        adapterList_2 = data.getHot_list();
        searchAdapter2.setData(data.getHot_list());

//        adapterList_1 = data.getUser_list();
//        searchAdapter1.setData(data.getUser_list());

    }

    /**
     * 列表数据下载失败
     *
     * @param code
     * @param
     */
    @Override
    public void getSearchDataFail(int code, String msg) {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }
}
