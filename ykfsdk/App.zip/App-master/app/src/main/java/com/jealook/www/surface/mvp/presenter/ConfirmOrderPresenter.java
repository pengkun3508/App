package com.jealook.www.surface.mvp.presenter;

import android.util.Log;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.http.RequestBackListener;
import com.jealook.www.http.model.AllOrderListBean;
import com.jealook.www.http.model.CollectionListBean;
import com.jealook.www.http.model.CouponListBean;
import com.jealook.www.http.model.ShopCartListBean;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.bean.ClassifyBean;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.mvp.model.MainRequest;
import com.jealook.www.surface.mvp.view.ClassFragmentView;
import com.jealook.www.surface.mvp.view.ConfirmOrderView;

import java.util.List;

public class ConfirmOrderPresenter  extends MvpPresenter<ConfirmOrderView> {
    public void getConfirmOrderData(String recId, String goods_id, String product_id, String num) {

        addToRxLife(MainRequest.getConfirmOrderData(recId,goods_id,product_id,num,new RequestBackListener<ConfirmOrderBean>() {
            @Override
            public void onStart() {
                showLoading();
            }

            @Override
            public void onSuccess(int code, ConfirmOrderBean data) {
                if (isAttachView())
                    getBaseView().getConfirmOrderSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getConfirmOrderFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onFinish() {
                dismissLoading();
            }
        }));

    }

    public void getConfirmOrderData1(String recId, String goods_id, String product_id, String num, String mark) {
        addToRxLife(MainRequest.getConfirmOrderData1(recId,goods_id,product_id,num,mark,new RequestBackListener<ConfirmOrderBean>() {
            @Override
            public void onStart() {
                showLoading();
            }

            @Override
            public void onSuccess(int code, ConfirmOrderBean data) {
                if (isAttachView())
                    getBaseView().getConfirmOrderSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getConfirmOrderFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onFinish() {
                dismissLoading();
            }
        }));

    }
}