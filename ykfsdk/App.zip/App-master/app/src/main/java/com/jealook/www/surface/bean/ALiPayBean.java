package com.jealook.www.surface.bean;

/**
 * @Description:
 * @Time:2020/5/15$
 * @Author:pk$
 */
public class ALiPayBean {
    /**
     * zfb_info : alipay_sdk=alipay-sdk-php-20161101&app_id=2021001156622216&biz_content=%7B%22body%22%3A%22%5Cu5546%5Cu54c1%22%2C%22subject%22%3A%22%5Cu8ba2%5Cu5355%22%2C%22out_trade_no%22%3A%22202005151200045656988427%22%2C%22total_amount%22%3A0.01%2C%22product_code%22%3A%22QUICK_MSECURITY_PAY%22%7D&charset=UTF-8&format=json&method=alipay.trade.app.pay&notify_url=http%3A%2F%2Fshop.jealook.com%2Fv1%2Fnotify%2Fali-notify&sign_type=RSA2&timestamp=2020-05-15+12%3A00%3A05&version=1.0&sign=X6oKS89pm7JU%2FXXYoifQKWHMruPoKDw36DtLwAU%2FFJNQwV2t0DTnK1Ze3bbKWKNNgDYqAcG9Bhc840O29scaZHJ5mK1gepGjreuUrBsDVeRyPCByEKMGvdXmjcil%2BnEEQDQ%2FnEeSjWByPolv5H91iR0UhcczL7evjGIdW8dFq9X7SyR7muaEf2QQPTDUJI7MWLa6YQm51n3rmTqHueeQTKoUwglSFnC7dj5b50todtHu76GkpJrpjZjbh9LWr0ImbIgwRgPHwcc7rU4dvr63aH6gAmAOgIcX%2BbrCeT4O3x7jhSsKdp1xfyjqNMwiZeKoc9fiabdDmdiMQ8fzMD0eMw%3D%3D
     */

    private String zfb_info;

    public String getZfb_info() {
        return zfb_info;
    }

    public void setZfb_info(String zfb_info) {
        this.zfb_info = zfb_info;
    }
}
