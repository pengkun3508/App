package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.NoticeView;

/**
 * @Description:
 * @Time:2020/4/14$
 * @Author:pk$
 */
public class NoticePresenter extends MvpPresenter<NoticeView> {
}
