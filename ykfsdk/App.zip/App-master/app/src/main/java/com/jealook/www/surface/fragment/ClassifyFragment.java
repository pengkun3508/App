package com.jealook.www.surface.fragment;


import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.jealook.www.R;
import com.jealook.www.base.BaseFragment;
import com.jealook.www.event.ScreenIdListEvent;
import com.jealook.www.event.ShopCarJudgeEvent;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.activity.MoveAbooutActivity_1;
import com.jealook.www.surface.adapter.ClassifyList_Adapter;
import com.jealook.www.surface.bean.ClassifyBean;
import com.jealook.www.surface.bean.ClassifyTypeBean;
import com.jealook.www.surface.dialog.ScreenDialog;
import com.jealook.www.surface.mvp.presenter.ClassifyFragmentPresenter;
import com.jealook.www.surface.mvp.view.ClassifyFragmentView;
import com.jealook.www.utils.DensityUtils;
import com.jealook.www.utils.SmartRefreshHelper;
import com.jealook.www.widgat.SpaceItemDecoration;
import com.jealook.www.widgat.SpacesItemDecoration;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;


/**
 * @Description:分类
 * @Time:2020/4/1 10:28
 * @Author:pk
 */
public class ClassifyFragment extends BaseFragment<ClassifyFragmentPresenter> implements ClassifyFragmentView {
    @BindView(R.id.classify_serachview_edt)
    EditText classifySerachviewEdt;//搜索
    @BindView(R.id.classify_qita)
    TextView classifyQita;//其它
    @BindView(R.id.imageButton1)
    RadioButton imageButton1;//全部
    @BindView(R.id.imageButton2)
    RadioButton imageButton2;//自营
    @BindView(R.id.imageButton3)
    RadioButton imageButton3;//海淘
    @BindView(R.id.radioGroup)
    RadioGroup radioGroup;//

    @BindView(R.id.all_view)
    View allView;//
    @BindView(R.id.ziying_view)
    View ziyingView;//
    @BindView(R.id.hiatao_view)
    View hiataoView;//

    @BindView(R.id.classify_zonghe)
    LinearLayout classifyZonghe;//综合
    @BindView(R.id.classify_xiaoliang)
    LinearLayout classifyXiaoliang;//销量
    @BindView(R.id.classify_xinpin)
    LinearLayout classifyXinpin;//新品
    @BindView(R.id.classify_jiage)
    LinearLayout classifyJiage;//价格
    @BindView(R.id.classify_shaixuan)
    LinearLayout classifyShaixuan;//筛选
    @BindView(R.id.classify_recycler)
    RecyclerView classifyRecycler;//List
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;

    @BindView(R.id.zonghe_text)
    TextView zonghe_text;//综合
    @BindView(R.id.xiaoliang_text)
    TextView xiaoliang_text;//销量
    @BindView(R.id.xinpin_text)
    TextView xinpin_text;//新品
    @BindView(R.id.jiage_text)
    TextView jiage_text;//价格


    int mark = 0;
    int page = 1;
    int lastItem = -1;
    int judge = 0;

    List<ClassifyTypeBean> classifyTypeBean;
    @BindView(R.id.jiage_img1)
    ImageView jiageImg1;
    @BindView(R.id.jiage_img2)
    ImageView jiageImg2;

    private SmartRefreshHelper<ClassifyBean.ListBean> mSmartRefreshHelper;

    List<ClassifyBean.ListBean> classifyBean;

    private ClassifyList_Adapter adapter1;

    String sort_key = "type_sort";  //sort_key--综合：type_sort;  价格：product_price; 新品：is_new；销量：virtual_sales
    String sort_value = "desc";//当sort_key不为空时，sort_value不为空；asc:正序,desc：倒序
    String count;//总数
    String iDstr = "";
    String idStr = "";

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_classify;
    }

    @Override
    protected ClassifyFragmentPresenter initPresenter() {
        return new ClassifyFragmentPresenter();
    }

    @Override
    protected void initView() {
        adapter1 = new ClassifyList_Adapter();
        final GridLayoutManager manager1 = new GridLayoutManager(getActivity(), 3);
        classifyRecycler.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(getActivity(), 0)));
        classifyRecycler.addItemDecoration(new SpaceItemDecoration(0, 0));
        classifyRecycler.setLayoutManager(manager1);
//        classifyRecycler.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(getActivity(), 3)));
//        classifyRecycler.addItemDecoration(new SpaceItemDecoration(0, -30));
        classifyRecycler.setAdapter(adapter1);

        //刷新数据
        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                judge = 0;
            }
        });


        presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据

        classifyRecycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
                int lastVisibleItem = manager.findLastCompletelyVisibleItemPosition();//找到最后完全可见的item位置
                Log.e("classifyRecycler", "adapter1.getData().size()====" + adapter1.getData().size());
                Log.e("classifyRecycler", "lastVisibleItem111111====" + lastVisibleItem);
                if (adapter1.getData().size() - 12 == lastVisibleItem) {
                    Log.e("classifyRecycler", "lastVisibleItem222222====" + lastVisibleItem);
                    Log.e("classifyRecycler", "adapter1.getData().2222222222====" + adapter1.getData().size());
                    if (lastItem != lastVisibleItem) {
                        lastItem = lastVisibleItem;
                        page++;
                        judge = 1;
                        Log.e("classifyRecycler", "page====" + page);
                        presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                    }
                } else {
                    if (adapter1.getData().size() - lastItem > 20) {
                        lastItem = adapter1.getData().size() - 12;
                        page++;
                        judge = 1;
                        presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                    }
                }
            }
        });

        //搜索输入框
        classifySerachviewEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //text  输入框中改变后的字符串信息
                //start 输入框中改变后的字符串的起始位置
                //before 输入框中改变前的字符串的位置 默认为0
                //count 输入框中改变后的一共输入字符串的数量
                Log.e("搜索输入框", "搜索框===" + s);
                page = 1;
                presenter.getClassifyData(s.toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //text  输入框中改变前的字符串信息
                //start 输入框中改变前的字符串的起始位置
                //count 输入框中改变前后的字符串改变数量一般为0
                //after 输入框中改变后的字符串与起始位置的偏移量
            }

            @Override
            public void afterTextChanged(Editable s) {
                //edit  输入结束呈现在输入框中的信息
            }
        });

        adapter1.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                MoveAbooutActivity_1.startSelf(getActivity(), adapter1.getData().get(position).getGoods_id(), adapter1.getData().get(position).getSearch_attr());
            }
        });
    }

    @Override
    protected void loadData() {
//        presenter.getAppUpdate();//下载时间
        presenter.getTypeList(0);


    }


    @OnClick({R.id.imageButton1, R.id.imageButton2, R.id.imageButton3, R.id.classify_zonghe, R.id.classify_xiaoliang, R.id.classify_xinpin, R.id.classify_jiage, R.id.classify_shaixuan})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.imageButton1://全部
                mark = 0;
                judge = 0;
                page = 1;
                allView.setBackgroundColor(getResources().getColor(R.color.them));
                ziyingView.setBackgroundColor(getResources().getColor(R.color.classify_them));
                hiataoView.setBackgroundColor(getResources().getColor(R.color.classify_them));
                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                break;
            case R.id.imageButton2://自营
                mark = 1;
                judge = 0;
                page = 1;
                allView.setBackgroundColor(getResources().getColor(R.color.classify_them));
                ziyingView.setBackgroundColor(getResources().getColor(R.color.them));
                hiataoView.setBackgroundColor(getResources().getColor(R.color.classify_them));

                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                break;
            case R.id.imageButton3://海淘
                mark = 2;
                judge = 0;
                page = 1;
                allView.setBackgroundColor(getResources().getColor(R.color.classify_them));
                ziyingView.setBackgroundColor(getResources().getColor(R.color.classify_them));
                hiataoView.setBackgroundColor(getResources().getColor(R.color.them));

                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                break;
//            case R.id.classify_serachview_edt://搜索
////                SearchActivity.startSelf(getContext());
//                break;
            case R.id.classify_zonghe://综合
                zonghe_text.setTextColor(getResources().getColor(R.color.them));
                xiaoliang_text.setTextColor(getResources().getColor(R.color.classify_text1));
                xinpin_text.setTextColor(getResources().getColor(R.color.classify_text1));
                jiage_text.setTextColor(getResources().getColor(R.color.classify_text1));
                jiageImg1.setImageResource(R.mipmap.classify_icon_2);
                jiageImg2.setImageResource(R.mipmap.classify_icon_3);
                sort_key = "type_sort";
                sort_value = "desc";
//                if (sort_value.equals("asc")) {
//                    sort_value = "desc";
//                } else {
//                sort_value = "asc";
//                }
                judge = 0;
                page = 1;
//                sort_key--综合：type_sort;  价格：product_price; 新品：is_new；销量：virtual_sales
//                adapter1.clearData();
                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                break;
            case R.id.classify_xiaoliang://销量
                zonghe_text.setTextColor(getResources().getColor(R.color.classify_text1));
                xiaoliang_text.setTextColor(getResources().getColor(R.color.them));
                xinpin_text.setTextColor(getResources().getColor(R.color.classify_text1));
                jiage_text.setTextColor(getResources().getColor(R.color.classify_text1));
                jiageImg1.setImageResource(R.mipmap.classify_icon_2);
                jiageImg2.setImageResource(R.mipmap.classify_icon_3);
                sort_key = "virtual_sales";
                sort_value = "desc";
//                if (sort_value.equals("asc")) {
//                    sort_value = "desc";
//                } else {
//                sort_value = "asc";
//                }
                judge = 0;
                page = 1;
//                adapter1.clearData();
                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                break;
            case R.id.classify_xinpin://新品
                zonghe_text.setTextColor(getResources().getColor(R.color.classify_text1));
                xiaoliang_text.setTextColor(getResources().getColor(R.color.classify_text1));
                xinpin_text.setTextColor(getResources().getColor(R.color.them));
                jiage_text.setTextColor(getResources().getColor(R.color.classify_text1));
                jiageImg1.setImageResource(R.mipmap.classify_icon_2);
                jiageImg2.setImageResource(R.mipmap.classify_icon_3);
                sort_key = "is_new";
                sort_value = "desc";
//                if (sort_value.equals("asc")) {
//                    sort_value = "desc";
//                } else {
//                sort_value = "asc";
//                }
                judge = 0;
                page = 1;
//                adapter1.clearData();
                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark,sort_key, sort_value, iDstr);//下载分类数据
                break;
            case R.id.classify_jiage://价格
                zonghe_text.setTextColor(getResources().getColor(R.color.classify_text1));
                xiaoliang_text.setTextColor(getResources().getColor(R.color.classify_text1));
                xinpin_text.setTextColor(getResources().getColor(R.color.classify_text1));
                jiage_text.setTextColor(getResources().getColor(R.color.them));
                sort_key = "product_price";
                Log.e("价格", "==sort_value==" + sort_value);
                if (sort_value.equals("asc")) {
                    sort_value = "desc";
                    jiageImg1.setImageResource(R.mipmap.classify_icon_2);
                    jiageImg2.setImageResource(R.mipmap.classify_icon_3_1);

                } else {
                    sort_value = "asc";
                    jiageImg1.setImageResource(R.mipmap.classify_icon_2_1);
                    jiageImg2.setImageResource(R.mipmap.classify_icon_3);

                }
                judge = 0;
                page = 1;
//                adapter1.clearData();
                Log.e("价格", "==sort_value=222222222====" + sort_value);
                Log.e("价格", "==sort_key=====" + sort_key);
                Log.e("价格", "==sort_value=====" + sort_value);
                presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                break;
            case R.id.classify_shaixuan://筛选
                Log.e("筛选", "==iDstr==" + iDstr);
                page = 1;
                judge = 0;
                if (classifyTypeBean != null) {
                    ScreenDialog.with(getActivity(), classifyTypeBean, new ClassifyFragmentPresenter(), count, idStr, iDstr, new ScreenDialog.ClassifDialogOnClickAll() {
                        @Override
                        public void onDialogClickListener(String str, String str1) {
                            Log.e("筛选", "==iDStr===" + str);
                            Log.e("筛选", "==iDStr11111===" + str1);
                            idStr = str;//数据展示；---297,3157
                            iDstr = str1;//掉接口传的参数;---34:297,45:3157
                            presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                        }

                    }).show();
                } else {
                    presenter.getTypeList(1);
                }

                break;
        }
    }


    /**
     * 时间返回成功
     *
     * @param
     * @param
     */
    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {
    }

    /**
     * 时间返回失败
     *
     * @param
     * @param
     */
    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    /**
     * 下载分类数据成功
     *
     * @param
     * @param
     */
    @Override
    public void getClassifySuccess(int code, ClassifyBean data) {
        smartRefreshLayout.finishRefresh();

        count = data.getCount();
        ScreenDialog.setCount(count);
        Log.e("ClassifyFragment", "=下载分类数据成功==count==" + count);

        if (judge == 0) {
            adapter1.setData(data.getList());
        } else {
            adapter1.addData(data.getList());
        }
//        adapter1.notifyDataSetChanged();

    }

    /**
     * 下载分类数据失败
     *
     * @param
     * @param
     */
    @Override
    public void getClassifyFail(int code, String msg) {
        smartRefreshLayout.finishRefresh();
//        if (code == 3000) {
//            ClassifyBean data = new ClassifyBean();
//            adapter1.setData(data.getList());
//            presenter.dismissLoading();
//        }
    }


    /**
     * @Description:分类筛选选项成功
     * @Time:2020/5/11 16:53
     * @Author:pk
     */
    @Override
    public void getClassifyTypeListSuccess(int code, List<ClassifyTypeBean> data, int type) {
        Log.e("筛选", "==data==" + data);
        classifyTypeBean = data;
        if (type == 1) {
            ScreenDialog.with(getActivity(), classifyTypeBean, new ClassifyFragmentPresenter(), count, idStr, iDstr, new ScreenDialog.ClassifDialogOnClickAll() {
                @Override
                public void onDialogClickListener(String str, String str1) {
                    Log.e("筛选", "==分类筛选选项成功=getParent_id===" + str);
                    idStr = str;//数据展示；---297,3157
                    iDstr = str1;//掉接口传的参数;---34:297,45:3157
                    page = 1;
                    Log.e("筛选", "==分类筛选选项成功=getParent_id===" + str1);
                    presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
                }

            }).show();
        }


    }

    /**
     * @Description:分类筛选选项失败
     * @Time:2020/5/11 16:53
     * @Author:pk
     */
    @Override
    public void getClassifyTypeListFail(int code, String msg) {

    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }

    //筛选数据
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ScreenIdListEvent event) {
        String getListId = event.getListId();
        Log.e("ClassifyFragment", "=筛选页传递消息=getListId===" + getListId);
    }

    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ShopCarJudgeEvent event) {
        Log.e("ShoppingCheFragment", "=首页传递消息==");
        int getJupdg = event.getJupdg();
        if (getJupdg == 2) {
            page = 1;
//            presenter.getAppUpdate();//下载时间
            presenter.getClassifyData(classifySerachviewEdt.getText().toString(), page, 20, mark, sort_key, sort_value, iDstr);//下载分类数据
        }
    }

}
