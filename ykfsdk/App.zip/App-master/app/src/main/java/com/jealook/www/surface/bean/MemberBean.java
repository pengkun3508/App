package com.jealook.www.surface.bean;

import java.util.List;

import per.goweii.rxhttp.request.base.BaseBean;

/**
 * @Description:
 * @Time:2020/8/19$
 * @Author:pk$
 */
public class MemberBean extends BaseBean {
    /**
     * list : [{"id":"3","name":"月卡","price":"15.00","original_price":"18.00"},{"id":"2","name":"季卡","price":"30.00","original_price":"48.00"},{"id":"1","name":"年卡会员","price":"88.00","original_price":"188.00"}]
     * users : {"member_end_time":"1970-01-01 08:00:00","is_member":"0","user_name":"你来呀","img_url":"http://img.jealook.com/app_img/20200611/20200611174336_53196.jpg"}
     */

    private UsersBean users;
    private List<ListBean> list;

    public UsersBean getUsers() {
        return users;
    }

    public void setUsers(UsersBean users) {
        this.users = users;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class UsersBean {
        /**
         * member_end_time : 1970-01-01 08:00:00
         * is_member : 0
         * user_name : 你来呀
         * img_url : http://img.jealook.com/app_img/20200611/20200611174336_53196.jpg
         */

        private String member_end_time;
        private String is_member;
        private String user_name;
        private String img_url;

        public String getMember_end_time() {
            return member_end_time;
        }

        public void setMember_end_time(String member_end_time) {
            this.member_end_time = member_end_time;
        }

        public String getIs_member() {
            return is_member;
        }

        public void setIs_member(String is_member) {
            this.is_member = is_member;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }

        public String getImg_url() {
            return img_url;
        }

        public void setImg_url(String img_url) {
            this.img_url = img_url;
        }
    }

    public static class ListBean {
        /**
         * id : 3
         * name : 月卡
         * price : 15.00
         * original_price : 18.00
         */

        private String id;
        private String name;
        private String price;
        private String original_price;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getOriginal_price() {
            return original_price;
        }

        public void setOriginal_price(String original_price) {
            this.original_price = original_price;
        }
    }
}
