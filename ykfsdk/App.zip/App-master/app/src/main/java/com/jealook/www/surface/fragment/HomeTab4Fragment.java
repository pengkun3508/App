package com.jealook.www.surface.fragment;

import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.DisplayInfoUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.http.model.SignBean;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.jealook.www.R;
import com.jealook.www.base.BaseFragment;
import com.jealook.www.common.Config;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.activity.MoveAboutActivity;
import com.jealook.www.surface.adapter.HomeTabAdapter;
import com.jealook.www.surface.dialog.ScreenDialog;
import com.jealook.www.surface.mvp.presenter.HomeFragmentPresenter;
import com.jealook.www.surface.mvp.view.HomeFragmentView;
import com.jealook.www.utils.SmartRefreshHelper;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class HomeTab4Fragment extends BaseFragment<HomeFragmentPresenter> implements HomeFragmentView {

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;
    private HomeTabAdapter homeTabAdapter;
    private SmartRefreshHelper<String> mSmartRefreshHelper;


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home_tab4;
    }


    @Override
    protected HomeFragmentPresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        homeTabAdapter = new HomeTabAdapter();
        recyclerView.setAdapter(homeTabAdapter);
        final int divider = (int) DisplayInfoUtils.getInstance().dp2px(5);
        RecyclerView.ItemDecoration gridItemDecoration = new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                GridLayoutManager layoutManager = (GridLayoutManager) parent.getLayoutManager();
                final GridLayoutManager.LayoutParams lp = (GridLayoutManager.LayoutParams) view.getLayoutParams();
                final int spanCount = layoutManager.getSpanCount();
                int layoutPosition = ((RecyclerView.LayoutParams) view.getLayoutParams()).getViewLayoutPosition();
                if (lp.getSpanSize() != spanCount) {
                    //左边间距
                    if (layoutPosition % 2 == 1) {
                        outRect.left = divider / 2;
                    } else {
                        outRect.right = divider / 2;
                    }
                }
                outRect.top = divider;
            }
        };
        recyclerView.addItemDecoration(gridItemDecoration);
//        mSmartRefreshHelper = SmartRefreshHelper.with(smartRefreshLayout, homeTabAdapter)
//                .setPerPageCount(Config.ONE_PAGE_ITEM_MAX_COUNT_DEFAULT)
//                .init(new SmartRefreshHelper.RefreshCallback() {
//                    @Override
//                    public void doRequestData(int page) {
//                        mSmartRefreshHelper.onSuccess(2000, getData());
//
//                    }
//                });
        homeTabAdapter.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                MoveAboutActivity.startSelf(getActivity());
            }
        });

    }

    @Override
    protected void loadData() {
        mSmartRefreshHelper.requestFirstPage(false);

    }

    @OnClick({R.id.ll_screen})
    @Override
    public void onClick(View v) {
        super.onClick(v);
    }

    @Override
    public boolean onClickWithoutLogin(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.ll_screen:
//                ScreenDialog.with(getActivity()).show();
                break;
        }
        return false;
    }

    public List<String> getData() {
        List<String> strings = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            strings.add("1");
        }
        return strings;
    }

    @Override
    public void getAppUpdateSuccess(int code, SignBean version) {

    }

    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    @Override
    public void getHomeDataSuccess(int code, HomeDataBean data) {

    }

    @Override
    public void getHomeDataFail(int code, String msg) {

    }
}
