package com.jealook.www.surface.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.fastjson.JSON;
import com.alibaba.sdk.android.man.MANService;
import com.alibaba.sdk.android.man.MANServiceProvider;
import com.dm.lib.utils.ResUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.github.jdsjlzx.recyclerview.LRecyclerView;
import com.github.jdsjlzx.recyclerview.LRecyclerViewAdapter;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.common.Constant;
import com.jealook.www.event.ChangeDetailPriceEvent;
import com.jealook.www.event.MainShoppingEvent;
import com.jealook.www.event.ShopTypeDataEvent;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.adapter.DetailsAdapter;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.bean.DetailsBean;
import com.jealook.www.surface.dialog.TypeSelectDialog;
import com.jealook.www.surface.mvp.presenter.MoveAboutPresenter;
import com.jealook.www.surface.mvp.view.MoveAboutView;
import com.jealook.www.utils.AppUtils;
import com.jealook.www.utils.CacheActivity;
import com.jealook.www.utils.DensityUtilss;
import com.jealook.www.utils.GlideImageLoader;
import com.jealook.www.utils.StatusBarUtil;
import com.jealook.www.utils.TransitionTime;
import com.jealook.www.utils.UserInfoBean;
import com.jealook.www.utils.UserUtils;
import com.jealook.www.widgat.actionbar.MoveAboutBarSimple;
import com.m7.imkfsdk.KfStartHelper;
import com.mobile.auth.gatewayauth.AuthRegisterXmlConfig;
import com.mobile.auth.gatewayauth.AuthUIConfig;
import com.mobile.auth.gatewayauth.PhoneNumberAuthHelper;
import com.mobile.auth.gatewayauth.TokenResultListener;
import com.mobile.auth.gatewayauth.model.TokenRet;
import com.mobile.auth.gatewayauth.ui.AbstractPnsViewDelegate;
import com.moor.imkf.IMChatManager;
import com.moor.imkf.model.entity.CardInfo;
import com.moor.imkf.model.entity.NewCardInfo;
import com.moor.imkf.model.entity.NewCardInfoAttrs;
import com.moor.imkf.utils.MoorUtils;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.dm.lib.utils.IOUtils.copy;

/**
 * @Description:商品详情
 * @Time:2020/4/20$
 * @Author:pk$
 */
public class MoveAbooutActivity_1 extends BaseActivity<MoveAboutPresenter> implements MoveAboutView {

    private static final int BAIDU_READ_PHONE_STATE = 100;

    @BindView(R.id.recycler_view)
    LRecyclerView recyclerView;
    @BindView(R.id.title)
    TextView title;
    @BindView(R.id.titlel)
    TextView titlel;
    @BindView(R.id.titler)
    TextView titler;
    @BindView(R.id.title_button)
    LinearLayout title_button;

    //    @BindView(R.id.smart_refresh_layout)
//    SmartRefreshLayout smartRefreshLayout;
    @BindView(R.id.move_shoucang_img)
    ImageView moveShoucangImg;
    @BindView(R.id.title_bars)
    RelativeLayout titleBar;
    @BindView(R.id.action_bar)
    MoveAboutBarSimple actionBar;
    @BindView(R.id.move_shopcat_btn)
    LinearLayout moveShopcatBtn;
    @BindView(R.id.move_kefu_btn)
    LinearLayout moveKefuBtn;
    @BindView(R.id.move_shoucang_btn)
    LinearLayout moveShoucangBtn;
    @BindView(R.id.move_add_shopcat_btn)
    TextView moveAddShopcatBtn;
    @BindView(R.id.tv_move_about)
    TextView tvMoveAbout;


    private float totaldy;
    private float mRecyclerFactor;
    private List<DetailsBean> list;
    private int item1 = 0;
    private int item2 = 0;
    private int item3 = 0;
    private LinearLayoutManager manager;
    private Resources res;
    String mark = "0";


    private static String goods_id;//商品详情
    private static String search_attr;//商品规格

    TextView move_transaction_price;
    TextView move_transaction_price_1;
    TextView move_xianshi_hour;
    TextView move_xianshi_min;
    TextView move_xianshi_second;
    TextView member_velue_text;
    LinearLayout move_ve_go_xianshi;
    RelativeLayout move_ve_go_time;
    RelativeLayout move_ve_go_jian;
    RelativeLayout member_relayout;//会员入口


    MoveDataBean moveDataBean;

    private long mHour = 02;
    private long mMin = 15;
    private long mSecond = 36;
    private boolean isRun = true;
    String[] all;

    DetailsAdapter detailsAdapter;
    List<String> getBannerEvent;
    Banner banner;

    List<String> strings;
    String getAttr_name;

    String sdktoken;
    private CheckBox use_http;
    //相差多少时间 - ms
    private long dt = 0;
    UserInfoBean getUserInfo;
    private int mScreenWidthDp;
    private int mScreenHeightDp;
    private PhoneNumberAuthHelper mAlicomAuthHelper;
    private TokenResultListener mTokenListener;
    private IWXAPI wxAPI;

    public PopupWindow popupwindow;

    String hourss;
    String minutess;
    String secondss;
    String mmark;//选择规格弹框路径；1--商品详情页面；“”--购物车
    String product_ids;
    String nums;


    public static void startSelf(Activity context, String goods_ids, String search_attrs) {
        Intent intent = new Intent(context, MoveAbooutActivity_1.class);
//        context.startActivity(intent);
        context.startActivityForResult(intent, 1);
        goods_id = goods_ids;
        search_attr = search_attrs;
        Log.e("goods_id", "=-goods_id=-" + goods_id);
        Log.e("search_attr", "=-search_attr=-" + search_attr);
    }


    @Override
    protected int getLayoutId() {
        return R.layout.activity_move_about_1;
    }

    @Override
    protected MoveAboutPresenter initPresenter() {
        return new MoveAboutPresenter();
    }


    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        actionBar.getTvRight().setVisibility(View.VISIBLE);
        //分享
        actionBar.getTvRight().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    return;
                } else {
                    initmPopupWindowView();
                    popupwindow.showAtLocation(getActivity().getWindow().getDecorView(), Gravity.CENTER, 0, 0);
                }
            }
        });


        initTitle();
        initListener();
        getUserInfo = UserUtils.getInstance().getUserInfo();

        wxAPI = WXAPIFactory.createWXAPI(getActivity(), Constant.WECHAT_APPID, true);
        wxAPI.registerApp(Constant.WECHAT_APPID);

        inits();


    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }


    //分享
    private void initmPopupWindowView() {
        LinearLayout wx_py_btn, wx_pyq_btn;

        TextView share_cancel_btn;
        // // 获取自定义布局文件pop.xml的视图
        View customView = getLayoutInflater().inflate(R.layout.share_layout, null, false);
        wx_py_btn = customView.findViewById(R.id.wx_py_btn);//好友
        wx_pyq_btn = customView.findViewById(R.id.wx_pyq_btn);//朋友圈
        share_cancel_btn = customView.findViewById(R.id.share_cancel_btn);//取消

        // 创建PopupWindow实例,先宽度，后高度
        popupwindow = new PopupWindow(customView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        // 设置动画效果 [R.style.AnimationFade 是自己事先定义好的]
//        popupwindow.setAnimationStyle(R.style.AnimationFade);
        // 自定义view添加触摸事件
        customView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
                return false;
            }
        });

        //初始化一个WXWebpageObject，填写url
        WXWebpageObject webpage = new WXWebpageObject();
        //http://h5.jealook.com/detail-share/index.html?good_id=6&search_attr=133|134
        webpage.webpageUrl = "http://h5.jealook.com/detail-share/index.html?good_id=" + moveDataBean.getInfo().getGoods_id() + "&search_attr=" + moveDataBean.getInfo().getSearch_attr();//分享商品链接


        WXMediaMessage msg = new WXMediaMessage(webpage);
//用 WXWebpageObject 对象初始化一个 WXMediaMessage 对象
        new Thread(new Runnable() {
            @Override
            public void run() {
                msg.title = "Jealook美瞳 ";
                msg.description = moveDataBean.getInfo().getShop_name() + "\t" + moveDataBean.getInfo().getShop_attr_name();
                Bitmap thumbBmp = null;
                try {
                    thumbBmp = BitmapFactory.decodeStream(new URL(moveDataBean.getInfo().getBanner().get(0)).openStream());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Log.e("分享", "==thumbBmp==" + thumbBmp);
                Bitmap thumbBmps = Bitmap.createScaledBitmap(thumbBmp, 120, 150, true);

                Log.e("分享", "==thumbBmps21111==" + thumbBmps);
                thumbBmp.recycle();
                msg.thumbData = bmpToByteArray(thumbBmps, true);

            }
        }).start();

        //构造一个Req
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("webpage");
        req.message = msg;


        //微信好友
        wx_py_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                SPUtils.getInstance().save("Good_id", moveDataBean.getInfo().getGoods_id());
//                SPUtils.getInstance().save("Search_attr", moveDataBean.getInfo().getSearch_attr());

                req.scene = SendMessageToWX.Req.WXSceneSession;//分享通道
                req.userOpenId = UserUtils.getInstance().getUserId();//分享人的ID
                wxAPI.sendReq(req);
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
            }
        });
        //微信朋友圈
        wx_pyq_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                req.scene = SendMessageToWX.Req.WXSceneTimeline;//分享通道
                req.userOpenId = UserUtils.getInstance().getUserId();//分享人的ID
                wxAPI.sendReq(req);
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
            }
        });
        //取消
        share_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
            }
        });
    }


    public static byte[] bmpToByteArray1(final Bitmap bmp, final boolean needRecycle) {
        int i;
        int j;
        if (bmp.getHeight() > bmp.getWidth()) {
            i = bmp.getWidth();
            j = bmp.getWidth();
        } else {
            i = bmp.getHeight();
            j = bmp.getHeight();
        }

        Bitmap localBitmap = Bitmap.createBitmap(i, j, Bitmap.Config.RGB_565);
        Canvas localCanvas = new Canvas(localBitmap);

        while (true) {
            localCanvas.drawBitmap(bmp, new Rect(0, 0, i, j), new Rect(0, 0, i, j), null);
            if (needRecycle)
                bmp.recycle();
            ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
            localBitmap.compress(Bitmap.CompressFormat.PNG, 10,
                    localByteArrayOutputStream);
            localBitmap.recycle();
            byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
            try {
                localByteArrayOutputStream.close();
                return arrayOfByte;
            } catch (Exception e) {
                //F.out(e);
            }
            i = bmp.getHeight();
            j = bmp.getHeight();
        }
    }

    /**
     * 得到本地或者网络上的bitmap url - 网络或者本地图片的绝对路径,比如:
     * <p>
     * A.网络路径: url=&quot;http://blog.foreverlove.us/girl2.png&quot; ;
     * <p>
     * B.本地路径:url=&quot;file://mnt/sdcard/photo/image.png&quot;;
     * <p>
     * C.支持的图片格式 ,png, jpg,bmp,gif等等
     *
     * @param url
     * @return
     */
    public static Bitmap GetLocalOrNetBitmap(String url) {
        Bitmap bitmap = null;
        InputStream in = null;
        BufferedOutputStream out = null;
        try {
            in = new BufferedInputStream(new URL(url).openStream(), 2 * 1024);
            final ByteArrayOutputStream dataStream = new ByteArrayOutputStream();
            out = new BufferedOutputStream(dataStream, 2 * 1024);
            copy(in, out);
            out.flush();
            byte[] data = dataStream.toByteArray();
            bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
            data = null;
            return bitmap;
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("IOException", "===e===" + e);
            return null;
        }
    }


    public static byte[] bmpToByteArray(final Bitmap bmp, final boolean needRecycle) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, output);
        if (needRecycle) {
            bmp.recycle();
        }
        byte[] result = output.toByteArray();
        try {
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String buildTransaction(final String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis())
                : type + System.currentTimeMillis();
    }


    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ShopTypeDataEvent event) {
        getBannerEvent = event.getBanner();
        TypeSelectDialog.setUrl(getBannerEvent.get(1));
        strings = new ArrayList<>();
        strings.add(getBannerEvent.get(1));

        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        banner.setImages(getBannerEvent);
        //设置指示器位置（当banner模式中有指示器时）
        banner.setIndicatorGravity(BannerConfig.CENTER);
        //banner设置方法全部调用完毕时最后调用
        banner.start();
    }

    //选完规格后返回的价格（接收消息）
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ChangeDetailPriceEvent event) {
        Log.e("ChangeDetailPriceEvent", "==修改规格传回来价格===" + event.getPrice());
//        move_transaction_price.setText("" + event.getPrice());
        if (moveDataBean.getInfo().getIs_promote().equals("1")) {//显示限时页面
            moveDataBean.getInfo().setPreferential_price(event.getPrice());
        } else if (moveDataBean.getInfo().getIs_promote().equals("0")) {//显示普通页面
            moveDataBean.getInfo().setProduct_price(event.getPrice());
        }
        moveDataBean.getInfo().setShop_attr_name(event.getAttr_name());
        detailsAdapter.setDatas(moveDataBean);
        detailsAdapter.notifyDataSetChanged();


    }


    private void initTitle() {
        res = getResources();
        //        图片的高度-状态栏的高度
        mRecyclerFactor = (DensityUtilss.dp2px(this, 400.0F) - DensityUtilss.getStatusBarHeight(this));
    }

    private void initListener() {
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (item1 != 0) {
                    recyclerView.scrollBy(0, (int) -totaldy);
                }
            }
        });
        titlel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (item2 != 0) {
//                    判断滑动距离是否超过商品
                    if (totaldy > item1)
                        recyclerView.scrollBy(0, (int) -(totaldy - item1) + 20);
                    else
                        recyclerView.scrollBy(0, (int) (item1 - totaldy) + 20);

                }
            }
        });
        titler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (item3 != 0) {
//                    recyclerView.scrollBy(0, item3);
//                }
                if (item3 != 0) {
//                    判断滑动距离是否超过商品
                    if (totaldy > item2)

                        recyclerView.scrollBy(0, (int) -(totaldy - item2) + (int) mRecyclerFactor);
                    else
                        recyclerView.scrollBy(0, (int) (item2 - totaldy) + (int) mRecyclerFactor);

                }
            }
        });
        //        设置渐变的主要代码
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recycler, int dx, int dy) {
                super.onScrolled(recycler, dx, dy);

                //滑动的距离
                totaldy += dy;
//                if (item2 != 0 && item1 != 0 && item3 != 0) {
                if (totaldy < item1) {
                    title.setTextColor(res.getColor(R.color.them));
                    titlel.setTextColor(res.getColor(R.color.black));
                    titler.setTextColor(res.getColor(R.color.black));
                } else if (totaldy > item1 && totaldy < item2) {
                    titlel.setTextColor(res.getColor(R.color.them));
                    title.setTextColor(res.getColor(R.color.black));
                    titler.setTextColor(res.getColor(R.color.black));
                } else if (totaldy > item2) {
                    titler.setTextColor(res.getColor(R.color.them));
                    title.setTextColor(res.getColor(R.color.black));
                    titlel.setTextColor(res.getColor(R.color.black));
                }
//                }
                //当滑动的距离 <= toolbar高度的时候，改变Toolbar背景色的透明度，达到渐变的效果
                if (totaldy <= mRecyclerFactor) {//--11.0---291.0
//                    如果在显示图片中显示圆图标
//                    算出透明度
                    float scale = (float) totaldy / mRecyclerFactor;
                    float alpha = scale * 255;//0.03780069*255

                    if (alpha < 160) {//9.639175
//                        如果透明度小于160设置为顶部是图片
//                        title_button.setVisibility(View.GONE);
                        StatusBarUtil.setTranslucentForImageView(MoveAbooutActivity_1.this, (int) alpha, titleBar);
                        title.setTextColor(Color.argb((int) alpha, 0, 0, 0));
                        titlel.setTextColor(Color.argb((int) alpha, 0, 0, 0));
                        titler.setTextColor(Color.argb((int) alpha, 0, 0, 0));
                        StatusBarUtils.setStatusBarMode(getActivity(), true);
                    } else {
//                        title_button.setVisibility(View.VISIBLE);
                        StatusBarUtil.setColor(MoveAbooutActivity_1.this, Color.argb((int) alpha, 255, 255, 255));
                        title.setTextColor(Color.argb((int) alpha, 0, 0, 0));
                        titlel.setTextColor(Color.argb((int) alpha, 0, 0, 0));
                        titler.setTextColor(Color.argb((int) alpha, 0, 0, 0));
                        StatusBarUtils.setStatusBarMode(getActivity(), true);
                    }
                    titleBar.setBackgroundColor(Color.argb((int) alpha, 255, 255, 255));
//                    title.setTextColor( Color.argb((int) alpha, 255, 255, 255));
//                    titlel.setTextColor( Color.argb((int) alpha, 255, 255, 255));
//                    titler.setTextColor( Color.argb((int) alpha, 255, 255, 255));
                } else {
                    StatusBarUtils.setStatusBarMode(getActivity(), true);
                    titleBar.setBackgroundColor(Color.parseColor("#ffffff"));
                    StatusBarUtil.setColor(MoveAbooutActivity_1.this, Color.parseColor("#ffffff"));
//                    title_button.setVisibility(View.VISIBLE);
//                    title.setTextColor(Color.argb(255, 0, 0, 0));
//                    titlel.setTextColor(Color.argb(255, 0, 0, 0));
//                    titler.setTextColor(Color.argb(255, 0, 0, 0));
                }

            }
        });
    }


    @Override
    protected void loadData() {
//        presenter.getAppUpdate();//下载时间
        presenter.getMoveDatas(goods_id, search_attr);//下载商品详情数据
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    /**
     * 数据时间返回成功
     *
     * @param code
     * @param version
     */
    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {

    }

    /**
     * 数据时间返回失败
     *
     * @param code
     * @param
     */
    @Override
    public void getAppUpdateFail(int code, String msg) {
    }

    /**
     * 商品详情返回成功
     *
     * @param code
     * @param
     */
    @Override
    public void getMoveDataSuccess(int code, MoveDataBean data) {
        moveDataBean = data;

        int getIs_collect = moveDataBean.getInfo().getIs_collect();
        if (getIs_collect == 0) {//没有收藏
            moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.move_img1));
            mark = "0";
        } else if (getIs_collect == 1) {//收藏
            moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.shoucang_img1));
            mark = "1";
        }

        list = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            DetailsBean bean = new DetailsBean();
            bean.setType(i + 1);
            list.add(bean);
        }
        setAdapters(list, moveDataBean);//加载数据

        //计算秒杀倒计时---ms
        dt = Integer.valueOf(data.getInfo().getSurplus_time());
        handler.sendEmptyMessageDelayed(0, 1000);


    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            dt = dt - 1;

            long hours = dt / (60 * 60);
            long minutes = (dt / 60) % 60;
            long seconds = dt % 60;

            hourss = String.valueOf(hours);
            minutess = String.valueOf(minutes);
            secondss = String.valueOf(seconds);

            if (hours < 10) {
                hourss = "0" + hours;
            }
            if (minutes < 10) {
                minutess = "0" + minutes;
            }
            if (seconds < 10) {
                secondss = "0" + seconds;
            }
//            Log.e("倒计时--详情页", "seconds====" + secondss);


            //设置倒计时
            move_xianshi_hour.setText(hourss + ":" + minutess + ":" + secondss);
            handler.removeMessages(0);
            handler.sendEmptyMessageDelayed(0, 1000);
            if (dt <= 0) {
                handler.removeCallbacksAndMessages(null);
            }
        }
    };

    /**
     * 商品详情返回失败
     *
     * @param code
     * @param
     */
    @Override
    public void getMoveDataFail(int code, String msg) {

    }

    /**
     * 收藏商品成功
     *
     * @param code
     * @param
     */
    @Override
    public void getCollectionShopSuccess(int code, Object data) {
        Log.e("收藏商品成功", "==code==" + code);
        Log.e("收藏商品成功", "==data==" + data);
        if (mark.equals("1")) {
            moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.shoucang_img1));
            Toast.makeText(this, "收藏成功", Toast.LENGTH_SHORT).show();
        } else if (mark.equals("0")) {
            moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.move_img1));
            Toast.makeText(this, "取消收藏成功", Toast.LENGTH_SHORT).show();
        }


    }

    /**
     * 收藏商品失败
     *
     * @param code
     * @param
     */
    @Override
    public void getCollectionShopFail(int code, String msg) {
        Log.e("收藏商品失败", "==code==" + code);
        Log.e("收藏商品失败", "==msg==" + msg);

        if (mark.equals("1")) {
            mark = "0";
            moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.move_img1));
            Toast.makeText(this, "收藏失败", Toast.LENGTH_SHORT).show();
        } else if (mark.equals("0")) {
            mark = "1";
            moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.shoucang_img1));
            Toast.makeText(this, "取消收藏失败", Toast.LENGTH_SHORT).show();
        }

    }

    /**
     * 添加购物车成功
     *
     * @param code
     * @param
     */
    @Override
    public void getAddShopCarSuccess(int code, Object data) {
        Log.e("添加购物车成功", "==code==" + code);
        Log.e("添加购物车成功", "==msg==" + data);
        TypeSelectDialog.dismiss();
//        TypeSelectDialog.with(getActivity(), moveDataBean, this).dismiss();
    }

    /**
     * 添加购物车失败
     *
     * @param code
     * @param
     */
    @Override
    public void getAddShopCarFail(int code, String msg) {
        Log.e("添加购物车失败", "==code==" + code);
        Log.e("添加购物车失败", "==msg==" + msg);
    }

    private void setAdapters(List<DetailsBean> list, MoveDataBean dataBean) {
//        recyclerView.setFocusable(false);
        recyclerView.setNestedScrollingEnabled(false);
        detailsAdapter = new DetailsAdapter(this);
        detailsAdapter.setDatas(dataBean);
        detailsAdapter.setDataList(list);
        LRecyclerViewAdapter adapter1 = new LRecyclerViewAdapter(detailsAdapter);
        View headView = View.inflate(this, R.layout.details_head, null);
        List<String> getBanner = dataBean.getInfo().getBanner();
        Log.e("setAdapter", "=getBanner=" + getBanner);
        banner = headView.findViewById(R.id.banners);

        move_ve_go_xianshi = headView.findViewById(R.id.move_ve_go_xianshi);//普通隐藏，限时显示
        move_ve_go_time = headView.findViewById(R.id.move_ve_go_time);//普通隐藏，限时显示
        move_ve_go_jian = headView.findViewById(R.id.move_ve_go_jian);//普通隐藏，限时显示

        move_transaction_price = headView.findViewById(R.id.move_transaction_prices);
        move_transaction_price_1 = headView.findViewById(R.id.move_transaction_price_1s);
        move_xianshi_hour = headView.findViewById(R.id.move_xianshi_hour);
        move_xianshi_min = headView.findViewById(R.id.move_xianshi_min);
        move_xianshi_second = headView.findViewById(R.id.move_xianshi_second);
        member_relayout = headView.findViewById(R.id.member_relayout);//会员入口
        member_velue_text = headView.findViewById(R.id.member_velue_text);//会员折扣值

        member_velue_text.setText(dataBean.getInfo().getMember_discount());


        if (dataBean.getInfo().getIs_promote().equals("1")) {//显示限时页面
            move_ve_go_xianshi.setVisibility(View.VISIBLE);
            move_ve_go_time.setVisibility(View.VISIBLE);
            move_transaction_price.setText("￥" + dataBean.getInfo().getPreferential_price());
            move_transaction_price_1.setText("￥" + dataBean.getInfo().getProduct_price());
        } else if (dataBean.getInfo().getIs_promote().equals("0")) {//显示普通页面
            move_ve_go_xianshi.setVisibility(View.GONE);
            move_ve_go_time.setVisibility(View.GONE);
            move_transaction_price.setText("￥" + dataBean.getInfo().getProduct_price());

        }
        move_transaction_price_1.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
//        move_transaction_time.setText(dataBean.getInfo().getPromote_start_date());

        int startDate = Integer.parseInt(dataBean.getInfo().getPromote_start_date());
        int endDate = Integer.parseInt(dataBean.getInfo().getPromote_end_date());
        int dataTime = endDate - startDate;
        String time = TransitionTime.secToTime(dataTime);
//        all = time.split(":");
        Log.e("", "==all==" + all);
        int getSurplus_time = dataBean.getInfo().getSurplus_time();
        String times = TransitionTime.secToTime(getSurplus_time);
        all = times.split(":");


        mHour = Long.parseLong(all[0]);
        mMin = Long.parseLong(all[1]);
        mSecond = Long.parseLong(all[2]);


        strings = new ArrayList<>();
        for (int i = 0; i < getBanner.size(); i++) {
            strings.add(getBanner.get(i));
        }

        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        banner.setImages(strings);
        //设置指示器位置（当banner模式中有指示器时）
        banner.setIndicatorGravity(BannerConfig.CENTER);
        //banner设置方法全部调用完毕时最后调用
        banner.start();
        adapter1.addHeaderView(headView);
        manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter1);
        recyclerView.setPullRefreshEnabled(false);
        recyclerView.setLoadMoreEnabled(false);
        recyclerView.setNoMore(true);
        detailsAdapter.setListener(new DetailsAdapter.OnItemHeightListener() {
            @Override
            public void setOnItemHeightListener(int height, int type) {
                if (height != 0) {
                    if (type == 1001) {
                        item1 = (int) (height + mRecyclerFactor);
                        return;
                    } else if (type == 1002) {
                        item2 = item1 + (height - DensityUtilss.getWidth(MoveAbooutActivity_1.this));
//                        item2 = item1 + height;
                        return;
                    } else if (type == 1003) {
                        item3 = item2 + item1;
                        return;
                    }
                }

            }

            @Override
            public void onSeeMoreBtnClick(String goods_id) {
                EvaluateListActivity.startSelf(getContext(), goods_id);

            }

        });
        /**
         * 会员入口
         */
        member_relayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!UserUtils.getInstance().getUserId().equals("")) {
                    MemberActivity.startSelf(getContext(), "1");//会员购买入口
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }


    @SuppressLint("MissingPermission")
    @OnClick({R.id.move_shopcat_btn, R.id.move_kefu_btn, R.id.move_shoucang_btn, R.id.move_add_shopcat_btn, R.id.tv_move_about})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.move_shopcat_btn://购物车
                CacheActivity.finishSingleActivityByClass(RecommendActivity.class);
                CacheActivity.finishSingleActivityByClass(SearchActivity.class);
                CacheActivity.finishSingleActivityByClass(SearchListActivity.class);
                CacheActivity.finishSingleActivityByClass(CommodityActivity.class);
                CacheActivity.finishSingleActivityByClass(BrandActivity.class);
                CacheActivity.finishSingleActivityByClass(LimitedActivity.class);
                CacheActivity.finishSingleActivityByClass(CollectionActivity.class);
//                setResult(10);
                new MainShoppingEvent("10").post();
                finish();
                break;
            case R.id.move_kefu_btn://客服
                if (!UserUtils.getInstance().getUserId().equals("")) {
//                    if (Build.VERSION.SDK_INT >= 23) {
////                        showContacts();
//                        handlePermission();
//                    } else {
////                        CustomerService();
                    //初始化SDK
                    initSdk();
//                    }

                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.move_shoucang_btn://收藏
                if (mark.equals("0")) {
                    mark = "1";
                    presenter.getMoveCollectionShop(moveDataBean.getInfo().getGoods_id(), mark);
                } else if (mark.equals("1")) {
                    mark = "0";
                    presenter.getMoveCollectionShop(moveDataBean.getInfo().getGoods_id(), mark);
                }
                break;
            case R.id.move_add_shopcat_btn://加入购物车
                if (moveDataBean == null) {
                    return;
                }
                if (!UserUtils.getInstance().getUserId().equals("")) {
//                String getSearch_attr = moveDataBean.getInfo().getSearch_attr();//默认选中的规格和颜色
                    TypeSelectDialog.with(getActivity(), moveDataBean, "", "", new TypeSelectDialog.AddShopCarClickListener() {
                        @Override
                        public void onBtnClickListener(String goods_id, String product_id, String num, String getAttr_names, String mmake) {
                            Log.e("onBtnClickListener", "==getAttr_names==" + getAttr_names);
                            getAttr_name = getAttr_names;
                            presenter.getAddShopCar(goods_id, product_id, num);
                        }
                    }).show();
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                    if (UserUtils.getInstance().getUserId().equals("")) {
//                    loginDialog();
//                    getPhoneNumber();
                        showLoadingDialog();
                        mAlicomAuthHelper.getLoginToken(getActivity(), 0);
                    }
                }


                break;
            case R.id.tv_move_about://购买
                if (moveDataBean == null) {
                    return;
                }


                if (!UserUtils.getInstance().getUserId().equals("")) {
                    TypeSelectDialog.with(getActivity(), moveDataBean, "", "1", new TypeSelectDialog.AddShopCarClickListener() {
                        @Override
                        public void onBtnClickListener(String goods_id, String product_id, String num, String getAttr_names, String mmake) {
                            Log.e("onBtnClickListener", "==getAttr_names==" + getAttr_names);
                            getAttr_name = getAttr_names;
//                            presenter.getAddShopCar(goods_id, product_id, num);
                            mmark = mmake;
                            presenter.getConfirmOrderData("", goods_id, product_id, num);
                            product_ids = product_id;
                            nums = num;

                        }
                    }).show();
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                    if (UserUtils.getInstance().getUserId().equals("")) {
//                    loginDialog();
//                    getPhoneNumber();
                        showLoadingDialog();
                        mAlicomAuthHelper.getLoginToken(getActivity(), 0);
                    }
                }


                break;

        }
    }


    /**
     * 初始化SDK
     */
    private void initSdk() {
        //设置sdk 显示语言版本
//        initLanguage("en");
        /*
          第一步:初始化help
         */
        final KfStartHelper helper = new KfStartHelper(this);
        /*
          商品信息实例，若有需要，请参照此方法；
         */
//        handleCardInfo(helper);
         /*
          新卡片类型示例，若有需要，请参照此方法；
         */
//        handleNewCardInfo(helper);
        /*
          第二步:设置参数
          初始化sdk方法，必须先调用该方法进行初始化后才能使用IM相关功能
          @param accessId       接入id（需后台配置获取）
          @param userName       用户名
          @param userId         用户id
         */
        /*
         * 修改会话页面 注销按钮 文案。建议两个 文字
         */
//        helper.setChatActivityLeftText("注销");
        /*
         * 修改会话页面 是否需要 emoji表情 按钮。
         */
//        helper.setChatActivityEmoji(true);
        helper.initSdkChat("97e623b0-f404-11ea-938a-2d31778d2422", UserUtils.getInstance().getUserInfo().getUser_name(), UserUtils.getInstance().getUserInfo().getUser_id());
    }

    /**
     * 获取未读消息数示例
     */
    private void getUnReadCount() {
        if (MoorUtils.isInitForUnread(getApplicationContext())) {

            IMChatManager.getInstance().getMsgUnReadCountFromService(new IMChatManager.HttpUnReadListen() {
                @Override
                public void getUnRead(int acount) {
                    Toast.makeText(MoveAbooutActivity_1.this, "未读消息数为：" + acount, Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            //未初始化，消息当然为 ：0
            Toast.makeText(MoveAbooutActivity_1.this, "还没初始化", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 商品信息示例
     *
     * @param helper
     */
    private void handleCardInfo(KfStartHelper helper) {
        String s = "https://wap.boosoo.com.cn/bobishop/goodsdetail?id=10160&mid=36819";
//        String s = "https://share1.atoshi.cn/#/productdetail?productId=376&userId=100123350544";
        CardInfo ci = new CardInfo("http://seopic.699pic.com/photo/40023/0579.jpg_wh1200.jpg", "我是一个标题当初读书", "我是name当初读书。", "价格 1000-9999", "https://www.baidu.com");
        String icon = "https://www.tianxiadengcang.com//index.php?m=Api&c=Goods&a=goodsThumImages&width=200&height=200&goods_id=168";
        String title = "美式北欧吊灯家居灯卧室客厅书房餐厅灯D1-31008-12头";
        String content = "8头/φ520*H350/96W 天下灯仓包装 黑色";
        String rigth3 = " ¥548.00";
        try {
            ci = new CardInfo(URLEncoder.encode(icon, "utf-8"), URLEncoder.encode(title, "utf-8"),
                    URLEncoder.encode(content, "utf-8"), URLEncoder.encode(rigth3, "utf-8"),
                    URLEncoder.encode(s, "utf-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        helper.setCard(ci);
    }

    /**
     * 新卡片类型示例,{@link NewCardInfo.Builder()} Builder中默认添加了一些字段，请在此自行定制
     */
    private void handleNewCardInfo(KfStartHelper helper) {
//        NewCardInfo newCardInfo = new NewCardInfo.Builder()
//                .build();

        NewCardInfo newCardInfo = new NewCardInfo.Builder()
                .setTitle("我是标题")
                .setAttr_one(new NewCardInfoAttrs().setColor("#487903").setContent("x9"))
                .setAttr_two(new NewCardInfoAttrs().setColor("#845433").setContent("未发货"))
                .setOther_title_one("附件信息")
                .setOther_title_two(null)
                .setOther_title_three(null)
                .setSub_title("我是副标题")
                .setPrice("$999")
                .build();


        helper.setNewCardInfo(newCardInfo);
    }

    /**
     * 语言切换
     * 中文 language：""
     * 英文 language："en"
     */
    private void initLanguage(String language) {
        Resources resources = getApplicationContext().getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.locale = new Locale(language);
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());//更新配置
    }


    //Android6.0申请权限的回调方法
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            // requestCode即所声明的权限获取码，在checkSelfPermission时传入
            case BAIDU_READ_PHONE_STATE:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // 获取到权限，作相应处理（调用定位SDK应当确保相关权限均被授权，否则可能引起定位失败）
//                    CustomerService();

                    break;
                } else {
                    // 没有获取到权限，做特殊处理
                    Toast.makeText(getApplicationContext(), "获取位置权限失败，请手动开启", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }


    /**
     * 一键登录
     */
    private void inits() {
        /*
         *   1.init get token callback Listener
         */
        mTokenListener = new TokenResultListener() {
            @Override
            public void onTokenSuccess(final String ret) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.e("xxxxxx", "onTokenSuccess:" + ret);

                        /*
                         *   setText just show the result for get token。
                         *   use ret to verfiy number。
                         */
//                        mAlicomAuthHelper.hideLoginLoading();
                        dismissLoadingDialog();
                        TokenRet tokenRet = null;
                        try {
                            tokenRet = JSON.parseObject(ret, TokenRet.class);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        configLoginTokenPortDialog();


                        if (tokenRet != null && ("600024").equals(tokenRet.getCode())) {
                            Log.e("获取到的Token值", "===终端自检成功:\n==Token值===" + ret);
                        }

                        if (tokenRet != null && ("600001").equals(tokenRet.getCode())) {
                            Log.e("获取到的Token值", "===唤起授权页成功:\n==Token值===" + ret);
                        }

                        if (tokenRet != null && ("600000").equals(tokenRet.getCode())) {
                            String token = tokenRet.getToken();
                            mAlicomAuthHelper.quitLoginPage();
                            Log.e("获取到的Token值", "===获取token成功:\n==Token值=11==" + ret);
                            presenter.getMobileLogin(token);

                            //将Token值

                        }
                    }
                });
            }

            @Override
            public void onTokenFailed(final String ret) {
                Log.e("xxxxxx", "onTokenFailed:" + ret);
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        /*
                         *  setText just show the result for get token
                         *  do something when getToken failed, such as use sms verify code.
                         */
//                        hideLoadingDialog();
                        dismissLoadingDialog();
//                        Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
                        Log.e("获取到的Token值", "===获取token失败:\n==Token值=22==" + ret);
                        mAlicomAuthHelper.quitLoginPage();
                        LoginActivity.startSelf(getActivity());
                    }
                });
            }
        };
        /*
         *   2.init AlicomAuthHelper with tokenListener
         */
        mAlicomAuthHelper = PhoneNumberAuthHelper.getInstance(getActivity(), mTokenListener);
        mAlicomAuthHelper.setAuthListener(mTokenListener);
        /*
         *   3.set debugMode when app is in debug mode, sdk will print log in debug mode
         */
        mAlicomAuthHelper.setLoggerEnable(true);//设置SDK是否开启日
        mAlicomAuthHelper.setAuthSDKInfo(Constant.LONIG_PHONE_NUMBER_KEY);//设置秘钥


    }

    private void configLoginTokenPortDialog() {
//        initDynamicView();
        mAlicomAuthHelper.removeAuthRegisterXmlConfig();
        mAlicomAuthHelper.removeAuthRegisterViewConfig();
        int authPageOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
        if (Build.VERSION.SDK_INT == 26) {
            authPageOrientation = ActivityInfo.SCREEN_ORIENTATION_BEHIND;
        }
        updateScreenSize(authPageOrientation);
        int dialogWidth = (int) (mScreenWidthDp * 0.8f);
        int dialogHeight = (int) (mScreenHeightDp * 0.65f);
        mAlicomAuthHelper.addAuthRegisterXmlConfig(new AuthRegisterXmlConfig.Builder()
                .setLayout(R.layout.login_item_layou_1, new AbstractPnsViewDelegate() {
                    @Override
                    public void onViewCreated(View view) {
                        findViewById(R.id.login_btn1).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {//其他号码登录
                                mAlicomAuthHelper.hideLoginLoading();
                                LoginActivity.startSelf(getActivity());
                                mAlicomAuthHelper.quitLoginPage();
                            }
                        });
                    }
                })
                .build());

        mAlicomAuthHelper.addAuthRegisterXmlConfig(new AuthRegisterXmlConfig.Builder()
                .setLayout(R.layout.login_item_layou_2, new AbstractPnsViewDelegate() {
                    @Override
                    public void onViewCreated(View view) {
                        findViewById(R.id.login_wechat).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                login();//微信登陆
                            }
                        });
//                        findViewById(R.id.login_qq).setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//
//                            }
//                        });
//                        findViewById(R.id.login_weibo).setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//
//                            }
//                        });
                    }
                })
                .build());


        int logBtnOffset = dialogHeight / 2;


        mAlicomAuthHelper.setAuthUIConfig(new AuthUIConfig.Builder()
                .setAppPrivacyOne("《隐私政策》", "http://shop.jealook.com/v1/html/article-info?id=117")
                .setAppPrivacyTwo("《用户协议》", "http://shop.jealook.com/v1/html/article-info?id=119")
                .setAppPrivacyColor(Color.BLACK, Color.parseColor("#A08FBB"))
                .setPrivacyState(true)
                .setCheckboxHidden(true)
                .setNavHidden(false)
                .setNavColor(getResources().getColor(R.color.them))
                .setWebNavColor(Color.parseColor("#A08FBB"))//设置协议顶部导航栏背景色
                .setStatusBarColor(Color.parseColor("#A08FBB"))//设置状态栏颜色
                .setLightColor(false)
                .setAuthPageActIn("in_activity", "out_activity")
                .setAuthPageActOut("in_activity", "out_activity")
                .setVendorPrivacyPrefix("《")
                .setVendorPrivacySuffix("》")
                .setLogBtnWidth(dialogWidth - 30)
                .setLogBtnMarginLeftAndRight(15)
                .setNavReturnHidden(true)//隐藏导航栏按钮
                .setLogBtnOffsetY(logBtnOffset + 60)
                .setNumFieldOffsetY(logBtnOffset)
                .setPageBackgroundPath("login_bg")
                .setLogBtnTextSize(18)
                .setDialogBottom(false)
                .setScreenOrientation(authPageOrientation)
                .setNavText("")
                .setSloganText("")
                .setSloganTextColor(Color.parseColor("#00000000"))
                .setNumberColor(Color.parseColor("#A08FBB"))
                .setNumberSize(27)
                .setSwitchAccHidden(true)
                .setLogBtnText("本机号码一键登录")
                .setLogBtnBackgroundPath("classify_list_item")
                .setLogBtnHeight(40)
                .setPrivacyOffsetY_B(110)
                .create());

    }

    private void updateScreenSize(int authPageScreenOrientation) {
        int screenHeightDp = AppUtils.px2dp(getActivity().getApplicationContext(), AppUtils.getPhoneHeightPixels(getActivity()));
        int screenWidthDp = AppUtils.px2dp(getActivity().getApplicationContext(), AppUtils.getPhoneWidthPixels(getActivity()));
        int rotation = getActivity().getWindowManager().getDefaultDisplay().getRotation();
        if (authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_BEHIND) {
            authPageScreenOrientation = getActivity().getRequestedOrientation();
        }
        if (authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                || authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                || authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT) {
            rotation = Surface.ROTATION_180;
        }
        switch (rotation) {
            case Surface.ROTATION_180:
                mScreenWidthDp = screenWidthDp;
                mScreenHeightDp = screenHeightDp;
                break;
        }
    }

    /**
     * 微信登录(三个步骤)
     * 1.微信授权登录
     * 2.根据授权登录code 获取该用户token
     * 3.根据token获取用户资料
     */
    public void login() {
//        SendAuth.Req req = new SendAuth.Req();
//        req.scope = "snsapi_userinfo";
//        req.state = String.valueOf(System.currentTimeMillis());
//        wxAPI.sendReq(req);

        if (!wxAPI.isWXAppInstalled()) {
            Toast.makeText(getActivity(), "您的设备未安装微信客户端", Toast.LENGTH_SHORT).show();
        } else {
            final SendAuth.Req req = new SendAuth.Req();
            req.scope = "snsapi_userinfo";
            req.state = String.valueOf(System.currentTimeMillis());
            wxAPI.sendReq(req);
        }

    }

    /**
     * @Description:一键登录成功
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getMobileLoginSuccess(int code, UserInfoBean data) {
        UserUtils.getInstance().login(data);
        // 用户登录埋点
        MANService manService = MANServiceProvider.getService();
        manService.getMANAnalytics().updateUserAccount("usernick", data.getUser_id());
//        new LoginDataEvent(data).post();
//        new MainHomeActivityEvent("2").post();
//        presenter.getPersonalInformation();//下载
//        finish();


    }

    /**
     * @Description:一键登录失败
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getMobileLoginFail(int code, String msg) {

    }

    /**
     * @Description:结算页面接口成功
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getConfirmOrderSuccess(int code, ConfirmOrderBean data) {
        if (mmark.equals("1")) {
            ConfirmOrderActivity.startSelf(MoveAbooutActivity_1.this, "", goods_id, product_ids, nums);
            TypeSelectDialog.dismiss();
        }
    }

    /**
     * @Description:结算页面接口失败
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getConfirmOrderFail(int code, String msg) {
        if (code == 4000) {
            Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }

}
