package com.jealook.www.surface.fragment;


import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Matrix;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.SPUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.google.gson.Gson;
import com.jealook.www.R;
import com.jealook.www.base.BaseFragment;
import com.jealook.www.common.Constant;
import com.jealook.www.event.GuangGaoEvent;
import com.jealook.www.event.HomeRefreshDataEvent;
import com.jealook.www.event.StratMoveAbooutActivity_1;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.receiver.AppUpdateReceiver;
import com.jealook.www.surface.activity.BrandActivity;
import com.jealook.www.surface.activity.CommodityActivity;
import com.jealook.www.surface.activity.LimitedActivity;
import com.jealook.www.surface.activity.MemberActivity;
import com.jealook.www.surface.activity.MoveAbooutActivity_1;
import com.jealook.www.surface.activity.ProductDetailsActivity;
import com.jealook.www.surface.activity.RecommendActivity;
import com.jealook.www.surface.activity.SearchActivity;
import com.jealook.www.surface.activity.WebActivity;
import com.jealook.www.surface.adapter.PaoQiList_Adapter;
import com.jealook.www.surface.adapter.PinpaiList_Adapter;
import com.jealook.www.surface.adapter.XianShiList_Adapter;
import com.jealook.www.surface.mvp.presenter.HomeFragmentPresenter;
import com.jealook.www.surface.mvp.view.HomeFragmentView;
import com.jealook.www.utils.DensityUtils;
import com.jealook.www.utils.GlideImageLoader;
import com.jealook.www.utils.ImageLoader;
import com.jealook.www.utils.SPAppUpdateUtils;
import com.jealook.www.utils.UserUtils;
import com.jealook.www.widgat.SpaceItemDecoration;
import com.jealook.www.widgat.SpacesItemDecoration;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.listener.OnBannerListener;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;

import butterknife.BindView;
import butterknife.OnClick;


/**
 * @Description:首页 优秀啊
 * @Time:2020/4/1 10:29
 * @Author:pk
 */
public class HomeFragment extends BaseFragment<HomeFragmentPresenter> implements HomeFragmentView {


    @BindView(R.id.home_serachview)
    TextView homeSerachview;//搜索框
    @BindView(R.id.camera_icon)
    ImageView cameraIcon;//相机
    @BindView(R.id.dot_0)
    View dot0;//点1
    @BindView(R.id.dot_1)
    View dot1;//点2
    @BindView(R.id.dot_2)
    View dot2;//点3
    @BindView(R.id.dot_3)
    View dot3;//点4
    @BindView(R.id.home_banner_fragment)
    FrameLayout homeBannerFragment;
    //    @BindView(R.id.gonggao)
//    VerticalTextview gonggao;//公告
    @BindView(R.id.recyclerv_1)
    RecyclerView recyclerv1;//限时折扣
    @BindView(R.id.recyclerv_2)
    RecyclerView recyclerv2;//品牌展示
    @BindView(R.id.recycler_paoqi)
    RecyclerView recyclerPaoqi;//各类抛期

    @BindView(R.id.xianshi_zanshi_text)
    TextView xianshiZanshiText;
    @BindView(R.id.pinpai_zanshi_text)
    TextView pinpaiZanshiText;
    @BindView(R.id.home_product)
    ImageView homeProduct;
    @BindView(R.id.banner)
    Banner banner;
    @BindView(R.id.xianshi_layout)
    RelativeLayout xianshi_layout;


    List<String> titleList;
    @BindView(R.id.paoqi_move_xianshi)
    TextView paoqiMoveXianshi;
    @BindView(R.id.paoqi_move_pinpai)
    TextView paoqiMovePinpai;
    @BindView(R.id.pinpai_title_img)
    ImageView pinpaiTitleImg;
    @BindView(R.id.xianshi_title_img)
    ImageView xianshiTitleImg;
    @BindView(R.id.view_flipper)
    ViewFlipper viewFlipper;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;


    private List<View> dots;
    private List<ImageView> images;
    //记录上一次点的位置
    private int oldPosition = 0;
    private int currentItem;
    private ScheduledExecutorService scheduledExecutorService;
    private ViewPagerAdapter adapter;
    String dataId;
    int dt;
    HomeDataBean.IndexAdBean getIndex_ad;

    List<HomeDataBean.BannerBean> bannerImage;//轮播
    List<HomeDataBean.ArtcleBean> getArtcle;//公告
    List<HomeDataBean.ShopBean> getShop;//抛期
    List<HomeDataBean.DiscountBean> getDiscount;//限时
    List<HomeDataBean.BrandBean> getBrnad;//品牌
    HomeDataBean.AlertAdBean getAlert_ad;//广告

    XianShiList_Adapter adapter1;
    private PinpaiList_Adapter adapter2;

    PaoQiList_Adapter paoQiAdapter3;

    private long mHour = 02;
    private long mMin = 15;
    private long mSecond = 36;
    private boolean isRun = true;
    String[] all;

    public PopupWindow popupwindow;//广告弹框


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    @Override
    protected HomeFragmentPresenter initPresenter() {
        return new HomeFragmentPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);


//        gonggao.setText(14, 2, Color.parseColor("#000000"));//设置属性,具体跟踪源码
//        gonggao.setTextStillTime(2000);//设置停留时长间隔
//        gonggao.setAnimTime(200);//设置进入和退出的时间间隔

        //数据适配器
        dataadpter();
        banner.post(new Runnable() {
            @Override
            public void run() {
                banner.getWidth();
                double f = Float.valueOf(banner.getWidth() + "") / (350 / 150);
                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(banner.getWidth(), (int) f);
                banner.setLayoutParams(layoutParams);
            }
        });


        //刷新数据
        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                presenter.getHomeData();//下载首页数据

            }
        });

    }


    /**
     * 数据适配器
     */
    private void dataadpter() {
        //限时折扣
        adapter1 = new XianShiList_Adapter(getActivity());
        final GridLayoutManager manager1 = new GridLayoutManager(getActivity(), 1);
        recyclerv1.setLayoutManager(manager1);
//        recyclerv1.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(getActivity(), 3)));
//        recyclerv1.addItemDecoration(new SpaceItemDecoration(0, -30));
        recyclerv1.setNestedScrollingEnabled(false);
        recyclerv1.setHasFixedSize(true);
        recyclerv1.setAdapter(adapter1);
        //适配器的点击事件适配器要这样写
        adapter1.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                MoveAbooutActivity_1.startSelf(getActivity(), getDiscount.get(position).getGoods_id(), getDiscount.get(position).getSearch_attr());

            }
        });
        //品牌展示
        adapter2 = new PinpaiList_Adapter(getActivity());
        final GridLayoutManager manager2 = new GridLayoutManager(getActivity(), 2);
        manager2.setOrientation(GridLayoutManager.HORIZONTAL);
        recyclerv2.setLayoutManager(manager2);
        recyclerv2.setNestedScrollingEnabled(false);
        recyclerv2.setHasFixedSize(true);
        recyclerv2.setAdapter(adapter2);
        adapter2.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {//跳入品牌列表页面
                CommodityActivity.startSelf(getContext(), getBrnad.get(position).getBrand_id());
            }
        });


        //抛期专区
        paoQiAdapter3 = new PaoQiList_Adapter(getActivity());
        final GridLayoutManager manager3 = new GridLayoutManager(getActivity(), 1);
        recyclerPaoqi.setLayoutManager(manager3);
        recyclerPaoqi.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(getActivity(), 0)));
        recyclerPaoqi.addItemDecoration(new SpaceItemDecoration(0, 0));
        recyclerPaoqi.setNestedScrollingEnabled(false);
        recyclerPaoqi.setHasFixedSize(true);
        recyclerPaoqi.setAdapter(paoQiAdapter3);


    }

    @Override
    protected void loadData() {
        presenter.getHomeData();//下载首页数据
    }

    @Override
    public void onClickCheckLogin(View v) {

    }

    @OnClick({R.id.home_serachview, R.id.xianshi_title_img, R.id.paoqi_move_xianshi, R.id.pinpai_title_img, R.id.paoqi_move_pinpai, R.id.home_product})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.home_serachview://搜索框
                SearchActivity.startSelf(getContext());
                break;
            case R.id.xianshi_title_img://限时Title--查看更多
                LimitedActivity.startSelf(getContext());
                break;
//            case R.id.paoqi_move_xianshi://限时列表
//                LimitedActivity.startSelf(getContext());
//                break;
            case R.id.pinpai_title_img://品牌Title--查看更多
                BrandActivity.startSelf(getContext());
                break;
//            case R.id.paoqi_move_pinpai://品牌列表
//                BrandActivity.startSelf(getContext());
//                break;
            case R.id.home_product:// 活动
//                ProductDetailsActivity.startSelf(getContext());
                //type--1：商品详情；2：活动详情；3：url;4:文字；5：商品列表
                if (getIndex_ad.getType().equals("1")) {//1：商品详情
                    MoveAbooutActivity_1.startSelf(getActivity(), getIndex_ad.getList().getGoods_id(), getIndex_ad.getList().getSearch_attr());
                } else if (getIndex_ad.getType().equals("2")) {//2：活动详情
                    ProductDetailsActivity.startSelf(getContext(), getIndex_ad.getList().getActive_id());//进入活动详情页面
                } else if (getIndex_ad.getType().equals("3")) {//3：url
                    WebActivity.startSelf(getActivity(), getIndex_ad.getList().getUrl());
                } else if (getIndex_ad.getType().equals("4")) {//4：文字
                } else if (getIndex_ad.getType().equals("5")) {//5：广告商品列表
                    RecommendActivity.startSelf(getContext(), "", getIndex_ad.getList().getId());//进入活动详情页面
                }


                break;
        }
    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }

    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(HomeRefreshDataEvent event) {
        Log.e("HomeFragment", "=首页传递消息==");
        Boolean getRefresh = event.getRefresh();
//        if (getRefresh) {
        presenter.getHomeData();//下载首页数据
//        }
    }

    //接收消息---从H5页面进入程序
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(StratMoveAbooutActivity_1 event) {
        Log.e("HomeFragment", "=从H5页面进入程序==");
        Log.e("HomeFragment", "=event.getGood_id()==" + event.getGood_id());

        MoveAbooutActivity_1.startSelf(getActivity(), event.getGood_id(), event.getSearch_attr());

//        }
    }


//    //开始滚动
//    @Override
//    public void onResume() {
//        super.onResume();
//        if (titleList != null) {
//            gonggao.startAutoScroll();
//        }
//
//    }
//
//    //停止滚动
//    @Override
//    public void onPause() {
//        super.onPause();
//        if (titleList != null) {
//            gonggao.stopAutoScroll();
//        }
//
//    }


    /**
     * 下载版本更新
     *
     * @param code
     * @param bean
     */
    @Override
    public void getAppUpdateSuccess(int code, SignBean bean) {
        if (bean.getVersion() != null && !TextUtils.isEmpty(bean.getVersion().getUrl())) {
            if (SPAppUpdateUtils.instance().isShouldUpdate1()) {//大于一天时间
                Log.e("getAppUpdateSuccess", "updateTime===" + "大于一天时间了");
                if (bean.getVersion().getMust() == 2) {//1：最新版本；2：强制更新；3：提示更新；4：手动更新
                    AppUpdateReceiver.send(bean.getVersion());
                } else if (bean.getVersion().getMust() == 3) {//1：最新版本；2：强制更新；3：提示更新；4：手动更新
                    AppUpdateReceiver.send(bean.getVersion());
                } else {
                    if (getAlert_ad.getId().equals("") || getAlert_ad.getId() == null) {//无广告
                    } else {//广告弹框
                        if (SPAppUpdateUtils.instance().isShouldUpdate1_1()) {//大于一天时间
                            if (popupwindow != null && popupwindow.isShowing()) {
                                popupwindow.dismiss();
                                return;
                            } else {
                                initmPopupWindowView(getAlert_ad.getPhoto(), getAlert_ad.getList().getUrl());
                                popupwindow.showAtLocation(getActivity().getWindow().getDecorView(), Gravity.CENTER, 0, 0);
                            }
                        }
                    }
                }
            }
            String userInfoJson = new Gson().toJson(bean);
            SPUtils.getInstance().save(Constant.KEY_SIGN_BEAN, userInfoJson);//保存保本号

        }

    }

    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(GuangGaoEvent event) {
        Log.e("HomeFragment", "=首页传递消息==");
        Boolean getRefresh = event.getRefresh();
//        if (getRefresh) {
        if (SPAppUpdateUtils.instance().isShouldUpdate1_1()) {//大于一天时间
            if (popupwindow != null && popupwindow.isShowing()) {
                popupwindow.dismiss();
                return;
            } else {
                if (getAlert_ad.getId().equals("") || getAlert_ad.getId() == null) {//无广告
                } else {//广告弹框
                    initmPopupWindowView(getAlert_ad.getPhoto(), getAlert_ad.getList().getUrl());
                    popupwindow.showAtLocation(getActivity().getWindow().getDecorView(), Gravity.CENTER, 0, 0);
                }
            }
        }
//        }
    }

    /**
     * 广告弹框
     * getFeeMsg1,getMobile1, getFeeMsg2,getMobile2
     */
    public void initmPopupWindowView(String img, String url) {
        Log.e("广告弹框", "initmPopupWindowView===img=" + img);
        Log.e("广告弹框", "initmPopupWindowView===url=" + url);
        ImageView dialog_update_img, dialog_update_close;
        // // 获取自定义布局文件pop.xml的视图
        View customView = getLayoutInflater().inflate(R.layout.dialog_update_1, null, false);
        dialog_update_img = customView.findViewById(R.id.dialog_update_img);//图片
        dialog_update_close = customView.findViewById(R.id.dialog_update_close);//关闭

        // 创建PopupWindow实例,先宽度，后高度
        popupwindow = new PopupWindow(customView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        // 设置动画效果 [R.style.AnimationFade 是自己事先定义好的]
        popupwindow.setAnimationStyle(R.style.DialogWindowStyle);
        // 自定义view添加触摸事件
        customView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
                return false;
            }
        });
        Matrix matrix = new Matrix();           //创建一个单位矩阵
        matrix.setTranslate(0, 0);          //平移x和y各100单位
        matrix.preRotate(0);                   //顺时针旋转30度
        dialog_update_img.setScaleType(ImageView.ScaleType.MATRIX);
        dialog_update_img.setImageMatrix(matrix);
        ImageLoader.image(getActivity(), dialog_update_img, img);

        //关闭
        dialog_update_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupwindow.dismiss();
                final SPAppUpdateUtils utils = SPAppUpdateUtils.instance();
                utils.setIgnore1();
            }
        });

        //跳转广告
        dialog_update_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupwindow.dismiss();
                WebActivity.startSelf(getActivity(), url);
                final SPAppUpdateUtils utils = SPAppUpdateUtils.instance();
                utils.setIgnore1();
            }
        });


    }


    /**
     * 数据时间返回失败
     *
     * @param code
     * @param
     */
    @Override
    public void getAppUpdateFail(int code, String msg) {

    }


    /**
     * 首页数据返回成功
     *
     * @param code
     * @param
     */
    @Override
    public void getHomeDataSuccess(int code, HomeDataBean data) {
        smartRefreshLayout.finishRefresh();
        long dataTime = 0;
        getDiscount = data.getDiscount();//限时
        if (getDiscount.size() == 0) {
            xianshiTitleImg.setVisibility(View.GONE);
            recyclerv1.setVisibility(View.GONE);
        } else {
            xianshiTitleImg.setVisibility(View.VISIBLE);
            recyclerv1.setVisibility(View.VISIBLE);
//            Glide.with(getActivity()).load(data.getDiscount_img()).into(xianshiTitleImg);
            ImageLoader.image(getActivity(), xianshiTitleImg, data.getDiscount_img());
        }
        adapter1.setData(getDiscount);//限时

        for (int i = 0; i < getDiscount.size(); i++) {
            int startDate = Integer.parseInt(getDiscount.get(i).getPromote_start_date());
            int endDate = Integer.parseInt(getDiscount.get(i).getPromote_end_date());
            dataTime = endDate - startDate;
//            dt = getDiscount.get(i).getSurplus_time();
            dt = Integer.valueOf(getDiscount.get(i).getSurplus_time());
        }

        getIndex_ad = data.getIndex_ad();
        //会员入口
        if (getIndex_ad.getId().equals("") || getIndex_ad.getId() == null) {
            homeProduct.setVisibility(View.GONE);
        } else {
            homeProduct.setVisibility(View.VISIBLE);
            ImageLoader.image(getActivity(), homeProduct, getIndex_ad.getPhoto());
            Matrix matrix = new Matrix();           //创建一个单位矩阵
            matrix.setTranslate(0, 0);          //平移x和y各100单位
            matrix.preRotate(0);                   //顺时针旋转30度
            homeProduct.setScaleType(ImageView.ScaleType.MATRIX);
            homeProduct.setImageMatrix(matrix);

        }

        //会员入口
        homeProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getIndex_ad.getType().equals("1")) {
                    MoveAbooutActivity_1.startSelf(getActivity(), getIndex_ad.getList().getGoods_id(), getIndex_ad.getList().getSearch_attr());
                } else if (getIndex_ad.getType().equals("2")) {
                    ProductDetailsActivity.startSelf(getContext(), getIndex_ad.getList().getActive_id());//进入活动详情页面
                } else if (getIndex_ad.getType().equals("3")) {
                    WebActivity.startSelf(getActivity(), getIndex_ad.getList().getUrl());
                } else if (getIndex_ad.getType().equals("4")) {

                } else if (getIndex_ad.getType().equals("5")) {
                    RecommendActivity.startSelf(getContext(), "", getIndex_ad.getList().getId());//商品列表
                } else if (getIndex_ad.getType().equals("6")) {

                    if (!UserUtils.getInstance().getUserId().equals("")) {
                        MemberActivity.startSelf(getContext(), "2");//会员购买入口
                    } else {
                        Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        getAlert_ad = data.getAlert_ad();//广告弹框

        //计算秒杀倒计时---ms
        handler.sendEmptyMessageDelayed(0, 1000);

//        String time = TransitionTime.secToTime(dt);
//        all = time.split(":");
//        Log.e("", "==all==" + all);

//        Glide.with(getActivity()).load(data.getBrand_img()).into(pinpaiTitleImg);
        ImageLoader.image(getActivity(), pinpaiTitleImg, data.getBrand_img());

//        mHour = Long.parseLong(all[0]);
//        mMin = Long.parseLong(all[1]);
//        mSecond = Long.parseLong(all[2]);
        bannerImage = data.getBanner();//轮播
        getArtcle = data.getArtcle();//公告
        getShop = data.getShop();//抛期
        paoQiAdapter3.setData(getShop);//抛期
        getBrnad = data.getBrand().get(0);//品牌

        List<HomeDataBean.BrandBean> getBrnad2 = data.getBrand().get(1);//品牌


        for (int i = 0; i < getBrnad2.size(); i++) {
            getBrnad.add(getBrnad2.get(i));
        }

        Log.e("getBrnad", "===getBrnad.size===" + getBrnad.size());
        adapter2.setData(getBrnad);//品牌


        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        banner.setImages(gatBannetData());
        //设置指示器位置（当banner模式中有指示器时）
        banner.setIndicatorGravity(BannerConfig.CENTER);
        //设置内置样式，共有六种可以点入方法内逐一体验使用。
//        banner.setBannerStyle(BannerConfig.NUM_INDICATOR);
//        //设置轮播的动画效果，内含多种特效，可点入方法内查找后内逐一体验
//        banner.setBannerAnimation(Transformer.Default);
        //banner设置方法全部调用完毕时最后调用
        banner.start();
        banner.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int position) {
//                bannerImage.size()
                Log.e("banner", "==position==");
                Log.e("banner", "==position==" + position);
                Log.e("banner", "==position==" + bannerImage.get(position).getId());
                Log.e("banner", "==getType==" + bannerImage.get(position).getType());
                Log.e("banner", "==position==" + bannerImage.get(position).getPhoto());
                SharedPreferences spf = getActivity().getSharedPreferences("user", Context.MODE_PRIVATE);
                spf.edit().putString("dataid", dataId).commit();


                //type--1：商品详情；2：活动详情；3：url;4:文字；5：商品列表
                if (bannerImage.get(position).getType().equals("1")) {//1：商品详情
                    MoveAbooutActivity_1.startSelf(getActivity(), bannerImage.get(position).getList().getGoods_id(), bannerImage.get(position).getList().getSearch_attr());
                } else if (bannerImage.get(position).getType().equals("2")) {//2：活动详情
                    ProductDetailsActivity.startSelf(getContext(), bannerImage.get(position).getList().getActive_id());//进入活动详情页面
                } else if (bannerImage.get(position).getType().equals("3")) {//3：url
                    WebActivity.startSelf(getActivity(), bannerImage.get(position).getList().getUrl());

                } else if (bannerImage.get(position).getType().equals("4")) {//4：文字

                } else if (bannerImage.get(position).getType().equals("5")) {//5：广告商品列表
                    RecommendActivity.startSelf(getContext(), "", bannerImage.get(position).getList().getId());//进入活动详情页面
                } else if (bannerImage.get(position).getType().equals("6")) {//6：会员入口
                    MemberActivity.startSelf(getContext(), "2");//
                }

            }
        });

        Log.e("getArtcle", "==getArtcle.size()==" + getArtcle.size());
        if (getArtcle.size() > 0) {
            viewFlipper.setVisibility(View.VISIBLE);
            titleList = new ArrayList<>();
            for (int i = 0; i < getArtcle.size(); i++) {
                titleList.add(getArtcle.get(i).getTitle());
            }
            for (int i = 0; i < titleList.size(); i++) {
                LinearLayout linearLayout = new LinearLayout(getActivity());
                linearLayout.setOrientation(LinearLayout.VERTICAL);
                linearLayout.setPadding(10, 10, 10, 10);
                TextView textView1 = new TextView(getActivity());
                textView1.setText(titleList.get(i));
                linearLayout.addView(textView1);
                viewFlipper.addView(linearLayout);
                int finalI = i;
                viewFlipper.getCurrentView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        WebActivity.startSelf(getActivity(), getArtcle.get(finalI).getInfo_url());

                    }
                });
            }
        } else {
            viewFlipper.setVisibility(View.GONE);
        }


//        gonggao.setTextList((ArrayList<String>) titleList);//加入显示内容,集合类型
//        gonggao.startAutoScroll();
//        //对单条文字的点击监听
//        gonggao.setOnItemClickListener(new VerticalTextview.OnItemClickListener() {
//            @Override
//            public void onItemClick(int position) {
//                // TO DO
////                Toast.makeText(getActivity(), titleList.get(position), Toast.LENGTH_SHORT).show();
//                WebActivity.startSelf(getActivity(), getArtcle.get(position).getInfo_url());
//            }
//        });
        presenter.getAppUpdate();//下载更新


    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            dt = dt - 1;
//            SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
//            String time = format.format(new Date(dt));

            String hourss;
            String minutess;
            String secondss;
            long hours = dt / (60 * 60);
            long minutes = (dt / 60) % 60;
            long seconds = dt % 60;
            hourss = String.valueOf(hours);
            minutess = String.valueOf(minutes);
            secondss = String.valueOf(seconds);

            if (hours < 10) {
                hourss = "0" + hours;
            }
            if (minutes < 10) {
                minutess = "0" + minutes;
            }
            if (seconds < 10) {
                secondss = "0" + seconds;
            }
//            Log.e("倒计时--首页--", "seconds====" + secondss);
            //设置倒计时
            adapter1.setDatas(hourss + ":" + minutess + ":" + secondss);
            adapter1.notifyDataSetChanged();

            handler.removeMessages(0);
            handler.sendEmptyMessageDelayed(0, 1000);
            if (dt <= 0) {
                handler.removeCallbacksAndMessages(null);
            }
        }
    };


    public List<String> gatBannetData() {
        List<String> strings = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < bannerImage.size(); i++) {
            ids.add(bannerImage.get(i).getId());
            strings.add(bannerImage.get(i).getPhoto());
        }
        SharedPreferences spf = getActivity().getSharedPreferences("user", Context.MODE_PRIVATE);
        spf.edit().putString("dataid", dataId).commit();
        return strings;
    }


    /**
     * 首页数据返回失败
     *
     * @param code
     * @param
     */
    @Override
    public void getHomeDataFail(int code, String msg) {
        smartRefreshLayout.finishRefresh();
    }


    /*定义的适配器*/
    public class ViewPagerAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public void destroyItem(ViewGroup view, int position, Object object) {
            // TODO Auto-generated method stub
//          super.destroyItem(container, position, object);
//          view.removeView(view.getChildAt(position));
//          view.removeViewAt(position);
            view.removeView(images.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup view, int position) {
            // TODO Auto-generated method stub
            view.addView(images.get(position));
            return images.get(position);
        }

    }


    @Override
    public void onStop() {
        // TODO Auto-generated method stub
        super.onStop();
        if (scheduledExecutorService != null) {
            scheduledExecutorService.shutdown();
            scheduledExecutorService = null;
        }
    }

}
