package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.bean.MemberBean;
import com.jealook.www.surface.mvp.presenter.MemberCompletePresenter;
import com.jealook.www.surface.mvp.view.MemberCompleteView;
import com.jealook.www.utils.CacheActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @Description:会员购买成功--结果
 * @Time:2020/8/19$
 * @Author:pk$
 */
public class MemberCompleteActivity extends BaseActivity<MemberCompletePresenter> implements MemberCompleteView {

    @BindView(R.id.member_time_expire)
    TextView memberTimeExpire;
    @BindView(R.id.member_return_btn)
    TextView memberReturnBtn;

    static String channel;//渠道；1==详情页面

    public static void startSelf(Context context, String channels) {
        Intent intent = new Intent(context, MemberCompleteActivity.class);
        context.startActivity(intent);
        channel = channels;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_member_complete;
    }

    @Override
    protected MemberCompletePresenter initPresenter() {
        return new MemberCompletePresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);

    }

    @Override
    protected void loadData() {
        presenter.getMemberDetailData();//会员详情
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @OnClick(R.id.member_return_btn)
    public void onViewClicked() {//返回
        if (channel.equals("1")) {//详情页面
            finish();
//            CacheActivity.finishSingleActivityByClass(PayMemberActivity.class);
//            CacheActivity.finishSingleActivityByClass(MemberActivity.class);
            CacheActivity.finishActivity();

        }
    }

    /**
     * @Description:会员详情-成功
     * @Time:2020/8/19 15:36
     * @Author:pk
     */
    @Override
    public void getMemberDetailSuccess(int code, MemberBean data) {
        memberTimeExpire.setText("会员到期时间：" + data.getUsers().getMember_end_time());

    }

    /**
     * @Description:会员详情-失败
     * @Time:2020/8/19 15:36
     * @Author:pk
     */
    @Override
    public void getMemberDetailFail(int code, String msg) {

    }
}
