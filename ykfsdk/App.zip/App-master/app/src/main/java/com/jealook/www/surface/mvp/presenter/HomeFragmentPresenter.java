package com.jealook.www.surface.mvp.presenter;


import android.util.Log;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.http.RequestBackListener;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.surface.mvp.model.MainRequest;
import com.jealook.www.surface.mvp.view.HomeFragmentView;
import com.jealook.www.utils.UserInfoBean;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/3/7
 */
public class HomeFragmentPresenter extends MvpPresenter<HomeFragmentView> {

    public void getHomeData() {
        addToRxLife(MainRequest.getHomeindex(new RequestBackListener<HomeDataBean>() {
            @Override
            public void onStart() {
//                showLoading();
            }

            @Override
            public void onSuccess(int code, HomeDataBean data) {
                if (isAttachView())
                    getBaseView().getHomeDataSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getHomeDataFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {
                Log.e("getHomeData","===Throwable=="+e);

            }

            @Override
            public void onFinish() {
//                dismissLoading();
            }
        }));
    }


    public void getAppUpdate() {
        addToRxLife(MainRequest.getAppUpdate( new RequestBackListener<SignBean>() {
            @Override
            public void onStart() {
//                showLoading();
            }

            @Override
            public void onSuccess(int code, SignBean data) {
                if (isAttachView())
                    getBaseView().getAppUpdateSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getAppUpdateFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onFinish() {
//                dismissLoading();
            }
        }));
    }
}
