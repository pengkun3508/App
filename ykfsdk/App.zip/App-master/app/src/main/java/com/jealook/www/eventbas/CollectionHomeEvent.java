package com.jealook.www.eventbas;

import com.dm.lib.core.eventbas.BaseEvent;

/**
 * 描述：点击收藏刷新列表
 *
 * @author Yanbo
 * @date 2019/4/1
 */
public class CollectionHomeEvent extends BaseEvent {

}
