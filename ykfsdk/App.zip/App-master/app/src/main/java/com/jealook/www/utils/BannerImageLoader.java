package com.jealook.www.utils;

import android.content.Context;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.jealook.www.R;
import com.youth.banner.loader.ImageLoader;

/**
 * 描述：轮播的图片展示
 *
 * @author Yanbo
 * @date 18/9/11
 */
public class BannerImageLoader extends ImageLoader {

    @Override
    public void displayImage(Context context, Object path, ImageView imageView) {
        Glide.with(context).load(path).apply(RequestOptions.errorOf(R.mipmap.default_img)
                .placeholder(R.mipmap.default_img)).into(imageView);
    }
}
