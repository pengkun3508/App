package com.jealook.www.surface.bean;

/**
 * Created by :方燚
 * Time       :2018/5/25.
 * Description:
 */

public class DetailsBean {
    private int type;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

}
