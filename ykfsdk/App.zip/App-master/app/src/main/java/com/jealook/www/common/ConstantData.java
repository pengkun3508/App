package com.jealook.www.common;

/**
 * @Description:
 * @Time:2020/5/14$
 * @Author:pk$
 */
public class ConstantData {

    /**
     * 微信支付
     */
    public static String APP_ID = "";

    /**
     * 支付渠道
     */
    public static String CHANNEL = "";//1==购买会员；2==购买商品
    /**
     * 一键登录手机号
     */
    public static String Number_Phone = "";
}
