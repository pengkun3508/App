package com.jealook.www.event;

import com.dm.lib.core.eventbas.BaseEvent;
import com.jealook.www.surface.bean.ConfirmOrderBean;

/**
 * @Description:
 * @Time:2020/5/29$
 * @Author:pk$
 */
public class CouponEvent extends BaseEvent {

    String type_Id;
    String str;
    ConfirmOrderBean data;

    public CouponEvent(String type_Ids, String strs, ConfirmOrderBean datas) {
        // TODO Auto-generated constructor stub
        type_Id = type_Ids;
        str = strs;
        data = datas;
    }

    public String getType_Id() {
        return type_Id;
    }

    public String getManJianStr() {
        return str;
    }

    public ConfirmOrderBean getData() {
        return data;
    }

}
