package com.jealook.www.eventbas;

import com.dm.lib.core.eventbas.BaseEvent;

/**
 * 描述：评定
 *
 * @author Yanbo
 * @date 2019/4/1
 */
public class UserGradeEvent extends BaseEvent {

    public UserGradeEvent(){}
}
