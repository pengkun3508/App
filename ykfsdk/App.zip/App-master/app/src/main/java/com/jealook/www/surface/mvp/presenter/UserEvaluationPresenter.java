package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.StartView;
import com.jealook.www.surface.mvp.view.UserEvaluationView;

public class UserEvaluationPresenter extends MvpPresenter<UserEvaluationView> {
}
