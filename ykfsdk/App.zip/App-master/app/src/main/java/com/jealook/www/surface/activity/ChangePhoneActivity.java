package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.mvp.presenter.ChangePhonePresenter;
import com.jealook.www.surface.mvp.view.ChangePhoneView;

import butterknife.OnClick;


/**
     * @Description:更换手机号
     * @Time:2020/4/14 9:40
     * @Author:pk
     */
public class ChangePhoneActivity extends BaseActivity<ChangePhonePresenter> implements ChangePhoneView {

    public static void startSelf(Context context) {
        Intent intent = new Intent(context, ChangePhoneActivity.class);
        context.startActivity(intent);
    }
    @Override
    protected int getLayoutId() {
        return R.layout.activity_change_phone;
    }

    @Override
    protected ChangePhonePresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
    }

    @Override
    protected void loadData() {

    }

    @OnClick({R.id.tv_ok})
    @Override
    public void onClick(View v) {
        super.onClick(v);
    }

    @Override
    public boolean onClickWithoutLogin(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.tv_ok:
                BindPhoneActivity.startSelf(getContext());
                break;

        }
        return false;
    }
}
