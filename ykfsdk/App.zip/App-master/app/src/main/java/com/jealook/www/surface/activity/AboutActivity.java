package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.mvp.presenter.AboutPresenter;
import com.jealook.www.surface.mvp.view.AboutView;
import com.jealook.www.widgat.actionbar.ActionBarSimple;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AboutActivity extends BaseActivity<AboutPresenter> implements AboutView {

    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.view_lin)
    View viewLin;

    public static void startSelf(Context context) {
        Intent intent = new Intent(context, AboutActivity.class);
        context.startActivity(intent);



    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_about;
    }

    @Override
    protected AboutPresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        viewLin.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

    }

    @Override
    protected void loadData() {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }
}
