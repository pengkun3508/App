package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.ClassFragmentView;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/3/7
 */
public class ClassFragmentPresenter extends MvpPresenter<ClassFragmentView> {


}
