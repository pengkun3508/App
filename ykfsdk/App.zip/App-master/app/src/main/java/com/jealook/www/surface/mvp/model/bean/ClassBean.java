package com.jealook.www.surface.mvp.model.bean;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/3/30
 */
public class ClassBean {

    /**
     * id : 1
     * name : 一班
     * img :
     * count : 1
     */

    private String id;
    private String name;
    private String img;
    private String count;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
