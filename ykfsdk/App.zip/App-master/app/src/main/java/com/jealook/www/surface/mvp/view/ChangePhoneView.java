package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019-12-24
 */
public interface ChangePhoneView extends MvpView {
}
