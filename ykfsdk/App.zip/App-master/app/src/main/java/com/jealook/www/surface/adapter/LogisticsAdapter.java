package com.jealook.www.surface.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.surface.bean.OrderLogisticsBean;

public class LogisticsAdapter extends BaseStateAdapter<OrderLogisticsBean.TracesBean, LogisticsAdapter.LogisticsHolder> {


    @Override
    protected LogisticsHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new LogisticsHolder(inflate(parent, R.layout.rv_item_logistics));
    }

    class LogisticsHolder extends BaseHolder<OrderLogisticsBean.TracesBean> {

        View view;
        ImageView ivImg;
        TextView item_time, item_content;

        LogisticsHolder(View itemView) {
            super(itemView);
            view = getView(R.id.view);
            ivImg = getView(R.id.iv_img);
            item_time = getView(R.id.item_time);
            item_content = getView(R.id.item_content);
        }

        @Override
        protected void bindData(OrderLogisticsBean.TracesBean data) {
            if (getAdapterPosition() == 0) {
                view.setVisibility(View.INVISIBLE);
            } else {
                view.setVisibility(View.VISIBLE);
            }
            item_time.setText(data.getAcceptTime());
            item_content.setText(data.getAcceptStation());

        }


    }
}