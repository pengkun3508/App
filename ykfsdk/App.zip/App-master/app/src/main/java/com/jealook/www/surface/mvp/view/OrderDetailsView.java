package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.AllOrderListBean;
import com.jealook.www.http.model.OrderDetailsBean;
import com.jealook.www.http.model.SiginOrderBean;
import com.jealook.www.http.model.VersionBean;

public interface OrderDetailsView extends MvpView {
    void getAppUpdateSuccess(int code, VersionBean version);

    void getAppUpdateFail(int code, String msg);

    void getOederDetailsSuccess(int code, OrderDetailsBean data);

    void getOederDetailsFail(int code, String msg);

    void getCelearOrderSuccess(int code, AllOrderListBean data);

    void getCelearOrderFail(int code, String msg);

    void getSignInOrderSuccess(int code, SiginOrderBean data);

    void getSignInOrderFail(int code, String msg);
}
