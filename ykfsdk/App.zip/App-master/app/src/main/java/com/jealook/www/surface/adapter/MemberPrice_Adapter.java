package com.jealook.www.surface.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.surface.bean.MemberBean;

/**
 * @Description:
 * @Time:2020/8/19$
 * @Author:pk$
 */
public class MemberPrice_Adapter extends BaseStateAdapter<MemberBean.ListBean, MemberPrice_Adapter.MemberPriceHolder> {

    Context context;
    int defItem;

    public MemberPrice_Adapter(Context context) {
        this.context = context;
    }


    //默认选中第一项
    public void setDefSelect(int position) {
        this.defItem = position;
        notifyDataSetChanged();
    }

    @Override
    protected MemberPriceHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new MemberPriceHolder(inflate(parent, R.layout.memberprice_item));
    }


    class MemberPriceHolder extends BaseHolder<MemberBean.ListBean> {

        LinearLayout member_item_bg;
        TextView member_name, member_price, member_original_price;


        MemberPriceHolder(View itemView) {
            super(itemView);
            member_item_bg = itemView.findViewById(R.id.member_item_bg);
            member_name = itemView.findViewById(R.id.member_name);
            member_price = itemView.findViewById(R.id.member_price);
            member_original_price = itemView.findViewById(R.id.member_original_price);
        }

        @Override
        protected void bindData(MemberBean.ListBean data) {
            member_original_price.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
            member_name.setText(data.getName());
            member_price.setText("￥" + data.getPrice());
            member_original_price.setText("￥" + data.getOriginal_price());
            if (defItem == getAdapterPosition()) {
                member_item_bg.setBackgroundResource(R.drawable.member_bg_1);
            } else {
                member_item_bg.setBackgroundResource(R.drawable.member_bg);
            }


        }


    }
}
