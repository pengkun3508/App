package com.jealook.www.surface.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.utils.DisplayInfoUtils;
import com.dm.lib.utils.ResUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.utils.UserInfoBean;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.common.Config;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.adapter.HomeTabAdapter;
import com.jealook.www.surface.dialog.TypeSelectDialog;
import com.jealook.www.surface.mvp.presenter.MoveAboutPresenter;
import com.jealook.www.surface.mvp.view.MoveAboutView;
import com.jealook.www.utils.GlideImageLoader;
import com.jealook.www.utils.MyScrollView;
import com.jealook.www.utils.SmartRefreshHelper;
import com.jealook.www.widgat.actionbar.MoveAboutBarSimple;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.listener.OnBannerListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @Description:商品详情页面
 * @Time:2020/4/2 14:53
 * @Author:pk
 */
public class MoveAboutActivity extends BaseActivity<MoveAboutPresenter> implements MoveAboutView {
    @BindView(R.id.action_bar)
    MoveAboutBarSimple actionBar;
    @BindView(R.id.banner)
    Banner banner;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;
    @BindView(R.id.move_youhuiquan_btn)
    RelativeLayout moveYouhuiquanBtn;
    @BindView(R.id.imageButton1)
    TextView imageButton1;
    @BindView(R.id.imageButton2)
    TextView imageButton2;
    @BindView(R.id.imageButton3)
    TextView imageButton3;
    //    @BindView(R.id.all_view)
//    View allView;
//    @BindView(R.id.ziying_view)
//    View ziyingView;
//    @BindView(R.id.hiatao_view)
//    View hiataoView;
//    @BindView(R.id.view_pager)
//    NoScrollViewPager viewPager;
    @BindView(R.id.move_shopcat_btn)
    LinearLayout moveShopcatBtn;
    @BindView(R.id.move_kefu_btn)
    LinearLayout moveKefuBtn;
    @BindView(R.id.move_shoucang_btn)
    LinearLayout moveShoucangBtn;
    @BindView(R.id.move_add_shopcat_btn)
    TextView moveAddShopcatBtn;
    @BindView(R.id.tv_move_about)
    TextView tvMoveAbout;
    @BindView(R.id.scroll_view)
    MyScrollView scrollView;
    @BindView(R.id.move_shoucang_img)
    ImageView moveShoucangImg;
    @BindView(R.id.title1)
    TextView title1;
    @BindView(R.id.title2)
    TextView title2;
    @BindView(R.id.title3)
    TextView title3;
    @BindView(R.id.title_bars)
    LinearLayout titleBar;
    @BindView(R.id.recyclerv_3)
    RecyclerView recyclerv3;
    private HomeTabAdapter adapter;
    private SmartRefreshHelper<String> mSmartRefreshHelper;
    String mark = "0";

    private Resources res;
    private float mRecyclerFactor;
    private int item1 = 0;
    private int item2 = 0;
    private int item3 = 0;
    private float totaldy;

    public static void startSelf(Activity context) {
        Intent intent = new Intent(context, MoveAboutActivity.class);
//        context.startActivity(intent);
        context.startActivityForResult(intent, 1);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_move_about;
    }

    @Override
    protected MoveAboutPresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
//        actionBar.getIvRight().setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                OnlineCustomerServiceActivity.startSelf(getContext());//社交页面
//            }
//        });
//        actionBar.getTvRight().setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        adapter = new HomeTabAdapter();
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setHasFixedSize(true);
        final int divider = (int) DisplayInfoUtils.getInstance().dp2px(5);
        RecyclerView.ItemDecoration gridItemDecoration = new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                GridLayoutManager layoutManager = (GridLayoutManager) parent.getLayoutManager();
                final GridLayoutManager.LayoutParams lp = (GridLayoutManager.LayoutParams) view.getLayoutParams();
                final int spanCount = layoutManager.getSpanCount();
                int layoutPosition = ((RecyclerView.LayoutParams) view.getLayoutParams()).getViewLayoutPosition();
                if (lp.getSpanSize() != spanCount) {
                    //左边间距
                    if (layoutPosition % 2 == 1) {
                        outRect.left = divider / 2;
                    } else {
                        outRect.right = divider / 2;
                    }
                }
                outRect.top = divider;
            }
        };
        recyclerView.addItemDecoration(gridItemDecoration);
        recyclerView.setAdapter(adapter);
//        mSmartRefreshHelper = SmartRefreshHelper.with(smartRefreshLayout, adapter)
//                .setPerPageCount(Config.ONE_PAGE_ITEM_MAX_COUNT_DEFAULT)
//                .init(new SmartRefreshHelper.RefreshCallback() {
//                    @Override
//                    public void doRequestData(int page) {
//                        mSmartRefreshHelper.onSuccess(2000, getData());
//
//                    }
//                });

        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        banner.setImages(getData());
        //设置指示器位置（当banner模式中有指示器时）
        banner.setIndicatorGravity(BannerConfig.RIGHT);
        //banner设置方法全部调用完毕时最后调用
        banner.start();
        banner.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int position) {

            }
        });


        initTitle();
        initListener();

    }


    private void initTitle() {
    }

    private void initListener() {

    }


    @Override
    protected void loadData() {
        mSmartRefreshHelper.requestFirstPage(false);

    }

    public List<String> getData() {
        List<String> strings = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            strings.add("1");
        }
        return strings;
    }

    @OnClick({R.id.tv_move_about})
    @Override
    public void onClick(View v) {
        super.onClick(v);
    }

    @Override
    public boolean onClickWithoutLogin(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.tv_move_about://购买
//                ConfirmOrderActivity.startSelf(getContext());
                break;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @OnClick({R.id.move_youhuiquan_btn, R.id.imageButton1, R.id.imageButton2, R.id.imageButton3, R.id.move_shopcat_btn, R.id.move_kefu_btn, R.id.move_shoucang_btn, R.id.move_add_shopcat_btn, R.id.tv_move_about})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.move_youhuiquan_btn://选择优惠券
                CouponActivity.startSelf(getContext());
                break;
            case R.id.imageButton1://商品详情
                break;
            case R.id.imageButton2://用户评价
                break;
            case R.id.imageButton3://用户须知
                break;
            case R.id.move_shopcat_btn://购物车
                setResult(10);
                finish();
                break;
            case R.id.move_kefu_btn://客服
//                OnlineCustomerServiceActivity.startSelf(getContext());//社交页面
                break;
            case R.id.move_shoucang_btn://收藏
                if (mark.endsWith("0")) {
                    mark = "1";
                    moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.shoucang_img1));
//                    moveShoucangImg.setBackgroundDrawable(getResources().getDrawable(R.mipmap.shoucang_img1));
                } else if (mark.endsWith("1")) {
                    mark = "0";
                    moveShoucangImg.setImageDrawable(ResUtils.getDrawable(R.mipmap.move_img1));
//                    moveShoucangImg.setBackgroundDrawable(getResources().getDrawable(R.mipmap.move_img1));
                }
                break;
            case R.id.move_add_shopcat_btn://加入购物车
//                TypeSelectDialog.with(getActivity()).show();
                break;
            case R.id.tv_move_about://购买
//                ConfirmOrderActivity.startSelf(getContext());
                break;
        }
    }

    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {

    }

    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    @Override
    public void getMoveDataSuccess(int code, MoveDataBean data) {

    }

    @Override
    public void getMoveDataFail(int code, String msg) {

    }

    @Override
    public void getCollectionShopSuccess(int code, Object data) {

    }

    @Override
    public void getCollectionShopFail(int code, String msg) {

    }

    @Override
    public void getAddShopCarSuccess(int code, Object data) {

    }

    @Override
    public void getAddShopCarFail(int code, String msg) {

    }

    @Override
    public void getMobileLoginSuccess(int code, UserInfoBean data) {

    }

    @Override
    public void getMobileLoginFail(int code, String msg) {

    }

    @Override
    public void getConfirmOrderSuccess(int code, ConfirmOrderBean data) {

    }

    @Override
    public void getConfirmOrderFail(int code, String msg) {

    }
}
