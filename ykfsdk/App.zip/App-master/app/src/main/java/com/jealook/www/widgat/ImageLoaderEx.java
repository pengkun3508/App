package com.jealook.www.widgat;

import android.content.Context;
import android.widget.ImageView;

import com.makeramen.roundedimageview.RoundedImageView;
import com.youth.banner.loader.ImageLoaderInterface;

public abstract class  ImageLoaderEx  implements ImageLoaderInterface<RoundedImageView> {

    @Override
    public RoundedImageView createImageView(Context context) {
        RoundedImageView imageView = new RoundedImageView(context);
        return imageView;
    }

}
