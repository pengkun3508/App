package com.jealook.www.surface.bean;

import per.goweii.rxhttp.request.base.BaseBean;

/**
 * @Description:
 * @Time:2020/5/12$
 * @Author:pk$
 */
public class PersonalInformationBean extends BaseBean {
    /**
     * user : {"img_url":"http://img.jealook.com/app_img/20200527/20200527140440_85957.jpg","sex":"男","user_name":"你是谁","user_id":"168","mobile":"15129005255","member_end_time":"1970-01-01","points":"0","sex_type":1,"is_member":0}
     * order_count : {"obligationcount":"0","pendingcount":"0","receivingcount":"0","commentcount":"0","replacementcount":"0"}
     * collect_count : 0
     * browse_count : 0
     * discount_count : 0
     * points : 0
     */

    private UserBean user;
    private OrderCountBean order_count;
    private String collect_count;
    private String browse_count;
    private String discount_count;
    private String points;

    public UserBean getUser() {
        return user;
    }

    public void setUser(UserBean user) {
        this.user = user;
    }

    public OrderCountBean getOrder_count() {
        return order_count;
    }

    public void setOrder_count(OrderCountBean order_count) {
        this.order_count = order_count;
    }

    public String getCollect_count() {
        return collect_count;
    }

    public void setCollect_count(String collect_count) {
        this.collect_count = collect_count;
    }

    public String getBrowse_count() {
        return browse_count;
    }

    public void setBrowse_count(String browse_count) {
        this.browse_count = browse_count;
    }

    public String getDiscount_count() {
        return discount_count;
    }

    public void setDiscount_count(String discount_count) {
        this.discount_count = discount_count;
    }

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }

    public static class UserBean {
        /**
         * img_url : http://img.jealook.com/app_img/20200527/20200527140440_85957.jpg
         * sex : 男
         * user_name : 你是谁
         * user_id : 168
         * mobile : 15129005255
         * member_end_time : 1970-01-01
         * points : 0
         * sex_type : 1
         * is_member : 0
         */

        private String img_url;
        private String sex;
        private String user_name;
        private String user_id;
        private String mobile;
        private String member_end_time;
        private String points;
        private int sex_type;
        private int is_member;

        public String getImg_url() {
            return img_url;
        }

        public void setImg_url(String img_url) {
            this.img_url = img_url;
        }

        public String getSex() {
            return sex;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }

        public String getUser_id() {
            return user_id;
        }

        public void setUser_id(String user_id) {
            this.user_id = user_id;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getMember_end_time() {
            return member_end_time;
        }

        public void setMember_end_time(String member_end_time) {
            this.member_end_time = member_end_time;
        }

        public String getPoints() {
            return points;
        }

        public void setPoints(String points) {
            this.points = points;
        }

        public int getSex_type() {
            return sex_type;
        }

        public void setSex_type(int sex_type) {
            this.sex_type = sex_type;
        }

        public int getIs_member() {
            return is_member;
        }

        public void setIs_member(int is_member) {
            this.is_member = is_member;
        }
    }

    public static class OrderCountBean {
        /**
         * obligationcount : 0
         * pendingcount : 0
         * receivingcount : 0
         * commentcount : 0
         * replacementcount : 0
         */

        private String obligationcount;
        private String pendingcount;
        private String receivingcount;
        private String commentcount;
        private String replacementcount;

        public String getObligationcount() {
            return obligationcount;
        }

        public void setObligationcount(String obligationcount) {
            this.obligationcount = obligationcount;
        }

        public String getPendingcount() {
            return pendingcount;
        }

        public void setPendingcount(String pendingcount) {
            this.pendingcount = pendingcount;
        }

        public String getReceivingcount() {
            return receivingcount;
        }

        public void setReceivingcount(String receivingcount) {
            this.receivingcount = receivingcount;
        }

        public String getCommentcount() {
            return commentcount;
        }

        public void setCommentcount(String commentcount) {
            this.commentcount = commentcount;
        }

        public String getReplacementcount() {
            return replacementcount;
        }

        public void setReplacementcount(String replacementcount) {
            this.replacementcount = replacementcount;
        }
    }
}
