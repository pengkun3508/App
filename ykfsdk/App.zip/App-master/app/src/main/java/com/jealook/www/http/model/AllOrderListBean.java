package com.jealook.www.http.model;

import java.util.List;

import per.goweii.rxhttp.request.base.BaseBean;

/**
 * @Description:
 * @Time:2020/5/8$
 * @Author:pk$
 */
public class AllOrderListBean extends BaseBean {
    /**
     * list : [{"order_id":"283","order_sn":"202004301139376716951921","order_status":"1","shipping_status":"0","pay_status":"0","goods_amount":"1620.20","order_amount":"1620.20","bonus":"0.00","shipping_fee":"0.00","status":1,"shop_list":[{"product_id":"20","goods_id":"1","goods_attr":"2|3|5042","color_id":"2","search_attr":"2|3","is_promote":"0","promote_start_date":"1586793600","promote_end_date":"1587052800","suppliers_id":"2","goods_name":"日本Angelcolor bambi series Natural 系列日抛型 Natural  Black 20枚","number":"10","product_price":"155.00","rec_id":"313","goods_attr_name":"Natural  Black,20枚,550度","goods_thumb":"http://img.jealook.com/backend/20200401/1585726474_6911.png"},{"product_id":"435","goods_id":"6","goods_attr":"134|153|160","color_id":"160","search_attr":"134|160","is_promote":"1","promote_start_date":"1586707200","promote_end_date":"1588262400","suppliers_id":"2","goods_name":"日本Artiral 日抛型 Artiral Brown 10枚","number":"1","product_price":"78.00","rec_id":"314","goods_attr_name":"10枚,550度,Artiral Brown","goods_thumb":"http://img.jealook.com/backend/20200401/1585726897_6100.png"}],"num":2}]
     * count : 1
     */

    private String count;
    private List<ListBean> list;

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * order_id : 283
         * order_sn : 202004301139376716951921
         * order_status : 1
         * shipping_status : 0
         * pay_status : 0
         * goods_amount : 1620.20
         * order_amount : 1620.20
         * bonus : 0.00
         * shipping_fee : 0.00
         * status : 1
         * shop_list : [{"product_id":"20","goods_id":"1","goods_attr":"2|3|5042","color_id":"2","search_attr":"2|3","is_promote":"0","promote_start_date":"1586793600","promote_end_date":"1587052800","suppliers_id":"2","goods_name":"日本Angelcolor bambi series Natural 系列日抛型 Natural  Black 20枚","number":"10","product_price":"155.00","rec_id":"313","goods_attr_name":"Natural  Black,20枚,550度","goods_thumb":"http://img.jealook.com/backend/20200401/1585726474_6911.png"},{"product_id":"435","goods_id":"6","goods_attr":"134|153|160","color_id":"160","search_attr":"134|160","is_promote":"1","promote_start_date":"1586707200","promote_end_date":"1588262400","suppliers_id":"2","goods_name":"日本Artiral 日抛型 Artiral Brown 10枚","number":"1","product_price":"78.00","rec_id":"314","goods_attr_name":"10枚,550度,Artiral Brown","goods_thumb":"http://img.jealook.com/backend/20200401/1585726897_6100.png"}]
         * num : 2
         */

        private String order_id;
        private String order_sn;
        private String order_status;
        private String shipping_status;
        private String pay_status;
        private String goods_amount;
        private String order_amount;
        private String bonus;
        private String shipping_fee;
        private int status;
        private int num;
        private List<ShopListBean> shop_list;

        public String getOrder_id() {
            return order_id;
        }

        public void setOrder_id(String order_id) {
            this.order_id = order_id;
        }

        public String getOrder_sn() {
            return order_sn;
        }

        public void setOrder_sn(String order_sn) {
            this.order_sn = order_sn;
        }

        public String getOrder_status() {
            return order_status;
        }

        public void setOrder_status(String order_status) {
            this.order_status = order_status;
        }

        public String getShipping_status() {
            return shipping_status;
        }

        public void setShipping_status(String shipping_status) {
            this.shipping_status = shipping_status;
        }

        public String getPay_status() {
            return pay_status;
        }

        public void setPay_status(String pay_status) {
            this.pay_status = pay_status;
        }

        public String getGoods_amount() {
            return goods_amount;
        }

        public void setGoods_amount(String goods_amount) {
            this.goods_amount = goods_amount;
        }

        public String getOrder_amount() {
            return order_amount;
        }

        public void setOrder_amount(String order_amount) {
            this.order_amount = order_amount;
        }

        public String getBonus() {
            return bonus;
        }

        public void setBonus(String bonus) {
            this.bonus = bonus;
        }

        public String getShipping_fee() {
            return shipping_fee;
        }

        public void setShipping_fee(String shipping_fee) {
            this.shipping_fee = shipping_fee;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public int getNum() {
            return num;
        }

        public void setNum(int num) {
            this.num = num;
        }

        public List<ShopListBean> getShop_list() {
            return shop_list;
        }

        public void setShop_list(List<ShopListBean> shop_list) {
            this.shop_list = shop_list;
        }

        public static class ShopListBean {
            /**
             * product_id : 20
             * goods_id : 1
             * goods_attr : 2|3|5042
             * color_id : 2
             * search_attr : 2|3
             * is_promote : 0
             * promote_start_date : 1586793600
             * promote_end_date : 1587052800
             * suppliers_id : 2
             * goods_name : 日本Angelcolor bambi series Natural 系列日抛型 Natural  Black 20枚
             * number : 10
             * product_price : 155.00
             * rec_id : 313
             * goods_attr_name : Natural  Black,20枚,550度
             * goods_thumb : http://img.jealook.com/backend/20200401/1585726474_6911.png
             */

            private String product_id;
            private String goods_id;
            private String goods_attr;
            private String color_id;
            private String search_attr;
            private String is_promote;
            private String promote_start_date;
            private String promote_end_date;
            private String suppliers_id;
            private String goods_name;
            private String number;
            private String product_price;
            private String rec_id;
            private String comment_id;
            private String goods_attr_name;

            public String getComment_id() {
                return comment_id;
            }

            public void setComment_id(String comment_id) {
                this.comment_id = comment_id;
            }

            private String goods_thumb;

            public String getProduct_id() {
                return product_id;
            }

            public void setProduct_id(String product_id) {
                this.product_id = product_id;
            }

            public String getGoods_id() {
                return goods_id;
            }

            public void setGoods_id(String goods_id) {
                this.goods_id = goods_id;
            }

            public String getGoods_attr() {
                return goods_attr;
            }

            public void setGoods_attr(String goods_attr) {
                this.goods_attr = goods_attr;
            }

            public String getColor_id() {
                return color_id;
            }

            public void setColor_id(String color_id) {
                this.color_id = color_id;
            }

            public String getSearch_attr() {
                return search_attr;
            }

            public void setSearch_attr(String search_attr) {
                this.search_attr = search_attr;
            }

            public String getIs_promote() {
                return is_promote;
            }

            public void setIs_promote(String is_promote) {
                this.is_promote = is_promote;
            }

            public String getPromote_start_date() {
                return promote_start_date;
            }

            public void setPromote_start_date(String promote_start_date) {
                this.promote_start_date = promote_start_date;
            }

            public String getPromote_end_date() {
                return promote_end_date;
            }

            public void setPromote_end_date(String promote_end_date) {
                this.promote_end_date = promote_end_date;
            }

            public String getSuppliers_id() {
                return suppliers_id;
            }

            public void setSuppliers_id(String suppliers_id) {
                this.suppliers_id = suppliers_id;
            }

            public String getGoods_name() {
                return goods_name;
            }

            public void setGoods_name(String goods_name) {
                this.goods_name = goods_name;
            }

            public String getNumber() {
                return number;
            }

            public void setNumber(String number) {
                this.number = number;
            }

            public String getProduct_price() {
                return product_price;
            }

            public void setProduct_price(String product_price) {
                this.product_price = product_price;
            }

            public String getRec_id() {
                return rec_id;
            }

            public void setRec_id(String rec_id) {
                this.rec_id = rec_id;
            }

            public String getGoods_attr_name() {
                return goods_attr_name;
            }

            public void setGoods_attr_name(String goods_attr_name) {
                this.goods_attr_name = goods_attr_name;
            }

            public String getGoods_thumb() {
                return goods_thumb;
            }

            public void setGoods_thumb(String goods_thumb) {
                this.goods_thumb = goods_thumb;
            }
        }
    }
}
