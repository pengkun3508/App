package com.jealook.www.surface.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.entity.LocalMedia;
import com.makeramen.roundedimageview.RoundedImageView;
import com.jealook.www.R;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.surface.activity.PhotoViewActivity;
import com.jealook.www.utils.DensityUtils;
import com.jealook.www.utils.ImageLoader;
import com.jealook.www.widgat.SpaceItemDecoration;
import com.jealook.www.widgat.SpacesItemDecoration;

import java.net.URISyntaxException;
import java.util.List;

/**
 * @Description:
 * @Time:2020/5/6$
 * @Author:pk$
 */
public class CommentListAdapter extends BaseStateAdapter<MoveDataBean.CommentBean, CommentListAdapter.CommentListHolder> {

    Context context;
    CommentImgAdapter commentAdapter;
    List<String> getImage;
    List<LocalMedia> selectList;

    public CommentListAdapter(Context context) {
        super();
        this.context = context;
    }


    @Override
    protected CommentListHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new CommentListHolder(inflate(parent, R.layout.comment_item));
    }

    class CommentListHolder extends BaseHolder<MoveDataBean.CommentBean> {

        RoundedImageView comment_img_head;
        TextView comment_name, comment_time, comment_type, comment_conten;
        RecyclerView comment_img_grid;

        CommentListHolder(View itemView) {
            super(itemView);
            comment_img_head = itemView.findViewById(R.id.comment_img_head);//头像
            comment_name = itemView.findViewById(R.id.comment_name);//名称
            comment_time = itemView.findViewById(R.id.comment_time);//时间
            comment_type = itemView.findViewById(R.id.comment_type);//规格类型
            comment_conten = itemView.findViewById(R.id.comment_conten);//规格类型
            comment_img_grid = itemView.findViewById(R.id.comment_img_grid);//图片List


        }

        @Override
        protected void bindData(MoveDataBean.CommentBean data) {

            commentAdapter = new CommentImgAdapter(context);
            final GridLayoutManager manager3 = new GridLayoutManager(context, 2);
            comment_img_grid.setLayoutManager(manager3);
            comment_img_grid.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(context, 1)));
            comment_img_grid.addItemDecoration(new SpaceItemDecoration(0, 0));
            comment_img_grid.setNestedScrollingEnabled(false);
            comment_img_grid.setHasFixedSize(true);
            comment_img_grid.setAdapter(commentAdapter);

            comment_img_head.setScaleType(ImageView.ScaleType.FIT_XY);
            ImageLoader.userIcon(context, comment_img_head, data.getImg_url());

            comment_name.setText(data.getUser_name());

            comment_time.setText(data.getAdd_time());
            comment_type.setText(data.getInfo());
            comment_conten.setText(data.getContent());


            Log.e("评论图片", "==评论图片==" + data);
            if (data.getImage().size() > 0) {
                getImage = data.getImage();
                comment_img_grid.setVisibility(View.VISIBLE);
                commentAdapter.setData(getImage);
                commentAdapter.notifyDataSetChanged();
            } else {
                comment_img_grid.setVisibility(View.GONE);
            }


            //点击图片，放大查看
            commentAdapter.addOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view, int position) {
                    PhotoViewActivity.startSelf((Activity) context,data.getImage(),position);

                }
            });


        }


    }
}

