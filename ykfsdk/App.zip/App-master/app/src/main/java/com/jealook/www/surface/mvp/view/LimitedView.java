package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.LimitedBean;
import com.jealook.www.http.model.VersionBean;

/**
 * @Description:
 * @Time:2020/4/14$
 * @Author:pk$
 */
public interface LimitedView extends MvpView {
    void getAppUpdateSuccess(int code, VersionBean version);

    void getAppUpdateFail(int code, String msg);


    void getLimiteSuccess(int code, LimitedBean limibean);

    void getLimiteFail(int code, String msg);

}
