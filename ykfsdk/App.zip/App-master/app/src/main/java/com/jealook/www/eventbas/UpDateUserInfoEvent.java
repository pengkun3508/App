package com.jealook.www.eventbas;

import com.dm.lib.core.eventbas.BaseEvent;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/4/10
 */
public class UpDateUserInfoEvent extends BaseEvent {

}
