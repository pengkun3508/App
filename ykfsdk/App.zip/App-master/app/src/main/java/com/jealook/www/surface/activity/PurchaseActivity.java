package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.dm.lib.utils.StatusBarUtils;
import com.flyco.tablayout.SlidingTabLayout;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.adapter.MyJourneyVPAdapter;
import com.jealook.www.surface.fragment.HomeTab1Fragment;
import com.jealook.www.surface.fragment.HomeTab2Fragment;
import com.jealook.www.surface.fragment.HomeTab3Fragment;
import com.jealook.www.surface.fragment.HomeTab4Fragment;
import com.jealook.www.surface.fragment.Purchase1Fragment;
import com.jealook.www.surface.mvp.presenter.PurchasePresenter;
import com.jealook.www.surface.mvp.view.PurchaseView;

import java.util.ArrayList;

import butterknife.BindView;

public class PurchaseActivity extends BaseActivity<PurchasePresenter> implements PurchaseView {


    @BindView(R.id.tl_1)
    SlidingTabLayout tl1;
    @BindView(R.id.view_pager)
    ViewPager viewPager;
    private ArrayList<Fragment> mFragments = new ArrayList<>();
    private final String[] mTitles = {"待付款", "进行中", "历史订单"};


    public static void startSelf(Context context) {
        Intent intent = new Intent(context, PurchaseActivity.class);
        context.startActivity(intent);
    }
    @Override
    protected int getLayoutId() {
        return R.layout.activity_purchase;
    }

    @Override
    protected PurchasePresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        mFragments.add(Purchase1Fragment.Purchase1Fragment(0));
        mFragments.add(Purchase1Fragment.Purchase1Fragment(1));
        mFragments.add(Purchase1Fragment.Purchase1Fragment(2));
        MyJourneyVPAdapter vp = new MyJourneyVPAdapter(getSupportFragmentManager(), mFragments);
        viewPager.setAdapter(vp);
        tl1.setViewPager(viewPager, mTitles);
        viewPager.setCurrentItem(0);
    }

    @Override
    protected void loadData() {

    }
}
