package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;

/**
 * 描述：
 *
 * @author yanbo
 * @date 2019-09-10
 */
public interface OrganizationAdminView extends MvpView {
}
