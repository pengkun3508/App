package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.OrganizationAdminView;

/**
 * 描述：
 *
 * @author yanbo
 * @date 2019-09-10
 */
public class OrganizationAdminPresenter extends MvpPresenter<OrganizationAdminView> {
}
