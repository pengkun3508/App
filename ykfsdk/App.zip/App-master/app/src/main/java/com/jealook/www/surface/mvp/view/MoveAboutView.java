package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.utils.UserInfoBean;

public interface MoveAboutView extends MvpView {


    void getAppUpdateSuccess(int code, VersionBean version);

    void getAppUpdateFail(int code, String msg);

    void getMoveDataSuccess(int code, MoveDataBean data);

    void getMoveDataFail(int code, String msg);


    void getCollectionShopSuccess(int code, Object data);

    void getCollectionShopFail(int code, String msg);

    void getAddShopCarSuccess(int code, Object data);

    void getAddShopCarFail(int code, String msg);

    void getMobileLoginSuccess(int code, UserInfoBean data);

    void getMobileLoginFail(int code, String msg);

    void getConfirmOrderSuccess(int code, ConfirmOrderBean data);

    void getConfirmOrderFail(int code, String msg);
}
