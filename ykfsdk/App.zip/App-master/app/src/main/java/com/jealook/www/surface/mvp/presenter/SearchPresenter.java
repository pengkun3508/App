package com.jealook.www.surface.mvp.presenter;

import android.util.Log;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.http.RequestBackListener;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.surface.bean.SearchListBean;
import com.jealook.www.surface.mvp.model.MainRequest;
import com.jealook.www.surface.mvp.view.PurchaseView;
import com.jealook.www.surface.mvp.view.SearchView;

public class SearchPresenter extends MvpPresenter<SearchView> {

    public void getSearchData() {
        addToRxLife(MainRequest.getSearchData(new RequestBackListener<SearchListBean>() {
            @Override
            public void onStart() {
//                showLoading();
            }

            @Override
            public void onSuccess(int code, SearchListBean data) {
                if (isAttachView())
                    getBaseView().getSearchDataSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getSearchDataFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onFinish() {
//                dismissLoading();
            }
        }));
    }
}
