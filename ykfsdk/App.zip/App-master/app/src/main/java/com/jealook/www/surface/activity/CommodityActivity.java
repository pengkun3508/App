package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.utils.CacheActivity;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.http.model.CommodityListBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.adapter.CommodityAdapter;
import com.jealook.www.surface.mvp.presenter.CommodityPresenter;
import com.jealook.www.surface.mvp.view.CommodityView;
import com.jealook.www.utils.DensityUtils;
import com.jealook.www.utils.SmartRefreshHelper;
import com.jealook.www.widgat.SpaceItemDecoration;
import com.jealook.www.widgat.SpacesItemDecoration;
import com.jealook.www.widgat.actionbar.ActionBarSimple;

import java.util.List;

import butterknife.BindView;

/**
 * @Description: 品牌列表进入的商品页面
 * @Time:2020/5/8$
 * @Author:pk$
 */
public class CommodityActivity extends BaseActivity<CommodityPresenter> implements CommodityView {


    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;
    CommodityAdapter adapter;
    private static String getBrand_id;

    private SmartRefreshHelper<CommodityListBean.ListBean> mSmartRefreshHelper;
    List<CommodityListBean.ListBean> listBean;

    int mark = 0;
    int page = 1;
    int lastItem = -1;
    int judge = 0;

    public static void startSelf(Context context, String getBrand_ids) {
        Intent intent = new Intent(context, CommodityActivity.class);
        context.startActivity(intent);
        getBrand_id = getBrand_ids;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_brand;
    }

    @Override
    protected CommodityPresenter initPresenter() {
        return new CommodityPresenter();
    }

    @Override
    protected void initView() {
        CacheActivity.addActivity(CommodityActivity.this);
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        adapter = new CommodityAdapter(this);
        final GridLayoutManager manager5 = new GridLayoutManager(getActivity(), 2);
        recyclerView.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(getActivity(), 0)));
        recyclerView.addItemDecoration(new SpaceItemDecoration(0, 0));
        recyclerView.setLayoutManager(manager5);
        recyclerView.setAdapter(adapter);




        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                presenter.getCommodityList(page, 10, getBrand_id);//下载商品详情数据
                judge = 0;
            }
        });


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
                int lastVisibleItem = manager.findLastCompletelyVisibleItemPosition();
                if (adapter.getData().size() - 5 == lastVisibleItem) {
                    if (lastItem != lastVisibleItem) {
                        lastItem = lastVisibleItem;
                        page++;
                        judge = 1;
                        presenter.getCommodityList(page, 10, getBrand_id);//下载商品详情数据
                    }
                } else {
                    if (adapter.getData().size() - lastItem > 10) {
                        lastItem = adapter.getData().size() - 5;
                        page++;
                        judge = 1;
                        presenter.getCommodityList(page, 10, getBrand_id);//下载商品详情数据
                    }
                }
            }
        });


        adapter.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                MoveAbooutActivity_1.startSelf(getActivity(), listBean.get(position).getGoods_id(), listBean.get(position).getSearch_attr());
            }
        });


    }

    @Override
    protected void loadData() {
//        presenter.getAppUpdate();//下载时间
        presenter.getCommodityList(page, 10, getBrand_id);//下载商品详情数据

    }

    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {


    }

    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    /**
     * @Description:下载列表数据成功
     * @Time:2020/5/8 17:34
     * @Author:pk
     */
    @Override
    public void getCommodityListSuccess(int code, CommodityListBean data) {
        listBean = data.getList();
        smartRefreshLayout.finishRefresh();

        if (judge == 0) {
            adapter.setData(data.getList());
        } else {
            adapter.addData(data.getList());
        }


    }

    /**
     * @Description:下载列表数据失败
     * @Time:2020/5/8 17:34
     * @Author:pk
     */
    @Override
    public void getCommodityListFail(int code, String msg) {
        Log.e("CommodityActivity", "==code==" + code);
//        if (code == 3000) {
//            CommodityListBean data = new CommodityListBean();
//            adapter.setData(data.getList());
//            presenter.dismissLoading();
//        }
    }
}
