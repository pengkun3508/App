package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.CommodityListBean;
import com.jealook.www.http.model.VersionBean;

/**
 * @Description:
 * @Time:2020/5/8$
 * @Author:pk$
 */
public interface CommodityView  extends MvpView {
    void getAppUpdateSuccess(int code, VersionBean version);

    void getAppUpdateFail(int code, String msg);

    void getCommodityListSuccess(int code, CommodityListBean data);

    void getCommodityListFail(int code, String msg);
}
