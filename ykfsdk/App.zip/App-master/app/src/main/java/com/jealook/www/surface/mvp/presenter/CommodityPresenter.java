package com.jealook.www.surface.mvp.presenter;

import android.util.Log;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.http.RequestBackListener;
import com.jealook.www.http.model.CommodityListBean;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.surface.mvp.model.MainRequest;
import com.jealook.www.surface.mvp.view.CommodityView;

/**
 * @Description:
 * @Time:2020/5/8$
 * @Author:pk$
 */
public class CommodityPresenter extends MvpPresenter<CommodityView> {
    public void getCommodityList(int page, int limit, String getBrand_id) {
        addToRxLife(MainRequest.getCommodityList(page, limit, getBrand_id, new RequestBackListener<CommodityListBean>() {
            @Override
            public void onStart() {
//                showLoading();
            }

            @Override
            public void onSuccess(int code, CommodityListBean data) {
                if (isAttachView())
                    getBaseView().getCommodityListSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getCommodityListFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onFinish() {
//                dismissLoading();
            }
        }));
    }
}
