package com.jealook.www.surface.fragment;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.utils.ResUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.flyco.roundview.RoundTextView;
import com.jealook.www.R;
import com.jealook.www.base.BaseFragment;
import com.jealook.www.event.ShopCarJudgeEvent;
import com.jealook.www.event.ShopTypeDataEvent;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.http.model.ShopCartListBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.activity.ConfirmOrderActivity;
import com.jealook.www.surface.activity.MoveAbooutActivity_1;
import com.jealook.www.surface.adapter.ShoppingCheAdapter;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.bean.ModifyTypeBean;
import com.jealook.www.surface.dialog.TypeSelectDialog;
import com.jealook.www.surface.mvp.presenter.VideonFragmentPresenter;
import com.jealook.www.surface.mvp.view.VideonFragmentView;
import com.jealook.www.utils.UserUtils;
import com.jealook.www.widgat.actionbar.ActionBarSimple;
import com.yanzhenjie.recyclerview.OnItemClickListener;
import com.yanzhenjie.recyclerview.OnItemLongClickListener;
import com.yanzhenjie.recyclerview.SwipeMenu;
import com.yanzhenjie.recyclerview.SwipeMenuCreator;
import com.yanzhenjie.recyclerview.SwipeMenuItem;
import com.yanzhenjie.recyclerview.SwipeRecyclerView;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;


/**
 * 描述：购物车
 *
 * @author Yanbo
 * @date 2019/3/6
 */
public class ShoppingCheFragment extends BaseFragment<VideonFragmentPresenter> implements VideonFragmentView {

    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.recyclerView)
    SwipeRecyclerView recyclerView;
    @BindView(R.id.iv_check_circle)
    ImageView ivCheckCircle;
    @BindView(R.id.rl_check_circle)
    RelativeLayout rlCheckCircle;
    @BindView(R.id.tv_total)
    TextView tvTotal;
    @BindView(R.id.tv_total1)
    TextView tvTotal1;
    @BindView(R.id.tv_settlement)
    TextView tvSettlement;
    @BindView(R.id.shop_ziying_btn)
    RadioButton shopZiyingBtn;
    @BindView(R.id.shop_haitao_btn)
    RadioButton shopHaitaoBtn;
    ShopCartListBean.ListBean listBean;
    @BindView(R.id.tab_unread_notify)
    TextView tabUnreadNotify;//自营数量
    @BindView(R.id.tab_unread_notify_1)
    TextView tabUnreadNotify1;//海淘数量
    @BindView(R.id.ziying_shop_view)
    View ziyingShopView;
    @BindView(R.id.haitao_shop_view)
    View haitaoShopView;
    @BindView(R.id.shopping_linear_btn)
    LinearLayout shoppingLinearBtn;

    LinearLayout shopping_bg_color;
    RoundTextView shopping_detele_text;


    boolean is_Select = true;

    List<ShopCartListBean.ListBean> ShopCartListBean = null;
    String goods_attr;
    String getAttr_name;
    String getRec_id;
    int is_All;

    int pos;

    int mark = 1;//判断属于-自营还是海淘页面----1为自营；2位海淘；

    String recId;


    private ShoppingCheAdapter shoppingCheAdapter;
    View view;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_online_learning;
    }


    @Override
    protected VideonFragmentPresenter initPresenter() {
        return new VideonFragmentPresenter();
    }

    @SuppressLint("WrongConstant")
    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        if (shopping_bg_color != null) {
            if (shopping_bg_color.getVisibility() == 0) {
                shopping_bg_color.setVisibility(View.INVISIBLE);
            }
        }
        view = View.inflate(getContext(), R.layout.rv_item_shopping_che, null);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
//        recyclerView.setSwipeMenuCreator(swipeMenuCreator);
//        recyclerView.setOnItemMenuClickListener(new OnItemMenuClickListener() {
//            @Override
//            public void onItemClick(SwipeMenuBridge menuBridge, int adapterPosition) {
//                menuBridge.closeMenu();
//                String getRec_id = shoppingCheAdapter.getData().get(adapterPosition).getRec_id();
//                Log.e("要删除的数据ID", "===getRec_id===" + getRec_id);
//                presenter.getDeleteData(getRec_id, "0");//删除购物车列表数据
//                shoppingCheAdapter.removeData(adapterPosition);
//            }
//        });


        shoppingLinearBtn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {

                if (shopping_bg_color != null) {
                    Log.e("shoppingLinearBtn", "===getVisibility===" + shopping_bg_color.getVisibility());
                    if (shopping_bg_color.getVisibility() == 0) {
                        shopping_bg_color.setVisibility(View.INVISIBLE);
                    }

                }
            }
        });
        if (shopping_bg_color != null) {
            shopping_bg_color.setOnClickListener(new View.OnClickListener() {
                @SuppressLint("WrongConstant")
                @Override
                public void onClick(View view) {
                    Log.e("shopping_bg_color", "===getVisibility===" + shopping_bg_color.getVisibility());
                    if (shopping_bg_color.getVisibility() == 0) {
                        shopping_bg_color.setVisibility(View.INVISIBLE);
                    }
                }
            });
        }

        //显示删除
        recyclerView.setOnItemLongClickListener(new OnItemLongClickListener() {
            @Override
            public void onItemLongClick(View view, int adapterPosition) {
//                String getRec_id = shoppingCheAdapter.getData().get(adapterPosition).getRec_id();
//                Log.e("要删除的数据ID", "===getRec_id===" + getRec_id);
//                presenter.getDeleteData(getRec_id, "0");//删除购物车列表数据
//                shoppingCheAdapter.removeData(adapterPosition);
//                DeteleDialog.with(getActivity()).show();
                if (shoppingCheAdapter.getData().size() > 0) {
                    shopping_bg_color = view.findViewById(R.id.shopping_bg_color);
                    shopping_detele_text = view.findViewById(R.id.shopping_detele_text);
                    shopping_bg_color.setVisibility(View.VISIBLE);
//                    Log.e("要删除的数据ID", "===getRec_id=123==" + getRec_id);
                    shopping_detele_text.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String getRec_id = shoppingCheAdapter.getData().get(adapterPosition).getRec_id();
                            Log.e("要删除的数据ID", "===getRec_id===" + getRec_id);
                            presenter.getDeleteData(getRec_id, "0");//删除购物车列表数据
                            shoppingCheAdapter.removeData(adapterPosition);
                            shopping_bg_color.setVisibility(View.INVISIBLE);

                        }
                    });


//                    view.setBackgroundColor(getResources().getColor(R.color.black_60));

//                    AlertDialog alertDialog2 = new AlertDialog.Builder(getActivity())
//                            .setTitle("是否删除？")
//                            .setIcon(R.mipmap.ic_launcher)
//                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加"Yes"按钮
//                                @Override
//                                public void onClick(DialogInterface dialogInterface, int i) {
//                                    String getRec_id = shoppingCheAdapter.getData().get(adapterPosition).getRec_id();
//                                    Log.e("要删除的数据ID", "===getRec_id===" + getRec_id);
//                                    presenter.getDeleteData(getRec_id, "0");//删除购物车列表数据
//                                    shoppingCheAdapter.removeData(adapterPosition);
//                                }
//                            })
//
//                            .setNegativeButton("取消", new DialogInterface.OnClickListener() {//添加取消
//                                @Override
//                                public void onClick(DialogInterface dialogInterface, int i) {
//                                    dialogInterface.dismiss();
//                                }
//                            })
//                            .create();
//                    alertDialog2.show();
                }
            }
        });

        //隐藏删除
//        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
//            @Override
//            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
//                //获得action事件
//                int action = e.getActionMasked();
//                //当action是ACTION_DOWN的时候，处理事件
//                if (action == MotionEvent.ACTION_DOWN) {
//                    //根据你点击的点的横纵坐标，得到你点击的view
//                    //这是Recyclerview自带的方法
//                    View touchView = rv.findChildViewUnder(e.getX(), e.getY());
//
//                    //Touch到了recyclerview没有item覆盖的区域
//                    if (touchView == null) {
//                        if (shopping_bg_color != null) {
//                            Log.e("addOnItemTouchListener", "===getVisibility===" + shopping_bg_color.getVisibility());
//                            if (shopping_bg_color.getVisibility() == 0) {
//                                shopping_bg_color.setVisibility(View.INVISIBLE);
//                            }
//
//                        }
//                        return false;
//                    }
//                    //需要单独处理event的view
//                    View radioGroup = touchView.findViewById(R.id.radioGroup);
//                    View bottonm_layout = touchView.findViewById(R.id.bottonm_layout);
//                    if (radioGroup == null && bottonm_layout == null) {
//                        if (shopping_bg_color != null) {
//                            Log.e("addOnItemTouchListener", "===getVisibility=111==" + shopping_bg_color.getVisibility());
//                            if (shopping_bg_color.getVisibility() == 0) {
//                                shopping_bg_color.setVisibility(View.INVISIBLE);
//                            }
//
//                        }
//                        return false;
//                    }
//
//                }
//
//                return false;
//            }
//
//            @Override
//            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
//
//            }
//
//            @Override
//            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
//
//            }
//        });

        //隐藏删除
        recyclerView.setOnItemClickListener(new OnItemClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onItemClick(View view, int adapterPosition) {
//                Log.e("适配器", "==适配器Item点击事件=1111==" + shopping_bg_color.getVisibility());
                if (shoppingCheAdapter.getData().size() > 0) {
                    if (shopping_bg_color != null) {
                        Log.e("recyclerView", "=====适配器Item点击事件=222===" + shopping_bg_color.getVisibility());
                        if (shopping_bg_color.getVisibility() == 0) {
                            shopping_bg_color.setVisibility(View.INVISIBLE);
                        } else if (shopping_bg_color.getVisibility() == 4) {
                            MoveAbooutActivity_1.startSelf(getActivity(), shoppingCheAdapter.getData().get(adapterPosition).getGoods_id(), shoppingCheAdapter.getData().get(adapterPosition).getSearch_attr());
                        }
//
                    } else {
                        MoveAbooutActivity_1.startSelf(getActivity(), shoppingCheAdapter.getData().get(adapterPosition).getGoods_id(), shoppingCheAdapter.getData().get(adapterPosition).getSearch_attr());
                    }
                }

            }
        });


        shoppingCheAdapter = new ShoppingCheAdapter(getActivity(), new ShoppingCheAdapter.AddShopNumberClickListener() {
            @Override
            public void onBtnClickListener(String s, String rec_id, int position) {
                pos = position;
                presenter.getAddAndReduce(mark, s, rec_id);//加减接口
//                getJG();
            }

            //选择商品类型
            @Override
            public void onTypeClickListener(ShopCartListBean.ListBean data, int positions) {
                getRec_id = shoppingCheAdapter.getData(positions).getRec_id();
                goods_attr = shoppingCheAdapter.getData().get(positions).getGoods_attr();
                listBean = data;
                presenter.getTypeShopData(data.getGoods_id());

            }

//            @Override
//            public void onItemDetailsPageListener(ShopCartListBean.ListBean data, int position) {
//                MoveAbooutActivity_1.startSelf(getActivity(), shoppingCheAdapter.getData().get(position).getGoods_id(), shoppingCheAdapter.getData().get(position).getSearch_attr());
//            }
        });//适配器

        recyclerView.setAdapter(shoppingCheAdapter);

//        shoppingCheAdapter.addOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View view, int position) {
//                Log.e("适配器", "==适配器点击事件===");
//                MoveAbooutActivity_1.startSelf(getActivity(), shoppingCheAdapter.getData().get(position).getGoods_id(), shoppingCheAdapter.getData().get(position).getSearch_attr());
//            }
//        });


//        //点击事件
//        shoppingCheAdapter.addOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View view, int position) {
//
//                presenter.getSelectShop(mark, 1, 1);
//
//
//            }
//        });
        //选择按钮
        shoppingCheAdapter.setShoppingCheOnClickAll(new ShoppingCheAdapter.ShoppingCheOnClickAll() {
            @Override
            public void OnClick(int is_check, String rec_id, boolean isall) {
                Log.e("oppingCheOnClickAll", "==is_check==" + is_check);
                Log.e("oppingCheOnClickAll", "==rec_id==" + rec_id);
                if (isall) {
                    Log.e("oppingCheOnClickAll", "==isall=222=");
                    Log.e("oppingCheOnClickAll", "==isall=222=");
                    if (is_check == 0) {//未选择
//                        ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                        presenter.getSelectShopping(mark, rec_id, is_check, 0);
                    } else if (is_check == 1) {//已选择
//                        ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
                        presenter.getSelectShopping(mark, rec_id, is_check, 0);
                    }
                } else {
                    Log.e("oppingCheOnClickAll", "==isall=333=");
                    Log.e("oppingCheOnClickAll", "==isall=333=");
//                    ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
//                    presenter.getSelectShopping(mark, rec_id,0, 0);
                    if (is_check == 0) {//未选择
//                        ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                        presenter.getSelectShopping(mark, rec_id, is_check, 0);
                    } else if (is_check == 1) {//已选择
//                        ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
                        presenter.getSelectShopping(mark, rec_id, is_check, 0);
                    }

                }

                getJG();
            }
        });
        RecyclerView.ItemDecoration gridItemDecoration = new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                outRect.top = 20;
            }
        };
        recyclerView.addItemDecoration(gridItemDecoration);


    }

    private double getJG() {
        Log.e("", "计算价格===" + mark);
        double d = 0;
        if (mark == 1) {
            for (int i = 0; i < shoppingCheAdapter.getList().size(); i++) {
                if (Integer.parseInt(shoppingCheAdapter.getList().get(i).getIs_promote()) == 1) {//限时
                    for (int j = 0; j < Integer.valueOf(shoppingCheAdapter.getList().get(i).getGoods_number()); j++) {
                        d = d + Double.valueOf(shoppingCheAdapter.getList().get(i).getPreferential_price());
                    }
                } else if (Integer.parseInt(shoppingCheAdapter.getList().get(i).getIs_promote()) == 0) {//普通
                    for (int j = 0; j < Integer.valueOf(shoppingCheAdapter.getList().get(i).getGoods_number()); j++) {
                        d = d + Double.valueOf(shoppingCheAdapter.getList().get(i).getProduct_price());
                    }
                }
            }
            tvTotal1.setText("￥" + d);
            Log.e("", "获取到价格===" + d);
        } else if (mark == 2) {
            for (int i = 0; i < shoppingCheAdapter.getList2().size(); i++) {
                if (Integer.parseInt(shoppingCheAdapter.getList2().get(i).getIs_promote()) == 1) {//限时
                    for (int j = 0; j < Integer.valueOf(shoppingCheAdapter.getList2().get(i).getGoods_number()); j++) {
                        d = d + Double.valueOf(shoppingCheAdapter.getList2().get(i).getPreferential_price());
                    }
                } else if (Integer.parseInt(shoppingCheAdapter.getList2().get(i).getIs_promote()) == 0) {//普通
                    for (int j = 0; j < Integer.valueOf(shoppingCheAdapter.getList2().get(i).getGoods_number()); j++) {
                        d = d + Double.valueOf(shoppingCheAdapter.getList2().get(i).getProduct_price());
                    }
                }
            }
            tvTotal1.setText("￥" + d);
            Log.e("", "获取到价格===" + d);
        }
        return d;
    }

    /**
     * 菜单创建器。在Item要创建菜单的时候调用。
     */
    private SwipeMenuCreator swipeMenuCreator = new SwipeMenuCreator() {
        @Override
        public void onCreateMenu(SwipeMenu swipeLeftMenu, SwipeMenu swipeRightMenu, int viewType) {
            SwipeMenuItem deleteItem = new SwipeMenuItem(getContext())
                    .setBackgroundColor(ResUtils.getColor(R.color.them))
                    .setText("删除") // 文字。
                    .setTextColor(Color.WHITE) // 文字颜色。
                    .setTextSize(14)// 文字大小。
                    .setWidth(200)
                    .setHeight(MATCH_PARENT);
            swipeRightMenu.addMenuItem(deleteItem);// 添加一个按钮到右侧侧菜单。.

            // 上面的菜单哪边不要菜单就不要添加。
        }
    };

    @Override
    public void onResume() {
        super.onResume();
//        presenter.getShopListData(mark);//下载购物车列表数据
        if (!UserUtils.getInstance().getUserId().equals("")) {
            presenter.getShopListData(mark);//下载购物车列表数据
        } else {
            shoppingCheAdapter.clearData();
            tabUnreadNotify.setVisibility(View.INVISIBLE);
            tabUnreadNotify1.setVisibility(View.INVISIBLE);
            shoppingCheAdapter.notifyDataSetChanged();
            Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void loadData() {
//        presenter.getAppUpdate();//下载时间
//        presenter.getShopListData(mark);//下载购物车列表数据
//        if (!UserUtils.getInstance().getUserId().equals("")) {
//            presenter.getShopListData(mark);//下载购物车列表数据
//        } else {
//            shoppingCheAdapter.clearData();
//            shoppingCheAdapter.notifyDataSetChanged();
//            Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
//        }

    }


    @OnClick({R.id.tv_settlement, R.id.rl_check_circle, R.id.shop_ziying_btn, R.id.shop_haitao_btn})
    @Override
    public void onClick(View v) {
        super.onClick(v);
    }

    @SuppressLint("WrongConstant")
    @Override
    public boolean onClickWithoutLogin(View v) {
        switch (v.getId()) {
            default:
                break;

            case R.id.shop_ziying_btn://自营
                if (shopping_bg_color != null) {  //隐藏删除
                    Log.e("自营", "===getVisibility=111==" + shopping_bg_color.getVisibility());
                    if (shopping_bg_color.getVisibility() == 0) {
                        shopping_bg_color.setVisibility(View.INVISIBLE);
                    }

                }

                mark = 1;
                ziyingShopView.setBackgroundColor(getResources().getColor(R.color.them));
                haitaoShopView.setBackgroundColor(getResources().getColor(R.color.classify_them));
                shoppingCheAdapter.setList(new ArrayList<>(), mark);
                shoppingCheAdapter.setList2(new ArrayList<>(), mark);

                if (!UserUtils.getInstance().getUserId().equals("")) {
                    presenter.getShopListData(mark);//下载购物车列表数据
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.shop_haitao_btn://海淘
                if (shopping_bg_color != null) {  //隐藏删除
                    Log.e("海淘", "===getVisibility=111==" + shopping_bg_color.getVisibility());
                    if (shopping_bg_color.getVisibility() == 0) {
                        shopping_bg_color.setVisibility(View.INVISIBLE);
                    }

                }
                mark = 2;
                ziyingShopView.setBackgroundColor(getResources().getColor(R.color.classify_them));
                haitaoShopView.setBackgroundColor(getResources().getColor(R.color.them));
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    presenter.getShopListData(mark);//下载购物车列表数据
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tv_settlement://结算
                if (shopping_bg_color != null) {  //隐藏删除
                    Log.e("结算", "===getVisibility=111==" + shopping_bg_color.getVisibility());
                    if (shopping_bg_color.getVisibility() == 0) {
                        shopping_bg_color.setVisibility(View.INVISIBLE);
                    }

                }
                Log.e("结算", "===mark11111111===" + mark);
//                ConfirmOrderActivity.startSelf(getContext(),rec_id,goods_id,product_id,num);
                if (mark == 1) {
                    StringBuffer sb = new StringBuffer();
                    if (shoppingCheAdapter.getList().size() > 0) {
                        for (int i = 0; i < shoppingCheAdapter.getList().size(); i++) {
                            sb.append(shoppingCheAdapter.getList().get(i).getRec_id()).append(",");
                        }
                        recId = sb.deleteCharAt(sb.length() - 1).toString();

                        Log.e("结算", "===拼接字符串===" + recId);

//                        ConfirmOrderActivity.startSelf(getContext(), recId, "", "", "");

                        presenter.getConfirmOrderData(recId, "", "", "");

                    }
                } else if (mark == 2) {
                    Log.e("结算", "===mark===" + mark);
                    StringBuffer sb1 = new StringBuffer();
                    if (shoppingCheAdapter.getList2().size() > 0) {
                        for (int i = 0; i < shoppingCheAdapter.getList2().size(); i++) {
                            sb1.append(shoppingCheAdapter.getList2().get(i).getRec_id()).append(",");
                        }
                        recId = sb1.deleteCharAt(sb1.length() - 1).toString();

                        Log.e("结算", "===拼接字符串===" + recId);
//                        ConfirmOrderActivity.startSelf(getContext(), recId, "", "", "");
                        presenter.getConfirmOrderData(recId, "", "", "");
                    }

                }
                break;
            case R.id.rl_check_circle://全选
                if (shopping_bg_color != null) {  //隐藏删除
                    Log.e("全选", "===getVisibility=111==" + shopping_bg_color.getVisibility());
                    if (shopping_bg_color.getVisibility() == 0) {
                        shopping_bg_color.setVisibility(View.INVISIBLE);
                    }

                }
                if (mark == 1) {//自营
                    if (is_All == 0) {//未选择状态
                        presenter.getSelectShopping(mark, "", 1, 1);//加减接口--1:自营还是海淘；2：每个商品的状态；3：全选的
                        List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                        strings.addAll(shoppingCheAdapter.getData());
                        shoppingCheAdapter.setList(strings, mark);
                    } else if (is_All == 1) {//选择状态
                        shoppingCheAdapter.setList(new ArrayList<>(), mark);
                        presenter.getSelectShopping(mark, "", 0, 1);//加减接口
                        shoppingCheAdapter.setList(new ArrayList<>(), mark);
                    }
                } else if (mark == 2) {//海淘
                    if (is_All == 0) {//未选择状态
                        presenter.getSelectShopping(mark, "", 1, 1);//加减接口--1:自营还是海淘；2：每个商品的状态；3：全选的
                        List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                        strings.addAll(shoppingCheAdapter.getData());
                        shoppingCheAdapter.setList2(strings, mark);
                    } else if (is_All == 1) {//选择状态
                        shoppingCheAdapter.setList2(new ArrayList<>(), mark);
                        presenter.getSelectShopping(mark, "", 0, 1);//加减接口
                        shoppingCheAdapter.setList2(new ArrayList<>(), mark);
                    }
                }
                break;
        }
        return false;
    }

    /**
     * @Description:下载时间成功
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {

    }

    /**
     * @Description:下载时间失败
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getAppUpdateFail(int code, String msg) {

    }


    /**
     * @Description:下载购物车列表成功
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getShopListDataSuccess(int code, ShopCartListBean data) {
        Log.e("下载购物车列表成功", "==data.getZy_count()==" + data.getZy_count());
        Log.e("下载购物车列表成功", "==data.getHt_count()==" + data.getHt_count());
        ShopCartListBean = data.getList();
//        shoppingCheAdapter.setList(new ArrayList<>(), mark);
//        shoppingCheAdapter.setList2(new ArrayList<>(), mark);
        if (Integer.parseInt(data.getZy_count()) > 0) {
            tabUnreadNotify.setText(data.getZy_count() + "");
            tabUnreadNotify.setVisibility(View.VISIBLE);
        } else {
            tabUnreadNotify.setVisibility(View.INVISIBLE);
        }
        if (Integer.parseInt(data.getHt_count()) > 0) {
            tabUnreadNotify1.setText(data.getHt_count() + "");
            tabUnreadNotify1.setVisibility(View.VISIBLE);
        } else {
            tabUnreadNotify1.setVisibility(View.INVISIBLE);
        }
        is_All = Integer.parseInt(data.getIs_all());//全选状态

        if (mark == 1) {//自营
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList(strings, mark);
            }
        } else if (mark == 2) {//海淘
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList2(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList2(strings, mark);
            }
        }
        if (code == 3000) {
            shoppingCheAdapter.setData(data.getList());
            ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
            tvTotal1.setText("￥0.0");
            Log.e("getShopListDataFail", "==getZy_count==" + data.getZy_count());
            Log.e("getShopListDataFail", "==getHt_count==" + data.getHt_count());
            if (Integer.parseInt(data.getZy_count()) > 0) {
                tabUnreadNotify.setText(data.getZy_count() + "");
                tabUnreadNotify.setVisibility(View.VISIBLE);
            } else {
                tabUnreadNotify.setVisibility(View.INVISIBLE);
            }
            if (Integer.parseInt(data.getHt_count()) > 0) {
                tabUnreadNotify1.setText(data.getHt_count() + "");
                tabUnreadNotify1.setVisibility(View.VISIBLE);
            } else {
                tabUnreadNotify1.setVisibility(View.INVISIBLE);
            }
            presenter.dismissLoading();
        }

        getJG();

        shoppingCheAdapter.setData(data.getList());
        shoppingCheAdapter.notifyDataSetChanged();


    }

    /**
     * @Description:下载购物车列表失败
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getShopListDataFail(int code, String msg) {
        shoppingCheAdapter.clearData();


    }

    /**
     * @Description:数量加减成功
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getAddAndReduceSuccess(int code, ShopCartListBean data) {
        Log.e("全选改变状态成功", "==data.getZy_count()==" + data.getZy_count());
        Log.e("全选改变状态成功", "==data.getHt_count()==" + data.getHt_count());
        ShopCartListBean = data.getList();
//        shoppingCheAdapter.setList(new ArrayList<>(), mark);
//        shoppingCheAdapter.setList2(new ArrayList<>(), mark);
//        if (data.getZy_count() > 0) {
//            tabUnreadNotify.setText(data.getZy_count() + "");
//            tabUnreadNotify.setVisibility(View.VISIBLE);
//        } else {
//            tabUnreadNotify.setVisibility(View.INVISIBLE);
//        }
//        if (data.getHt_count() > 0) {
//            tabUnreadNotify1.setText(data.getHt_count() + "");
//            tabUnreadNotify1.setVisibility(View.VISIBLE);
//        } else {
//            tabUnreadNotify1.setVisibility(View.INVISIBLE);
//        }
        is_All = Integer.parseInt(data.getIs_all());//全选状态

        if (mark == 1) {//自营
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList(strings, mark);
            }
        } else if (mark == 2) {//海淘
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList2(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList2(strings, mark);
            }
        }

        getJG();

        shoppingCheAdapter.setData(data.getList());
        shoppingCheAdapter.notifyDataSetChanged();

    }

    /**
     * @Description:数量加减失败
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getAddAndReduceFail(int code, String msg) {

    }

    /**
     * @Description:删除商品成功
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getDeleteDataSuccess(int code, ShopCartListBean data) {
        ShopCartListBean = data.getList();
        shoppingCheAdapter.setData(data.getList());
        shoppingCheAdapter.notifyDataSetChanged();
        if (Integer.parseInt(data.getZy_count()) > 0) {
            tabUnreadNotify.setVisibility(View.VISIBLE);
            tabUnreadNotify.setText(data.getZy_count());
        } else {
            tabUnreadNotify.setVisibility(View.GONE);
        }

        if (Integer.parseInt(data.getHt_count()) > 0) {
            Log.e("海淘数量", "海淘数量===" + data.getHt_count());
            tabUnreadNotify1.setVisibility(View.VISIBLE);
            tabUnreadNotify1.setText(data.getHt_count() + "");
        } else {
            tabUnreadNotify1.setVisibility(View.GONE);
        }

        is_All = Integer.parseInt(data.getIs_all());//全选状态

        if (mark == 1) {//自营
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList(strings, mark);
            }
        } else if (mark == 2) {//海淘
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList2(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList2(strings, mark);
            }
        }

        getJG();

    }

    /**
     * @Description:删除商品失败
     * @Time:2020/5/7 12:54
     * @Author:pk
     */
    @Override
    public void getDeleteDataFail(int code, String msg) {
//        if (code == 3000) {
//            ShopCartListBean data = new ShopCartListBean();
//            shoppingCheAdapter.setData(data.getList());
//            presenter.dismissLoading();
//        }

    }

    /**
     * @Description:选择商品类型
     * @Time:2020/5/11 13:58
     * @Author:pk
     */
    @Override
    public void getTypeShopSuccess(int code, MoveDataBean moveDataBeas) {
        Log.e("选择商品类型", "==Success==" + code);
//        ShopCartListBean
//        MoveDataBean moveDataBeas = new MoveDataBean();
        MoveDataBean.InfoBean infoBean = new MoveDataBean.InfoBean();
        List<String> strings = new ArrayList<>();
        strings.add(listBean.getGoods_thumb());
        infoBean.setBanner(strings);
        infoBean.setSearch_attr(listBean.getSearch_attr());
        infoBean.setGoods_id(listBean.getGoods_id());
        infoBean.setProduct_number(listBean.getNumber());
        infoBean.setProduct_price(listBean.getProduct_price());
        moveDataBeas.setInfo(infoBean);
        Log.e("选择商品类型", "goods_attr===" + goods_attr);

        TypeSelectDialog.with(getActivity(), moveDataBeas, goods_attr, "", new TypeSelectDialog.AddShopCarClickListener() {
            @Override
            public void onBtnClickListener(String goods_id, String product_id, String num, String getAttr_name, String mmake) {
                goods_attr = "";
                presenter.getModifyType(mark, getRec_id, num, product_id);
            }
        }).show();

    }

    @Override
    public void getTypeShopFail(int code, String msg) {
        Log.e("选择商品类型", "==Fail==" + code);
    }

    /**
     * @Description:修改商品规格成功
     * @Time:2020/5/11 13:58
     * @Author:pk
     */
    @Override
    public void getModifyTypeSuccess(int code, ModifyTypeBean data) {
        presenter.getShopListData(mark);//下载购物车列表数据
        TypeSelectDialog.dismiss();
    }

    /**
     * @Description:修改商品规格失败
     * @Time:2020/5/11 13:58
     * @Author:pk
     */
    @Override
    public void getModifyTypeFail(int code, String msg) {

    }

    /**
     * 全选改变状态成功
     *
     * @param code
     * @param data
     */
    @Override
    public void getSelectShoppingSuccess(int code, ShopCartListBean data) {
//        is_All = data.getIs_all();//全选状态
//        if (is_All == 1) {
//            ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
//        } else if (is_All == 0) {
//            ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
//        }

//        presenter.getShopListData(mark);//下载购物车列表数据

//        Log.e("全选改变状态成功", "==data.getZy_count()==" + data.getZy_count());
//        Log.e("全选改变状态成功", "==data.getHt_count()==" + data.getHt_count());
        ShopCartListBean = data.getList();
//        shoppingCheAdapter.setList(new ArrayList<>(), mark);
//        shoppingCheAdapter.setList2(new ArrayList<>(), mark);
//        if (data.getZy_count() > 0) {
//            tabUnreadNotify.setText(data.getZy_count() + "");
//            tabUnreadNotify.setVisibility(View.VISIBLE);
//        } else {
//            tabUnreadNotify.setVisibility(View.INVISIBLE);
//        }
//        if (data.getHt_count() > 0) {
//            tabUnreadNotify1.setText(data.getHt_count() + "");
//            tabUnreadNotify1.setVisibility(View.VISIBLE);
//        } else {
//            tabUnreadNotify1.setVisibility(View.INVISIBLE);
//        }
        is_All = Integer.parseInt(data.getIs_all());//全选状态

        if (mark == 1) {//自营
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList(strings, mark);
            }
        } else if (mark == 2) {//海淘
            if (is_All == 1) {//选择状态
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                strings.addAll(ShopCartListBean);
                shoppingCheAdapter.setList2(strings, mark);
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_1));
            } else if (is_All == 0) {//未选择状态
                ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
                List<ShopCartListBean.ListBean> strings = new ArrayList<>();
                for (int i = 0; i < ShopCartListBean.size(); i++) {
                    if (ShopCartListBean.get(i).getIs_check().equals("1")) {
                        strings.add(ShopCartListBean.get(i));
                    }
                }
                shoppingCheAdapter.setList2(strings, mark);
            }
        }

        getJG();

        shoppingCheAdapter.setData(data.getList());
        shoppingCheAdapter.notifyDataSetChanged();


    }

    /**
     * 全选改变状态失败
     *
     * @param code
     * @param
     */
    @Override
    public void getSelectShoppingFail(int code, String msg) {
//        if (code == 3000) {
        ShopCartListBean data = new ShopCartListBean();
        shoppingCheAdapter.setData(data.getList());
        ivCheckCircle.setImageDrawable(ResUtils.getDrawable(R.mipmap.shop_cat_icon_2));
        tvTotal1.setText("￥0.0");
        presenter.dismissLoading();
//        }

    }

    //结算成功
    @Override
    public void getConfirmOrderSuccess(int code, ConfirmOrderBean data) {
        Log.e("购物车", "结算成功===code===" + code);
        ConfirmOrderActivity.startSelf(getContext(), recId, "", "", "");

    }

    //结算失败
    @Override
    public void getConfirmOrderFail(int code, String msg) {
        Log.e("购物车", "结算失败===code===" + code);
        Log.e("购物车", "结算失败===msg===" + msg);

        if (code == 4000) {
            Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }

    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ShopTypeDataEvent event) {
        List<String> getBannerEvent = event.getBanner();
        TypeSelectDialog.setUrl(getBannerEvent.get(1));

    }

    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ShopCarJudgeEvent event) {
        Log.e("ShoppingCheFragment", "=首页传递消息==");
        int getJupdg = event.getJupdg();
        if (getJupdg == 1) {
//            presenter.getAppUpdate();//下载时间
            if (!UserUtils.getInstance().getUserId().equals("")) {
                presenter.getShopListData(mark);//下载购物车列表数据
            } else {
                shoppingCheAdapter.clearData();
                shoppingCheAdapter.notifyDataSetChanged();
                Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
            }

        }
    }


}
