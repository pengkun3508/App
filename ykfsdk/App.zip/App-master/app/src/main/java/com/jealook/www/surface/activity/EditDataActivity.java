package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.event.MainHomeActivityEvent;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.bean.UpdateImgBean;
import com.jealook.www.surface.bean.UserInfo;
import com.jealook.www.surface.mvp.presenter.EditDataPresenter;
import com.jealook.www.surface.mvp.view.EditDataView;
import com.jealook.www.utils.ImageLoader;
import com.jealook.www.utils.UserUtils;
import com.jealook.www.widgat.actionbar.ActionBarSimple;
import com.makeramen.roundedimageview.RoundedImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @Description:编辑个人资料
 * @Time:2020/4/14 9:41
 * @Author:pk
 */
public class EditDataActivity extends BaseActivity<EditDataPresenter> implements EditDataView {


    @BindView(R.id.personal_head_img)
    RoundedImageView personalHeadImg;
    @BindView(R.id.personal_head)
    LinearLayout personalHead;
    @BindView(R.id.personal_name_edit)
    TextView personalNameEdit;
    @BindView(R.id.personal_name)
    LinearLayout personalName;
    @BindView(R.id.personal_sex_edit)
    TextView personalSexEdit;
    @BindView(R.id.personal_sex)
    LinearLayout personalSex;
    @BindView(R.id.personal_phone_edit)
    TextView personalPhoneEdit;//手机号
    @BindView(R.id.personal_phone)
    RelativeLayout personalPhone;
    @BindView(R.id.personal_out_btn)
    TextView personalOutBtn;
    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    String getMobile;

    public static void startSelf(Context context) {
        Intent intent = new Intent(context, EditDataActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_edit_data;
    }

    @Override
    protected EditDataPresenter initPresenter() {
        return new EditDataPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        actionBar.getTvRight().setText("编辑");
        actionBar.getTvRight().setVisibility(View.VISIBLE);
        actionBar.getTvRight().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditDataActivity_2.startSelf(EditDataActivity.this);
            }
        });

        personalHeadImg.setScaleType(ImageView.ScaleType.FIT_XY);
    }

    @Override
    protected void loadData() {
        presenter.getUserInfoData();

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @OnClick({R.id.personal_head_img, R.id.personal_name, R.id.personal_sex, R.id.personal_phone, R.id.personal_out_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.personal_head_img://更换头像
                break;
            case R.id.personal_name://姓名
                break;
            case R.id.personal_sex://性别
                break;
            case R.id.personal_phone://修改手机号
                VerifyPhoneActivity.startSelf(this,getMobile);
                break;
            case R.id.personal_out_btn://退出登录
//                UserUtils.getInstance().getUserInfo();
                UserUtils.getInstance().logout();
//                new MyPersonalJudgeEvent(1).post();
                new MainHomeActivityEvent("1").post();
                finish();
                break;
        }
    }

    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {

    }

    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    @Override
    public void getUserInfoSuccess(int code, UserInfo data) {
        getMobile = data.getMobile();
        ImageLoader.userIcon(this, personalHeadImg, data.getImg_url());
        personalNameEdit.setText(data.getUser_name());
        personalSexEdit.setText(data.getSex());
        personalPhoneEdit.setText(data.getMobile());
    }

    @Override
    public void getUserInfoFail(int code, String msg) {

    }

    @Override
    public void uploadPhotosSuccess(int code, UpdateImgBean data) {

    }

    @Override
    public void uploadPhotosFailed(int code, String msg) {

    }

    @Override
    public void uploadPersonalSuccess(int code, UserInfo data) {

    }

    @Override
    public void uploadPersonalFailed(int code, String msg) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.getUserInfoData();
    }
}
