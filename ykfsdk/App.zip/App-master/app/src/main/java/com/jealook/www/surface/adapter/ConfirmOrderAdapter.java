package com.jealook.www.surface.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.surface.bean.ConfirmOrderBean;

/**
 * @Description:确认订单商品List
 * @Time:2020/5/12$
 * @Author:pk$
 */
public class ConfirmOrderAdapter extends BaseStateAdapter<ConfirmOrderBean.ShopListBean, ConfirmOrderAdapter.ConfirmOrderHolder> {

    Context context;

    public ConfirmOrderAdapter(Context context) {
        this.context = context;

    }

    @Override
    protected ConfirmOrderHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new ConfirmOrderHolder(inflate(parent, R.layout.confirm_item_order));
    }

    class ConfirmOrderHolder extends BaseHolder<ConfirmOrderBean.ShopListBean> {

        ImageView confirm_order_img;
        TextView confirm_order_name, confirm_order_type, confirm_order_number, confirm_order_price, confirm_order_price_1;

        ConfirmOrderHolder(View itemView) {
            super(itemView);
            confirm_order_img = getView(R.id.confirm_order_img);
            confirm_order_name = getView(R.id.confirm_order_name);
            confirm_order_type = getView(R.id.confirm_order_type);
            confirm_order_number = getView(R.id.confirm_order_number);
            confirm_order_price = getView(R.id.confirm_order_price);
            confirm_order_price_1 = getView(R.id.confirm_order_price_1);

        }

        @Override
        protected void bindData(ConfirmOrderBean.ShopListBean data) {
            confirm_order_img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Glide.with(context).load(data.getGoods_thumb())
                    .into(confirm_order_img);

            confirm_order_name.setText(data.getGoods_name());
            confirm_order_type.setText(data.getGoods_attr_name());
            confirm_order_number.setText("x" + data.getNumber());
            confirm_order_price.setText("￥" + data.getProduct_price());

            if (data.getIs_promote()==1) {//显示限时页面
                confirm_order_price_1.setVisibility(View.VISIBLE);
                confirm_order_price.setText("￥" + data.getPreferential_price());
                confirm_order_price_1.setText("￥" + data.getProduct_price());
            } else if (data.getIs_promote()==0) {//显示普通页面
                confirm_order_price_1.setVisibility(View.GONE);

            }
            confirm_order_price_1.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
        }
    }
}
