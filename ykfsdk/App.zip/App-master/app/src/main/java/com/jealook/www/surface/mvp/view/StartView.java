package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;

/**
 * 描述：
 *
 * @author Cuizhen
 * @date 2018/9/4
 */
public interface StartView extends MvpView {
}
