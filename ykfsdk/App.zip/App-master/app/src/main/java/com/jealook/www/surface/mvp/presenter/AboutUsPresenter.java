package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.AboutUsView;
import com.jealook.www.surface.mvp.view.AddressAddView;

/**
 * @Description:
 * @Time:2020/6/30$
 * @Author:pk$
 */
public class AboutUsPresenter  extends MvpPresenter<AboutUsView> {
}
