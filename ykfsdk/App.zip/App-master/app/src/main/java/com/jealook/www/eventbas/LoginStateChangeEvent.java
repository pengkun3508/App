package com.jealook.www.eventbas;

import com.dm.lib.core.eventbas.BaseEvent;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/4/4
 */
public class LoginStateChangeEvent extends BaseEvent {

}
