package com.jealook.www.surface.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.common.Config;
import com.jealook.www.surface.adapter.OnlineCustomerServiceAdapter;
import com.jealook.www.surface.mvp.presenter.OnlineCustomerServicePresenter;
import com.jealook.www.surface.mvp.view.OnlineCustomerServiceView;
import com.jealook.www.utils.SmartRefreshHelper;
import com.jealook.www.widgat.actionbar.ActionBarSimple;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @Description:客服
 * @Time:2020/4/14 9:42
 * @Author:pk
 */
public class OnlineCustomerServiceActivity extends BaseActivity<OnlineCustomerServicePresenter> implements OnlineCustomerServiceView {
    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;
    @BindView(R.id.edit_language)
    EditText editLanguage;
    private OnlineCustomerServiceAdapter adapter;
    private SmartRefreshHelper<String> mSmartRefreshHelper;


    @Override
    protected int getLayoutId() {
        return R.layout.activity_online_customer_service;
    }

    public static void startSelf(Context context) {
        Intent intent = new Intent(context, OnlineCustomerServiceActivity.class);
        context.startActivity(intent);

    }

    @Override
    protected OnlineCustomerServicePresenter initPresenter() {
        return null;
    }

    @SuppressLint("MissingPermission")
    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OnlineCustomerServiceAdapter();
        recyclerView.setAdapter(adapter);
        mSmartRefreshHelper = SmartRefreshHelper.with(smartRefreshLayout, adapter)//刷新数据
                .setPerPageCount(Config.ONE_PAGE_ITEM_MAX_COUNT_DEFAULT)
                .init(new SmartRefreshHelper.RefreshCallback() {
                    @Override
                    public void doRequestData(int page) {
                        mSmartRefreshHelper.onSuccess(2000, getData());

                    }
                });


    }

    @Override
    protected void loadData() {
        mSmartRefreshHelper.requestFirstPage(false);

    }

    public List<String> getData() {
        List<String> strings = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            strings.add("1");
        }
        return strings;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }


    //发送文件类的消息( 包含视频 文件 图片)

//    /**
//     * @param filepath
//     * @param msgType  图片:UdeskConst.ChatMsgTypeString.TYPE_IMAGE
//     *                 文件:UdeskConst.ChatMsgTypeString.TYPE_File
//     *                 MP4视频: UdeskConst.ChatMsgTypeString.TYPE_SHORT_VIDEO
//     */
//    public synchronized void  sendFileMessage(String filepath, String msgType) {
//        try {
//            if (TextUtils.isEmpty(filepath)) {
//                return;
//            }
//            String fileName = (UdeskUtils.getFileName(filepath, msgType));
//            String fileSzie = UdeskUtils.getFileSizeByLoaclPath(filepath);
//            MessageInfo msgInfo = UdeskUtil.buildSendMessage(msgType,
//                    System.currentTimeMillis(), "", filepath, fileName, fileSzie);
//            postMessage(msgInfo, UdeskConst.LiveDataType.AddFileMessage);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } catch (OutOfMemoryError error) {
//            error.printStackTrace();
//        }
//    }


}
