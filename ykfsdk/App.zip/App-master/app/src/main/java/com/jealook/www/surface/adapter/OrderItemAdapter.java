package com.jealook.www.surface.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.http.model.AllOrderListBean;
import com.jealook.www.surface.activity.PublishCommentActivity;
import com.jealook.www.utils.ImageLoader;

/**
 * @Description:
 * @Time:2020/5/8$
 * @Author:pk$
 */
public class OrderItemAdapter extends BaseStateAdapter<AllOrderListBean.ListBean.ShopListBean, OrderItemAdapter.OrderItemHolder> {

    String marks;

    Context context;
    String order_id;
    int status;

    public OrderItemAdapter(Context contexts, String order_ids, int getStatus) {
        super();
        context = contexts;
        order_id = order_ids;
        status = getStatus;
    }


    public interface OnItemClickListener {
        void onItemClicked(View view, int position);
    }


    @Override
    protected OrderItemHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new OrderItemHolder(inflate(parent, R.layout.allorderlist_item));
    }


    public class OrderItemHolder extends BaseHolder<AllOrderListBean.ListBean.ShopListBean> {
        TextView order_item_title, order_item_type, order_item_type_number, order_item1_pingjia_btn;
        ImageView order_item_image;

        OrderItemHolder(View itemView) {
            super(itemView);
            order_item_image = getView(R.id.order_item_image);
            order_item_title = getView(R.id.order_item_title);
            order_item_type = getView(R.id.order_item_type);
            order_item_type_number = getView(R.id.order_item_type_number);
            order_item1_pingjia_btn = getView(R.id.order_item1_pingjia_btn);
        }

        @Override
        protected void bindData(AllOrderListBean.ListBean.ShopListBean data) {
            ImageLoader.image(context, order_item_image, data.getGoods_thumb());
            order_item_title.setText(data.getGoods_name());
            order_item_type.setText(data.getGoods_attr_name());
            order_item_type_number.setText("x" + data.getNumber());
            if (status == 3) {//评价状态
                if (data.getComment_id().equals("0")) {//判断是否评价状态
                    order_item1_pingjia_btn.setVisibility(View.VISIBLE);
                } else {
                    order_item1_pingjia_btn.setVisibility(View.GONE);
                }
            } else {
                order_item1_pingjia_btn.setVisibility(View.GONE);
            }
            /**
             * 评价
             */
            order_item1_pingjia_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PublishCommentActivity.startSelf(context, data.getGoods_id(), data.getSearch_attr(), order_id, data.getRec_id());
                }
            });

        }
    }
}
