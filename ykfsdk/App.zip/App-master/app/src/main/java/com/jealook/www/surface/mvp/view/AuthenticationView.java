package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;

public interface AuthenticationView extends MvpView {
}
