package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.AddressView;
import com.jealook.www.surface.mvp.view.AuthenticationView;

public class AuthenticationPresenter extends MvpPresenter<AuthenticationView> {
}