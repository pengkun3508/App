package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.OrganizationAdminView;
import com.jealook.www.surface.mvp.view.Purchase1View;

public class Purchase1Presenter extends MvpPresenter<Purchase1View> {
}
