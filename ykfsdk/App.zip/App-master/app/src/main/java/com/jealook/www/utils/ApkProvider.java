package com.jealook.www.utils;


import androidx.core.content.FileProvider;

/**
 * APP更新
 */
public class ApkProvider extends FileProvider {
}
