package com.jealook.www.eventbas;

import com.dm.lib.core.eventbas.BaseEvent;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/4/11
 */
public class NewsEvent extends BaseEvent {

}
