package com.jealook.www.common;

/**
 * 不可变的常量
 *
 * @author Yanbo
 * @date 2018/8/31
 */
public interface Constant {


    /**
     * 保存本地数据公共参数
     */
     String Sharepre_Name = "jealook";

    /**
     * 公共请求头的名字
     */
    String PUBLIC_HEADER_TIME_NAME = "JEALOOK-time";
    String PUBLIC_HEADER_SIGN_NAME = "JEALOOK-sign";
    /**
     * 公共请求参数的键值
     */
    String PUBLIC_PARAM_SYSTEM_KEY = "system";
    String PUBLIC_PARAM_SYSTEM_VALUE = "android";
    String PUBLIC_PARAM_VERSION_KEY = "version";
    String PUBLIC_PARAM_USER_ID_KEY = "user_id";
    String PUBLIC_PARAM_USER_DEVICE_KEY = "user_device";
    String PUBLIC_PARAM_JPUSH_DEVICE_KEY = "jpush_device";
    String PUBLIC_PARAM_DEVICE_ID_KEY = "device_id";//设备ID

    String KEY_SIGN_BEAN = "sign_bean";
    /**
     * 把正式参数和公共请求参数合并为一个参数传入后台（为方便以后的双向加密和解密），这个合并后的参数的KEY值为下
     */
    String PUBLIC_PARAM_KEY = "data";

    /**
     * 友盟
     */
    String WECHAT_APP_ID = " ";
    String WECHAT_APP_SECRET = " ";
    String QQ_APP_ID = " ";
    String QQ_APP_SECRET = " ";


    /**
     * 微信
     */

    String WECHAT_APPID = "wx15087974bfc54020";
    String WECHAT_SECRET = "3eb2db47e792e057c60183999f963151";


    /**
     * 一键登录
     */
    String LONIG_PHONE_NUMBER_KEY = "JhlmFzetxLlT706Gcs82XKj/FBUxaNELFt/tlDXCkxeZcah3V9PjbSgOYDq5U1iHHIM7mpR7Yz4hqyiV2f0dCDuJCmoi5pT3HV2x1L+BnfVCT4XIBLygWTEiAEYnxgvvfNapPgGND4nsMPP59XNLsTrn6fFD5w2p3Q9m3RjV62soHMHJelOsFGL6WB1tCSvRT8tJMVZ8h3Cw2tPvMjli9OWPo5DTxwkeYFSaHkT+qGrbhHVLaL8hrrZsHCliFFHjY+HaR7A7CgNc5fjOl+sDhK6vLKG7JsUG";


}
