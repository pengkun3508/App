package com.jealook.www.surface.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;

/**
 * 描述：
 *
 * @author yanbo
 * @date 2019-09-10
 */
public class OrganizationAdminAdapyer extends BaseStateAdapter<String, OrganizationAdminAdapyer.OrganizationAdminHolder> {


    @Override
    protected OrganizationAdminHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new OrganizationAdminHolder(inflate(parent, R.layout.rv_item_organization_admin));
    }

    class OrganizationAdminHolder extends BaseHolder<String> {


        TextView mClassTitls;
        ImageView mUsers;
        TextView mAddPeopleNumbers;
        ImageView mIcons;


        OrganizationAdminHolder(View itemView) {
            super(itemView);

            mClassTitls = getView(R.id.tv_titles);
            mUsers = getView(R.id.iv_users);
            mAddPeopleNumbers = getView(R.id.tv_add_people_numbers);
            mIcons = getView(R.id.iv_icons);
        }

        @Override
        protected void bindData(String data) {
//            mClassTitls.setText(data.getName());
//            ImageLoader.image(mIcons.getContext(),mIcons,data.getImg());
//            mAddPeopleNumbers.setText(MessageFormat.format("{0}人已加入", data.getCount()));
        }


    }
}