package com.jealook.www.http;


import com.jealook.www.common.Config;
import com.jealook.www.http.model.AddressListBean;
import com.jealook.www.http.model.AllOrderListBean;
import com.jealook.www.http.model.AlreadyCouponListBean;
import com.jealook.www.http.model.BrandListBean;
import com.jealook.www.http.model.CollectionListBean;
import com.jealook.www.http.model.CommodityListBean;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.LimitedBean;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.http.model.NotCouponListBean;
import com.jealook.www.http.model.OrderDetailsBean;
import com.jealook.www.http.model.ShopCartListBean;
import com.jealook.www.http.model.SiginOrderBean;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.surface.bean.ALiPayBean;
import com.jealook.www.surface.bean.BrowseListBean;
import com.jealook.www.surface.bean.ClassifyBean;
import com.jealook.www.surface.bean.ClassifyTypeBean;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.bean.EvaluateListBean;
import com.jealook.www.surface.bean.MemberBean;
import com.jealook.www.surface.bean.ModifyTypeBean;
import com.jealook.www.surface.bean.OrderLogisticsBean;
import com.jealook.www.surface.bean.PersonalInformationBean;
import com.jealook.www.surface.bean.ProductDetailsBean;
import com.jealook.www.surface.bean.PublishComment;
import com.jealook.www.surface.bean.RealNameDetailsBean;
import com.jealook.www.surface.bean.RealNameListBean;
import com.jealook.www.surface.bean.SearchListBean;
import com.jealook.www.surface.bean.SearchListListBean;
import com.jealook.www.surface.bean.TypeGoodsBean;
import com.jealook.www.surface.bean.UpdateImgBean;
import com.jealook.www.surface.bean.UserInfo;
import com.jealook.www.surface.bean.WeCatPayBean;
import com.jealook.www.surface.mvp.model.bean.AddressDetailsBean;
import com.jealook.www.utils.UserInfoBean;

import java.util.List;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import per.goweii.rxhttp.request.Api;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

/**
 * 描述：网络请求接口
 *
 * @author Cuizhen
 * @date 2018/9/4
 */
public class ProjectApi extends Api {

    public static ApiService api() {
        return api(ApiService.class);
    }

    public interface ApiCode {
        int TIME_OUT = 1000;                     // 请求延迟
        int REQUEST_ERROR = 1001;                // 请求方式错误
        int ILLEGAL_PARAMETER = 1002;            // 非法参数

        int SUCCESS = 2000;                      // 获取信息成功
        int SUCCESS_OLD = 104;                   // 获取信息成功 老版本的
        int SUCCESS_NO_DATA = 2001;              // 暂无相关数据

        int FAILED = 3000;                       // 获取信息失败
        int PHONE_EXIST = 3001;                  // 该手机号已注册过
        int PASSWARD_ERROR = 3002;               // 密码错误
        int PHONE_ILLEGAL = 3003;                // 手机号不合法
        int PHONE_NOT_BIND = 3004;               // 请绑定手机号
        int PHONE_NOT_REGIST = 3005;             // 该手机号未注册
        int REGIST_NONE_LOCATE = 3006;           // 注册时没有经纬度
        int PANDA_COIN_INSUFFICIENT = 3007;      // 熊猫币不足，请充值


        int ACCOUNT_NOT_ERROR = 4000;            // 数据错误

        int ACCOUNT_NOT_EXIST = 4001;            // 账号不存在
        int ACCOUNT_EXCEPTION = 4002;            // 账号异常,请重新登录
        int ACCOUNT_FROZEN = 4003;               // 该账户已被冻结,请联系管理员
        int ACCOUNT_DELETED = 4004;              // 该账户已被管理员删除

        int ERROR = 5000;                        // 访问异常
        int ERROR_NET = 5001;                    // 网络异常

        int PWD_HAD_BEEN_UPDATE = 6000;          // 密码已修改，请重新登录
    }

    public interface ApiConfig {
        String BASE_URL = Config.HTTP_HOST + Config.HTTP_VERSION;
    }


    public interface ApiService {


        /**
         * 0001---获取系统时间
         */
        @GET("public/get-sign")
        Observable<ResponseBean<SignBean>> getSign();


        /**
         * 0002---获取首页数据
         */
        @GET("index/get-index-data")
        Observable<ResponseBean<HomeDataBean>> getHomeData();

        /**
         * 0002---获取搜索页面数据
         */
        @GET("list/get-search")
        Observable<ResponseBean<SearchListBean>> getSearchData();


        /**
         * 0004---获取商品详情数据
         */
        @GET("shop/get-shop-info")
        Observable<ResponseBean<MoveDataBean>> getMoveData(@Query("goods_id") String goods_id,
                                                           @Query("attr") String search_attr);

        /**
         * 0004---评论页面数据
         */
        @GET("shop/get-shop-name")
        Observable<ResponseBean<PublishComment>> getPublicComment(@Query("goods_id") String goods_id,
                                                                  @Query("attr") String search_attr);


        /**
         * 0004---获取限时列表数据
         */
        @GET("list/get-discounts-data")
        Observable<ResponseBean<LimitedBean>> getLimitedData(@Query("page") int page,
                                                             @Query("limit") int limit);

        /**
         * 0004---获取分类列表数据
         */
        @GET("type/get-screen-list")
        Observable<ResponseBean<ClassifyBean>> getClassifyData(@Query("goods_name") String goods_name,
                                                               @Query("page") int page,
                                                               @Query("limit") int limit,
                                                               @Query("type") int type,
                                                               @Query("sort_key") String sort_key,
                                                               @Query("sort_value") String sort_value,
                                                               @Query("attr") String str);

        /**
         * 0004---获取分类列表数据
         */
        @GET("type/get-type-list")
        Observable<ResponseBean<List<ClassifyTypeBean>>> getTypeList();


        /**
         * 0004---获取地址列表数据
         */
        @GET("my/get-address-list")
        Observable<ResponseBean<List<AddressListBean>>> getAddressData();


        /**
         * 0004---地址详情页面
         */
        @GET("my/get-address-info")
        Observable<ResponseBean<AddressDetailsBean>> getAddressDetails(@Query("address_id") String address_id);

        /**
         * 0004---更改，编辑地址
         *
         * @param name
         * @param phone
         * @param address
         */
        @FormUrlEncoded
        @POST("my/edit-address")
        Observable<ResponseBean<List<AddressListBean>>> getEditressindex(@Field("province") String pId,
                                                                         @Field("city") String cId,
                                                                         @Field("district") String dId,
                                                                         @Field("address_name") String name,
                                                                         @Field("mobile") String phone,
                                                                         @Field("address") String address,
                                                                         @Field("is_default") String getIs_default,
                                                                         @Field("address_id") String getAddress_id);

        /**
         * 0004---更改，编辑地址
         */
        @FormUrlEncoded
        @POST("my/edit-address")
        Observable<ResponseBean<List<AddressListBean>>> getEditressindex_1(@Field("is_default") String getIs_default,
                                                                           @Field("address_id") String getAddress_id);


        /**
         * 0004---更改，编辑地址
         *
         * @param name
         * @param phone
         * @param address
         */
        @FormUrlEncoded
        @POST("my/add-address")
        Observable<ResponseBean<List<AddressListBean>>> getAddAddressindex(@Field("province") String pId,
                                                                           @Field("city") String cId,
                                                                           @Field("district") String dId,
                                                                           @Field("address_name") String name,
                                                                           @Field("mobile") String phone,
                                                                           @Field("address") String address,
                                                                           @Field("is_default") String getIs_default);


        /**
         * 0004---删除地址
         */
        @FormUrlEncoded
        @POST("my/del-address")
        Observable<ResponseBean<List<AddressListBean>>> getDeleteAddressindex(@Field("address_id") String address_id);


        /**
         * 0004---收藏商品
         */
        @FormUrlEncoded
        @POST("shop/collect")
        Observable<ResponseBean<Object>> getMoveCollectionShop(@Field("goods_id") String goods_id,
                                                               @Field("type") String mark);

        /**
         * 0004---意见反馈
         */
        @FormUrlEncoded
        @POST("my/feedback")
        Observable<ResponseBean<Object>> postFeedBack(@Field("content") String goods_id,
                                                      @Field("image") String imgFiles);

        /**
         * 0004---添加购物车
         */
        @FormUrlEncoded
        @POST("cart/add-cart")
        Observable<ResponseBean<Object>> getAddShopCar(@Field("goods_id") String goods_id,
                                                       @Field("product_id") String product_id,
                                                       @Field("num") String num);


        /**
         * 0004---购物车列表
         */
        @GET("cart/get-cart-list")
        Observable<ResponseBean<ShopCartListBean>> getShopListData(@Query("type") int type);


        /**
         * 0004---购物车加减
         */
        @FormUrlEncoded
        @POST("cart/set-shop-attr")
        Observable<ResponseBean<ShopCartListBean>> getAddAndReduce(@Field("type") int mark,
                                                                   @Field("num") String number,
                                                                   @Field("rec_id") String getRec_id);


        /**
         * 0004---删除购物车数据
         */
        @FormUrlEncoded
        @POST("cart/del-cart")
        Observable<ResponseBean<ShopCartListBean>> getDeleteData(@Field("rec_id") String getRec_id,
                                                                 @Field("is_all") String is_all);

        /**
         * 0004---修改商品规格
         */
        @FormUrlEncoded
        @POST("cart/set-shop-attr")
        Observable<ResponseBean<ModifyTypeBean>> getModifyType(@Field("type") int mark,
                                                               @Field("rec_id") String getRec_id,
                                                               @Field("num") String num,
                                                               @Field("product_id") String product_id);


        /**
         * 0004---选择类型
         */

        @GET("shop/get-product-list")
        Observable<ResponseBean<MoveDataBean>> getTypeShopData(@Query("goods_id") String goods_id);


        /**
         * 0004---修改全选状态
         */
        @FormUrlEncoded
        @POST("cart/set-shop-attr")
        Observable<ResponseBean<ShopCartListBean>> getSelectShopping(@Field("type") int mark,
                                                                     @Field("rec_id") String rec_id,
                                                                     @Field("is_check") int is_check,
                                                                     @Field("is_all") int is_all);

        /**
         * 0004---确认订单
         */
        @FormUrlEncoded
        @POST("order/confrim-order")
        Observable<ResponseBean<ConfirmOrderBean>> getConfirmOrderData(@Field("rec_id") String recId,
                                                                       @Field("goods_id") String goods_id,
                                                                       @Field("product_id") String product_id,
                                                                       @Field("num") String num);

        /**
         * 0004---确认订单
         */
        @FormUrlEncoded
        @POST("order/confrim-order")
        Observable<ResponseBean<ConfirmOrderBean>> getConfirmOrderData1(@Field("rec_id") String recId,
                                                                        @Field("goods_id") String goods_id,
                                                                        @Field("product_id") String product_id,
                                                                        @Field("num") String num,
                                                                        @Field("id") String type_id);

        /**
         * 0004---提交订单
         */
        @FormUrlEncoded
        @POST("order/submit-order")
        Observable<ResponseBean<WeCatPayBean>> postSubmitOrder(@Field("rec_id") String recIds,
                                                               @Field("goods_id") String goods_ids,
                                                               @Field("product_id") String product_ids,
                                                               @Field("num") String nums,
                                                               @Field("real_id") String real_ids,
                                                               @Field("address_id") String address_ids,
                                                               @Field("type") String types,
                                                               @Field("postscript") String confirmMessages,
                                                               @Field("order_id") String order_ids,
                                                               @Field("id") String bonus_id);

        /**
         * 0004---提交订单
         */
        @FormUrlEncoded
        @POST("order/submit-order")
        Observable<ResponseBean<ALiPayBean>> postALiSubmitOrder(@Field("rec_id") String recIds,
                                                                @Field("goods_id") String goods_ids,
                                                                @Field("product_id") String product_ids,
                                                                @Field("num") String nums,
                                                                @Field("real_id") String real_ids,
                                                                @Field("address_id") String address_ids,
                                                                @Field("type") String types,
                                                                @Field("postscript") String confirmMessages,
                                                                @Field("order_id") String order_ids,
                                                                @Field("id") String bonus_id);


        /**
         * 0004---下载优惠券未领取列表
         */
        @GET("shop/get-discount-list")
        Observable<ResponseBean<List<NotCouponListBean>>> getCouponListData(@Query("rec_id") String recIds,
                                                                            @Query("goods_id") String goods_ids,
                                                                            @Query("product_id") String product_ids,
                                                                            @Query("num") String nums);

        /**
         * 0004---下载优惠券已领取列表
         */
        @GET("my/get-my-discount-list")
        Observable<ResponseBean<List<AlreadyCouponListBean>>> getCouponListData1(@Query("rec_id") String recIds,
                                                                                 @Query("goods_id") String goods_ids,
                                                                                 @Query("product_id") String product_ids,
                                                                                 @Query("num") String nums);

        /**
         * 0004---领取优惠券
         */
        @GET("shop/get-discount")
        Observable<ResponseBean<Object>> getCollectCoupons(@Query("id") String type_id);


        /**
         * 0004---获取订单列表数据
         */
        @GET("order/get-order-list")
        Observable<ResponseBean<AllOrderListBean>> getOrderListData(@Query("page") int page,
                                                                    @Query("limit") int limit,
                                                                    @Query("type") int type);

        /**
         * 0004---取消订单
         */
        @FormUrlEncoded
        @POST("order/cancel")
        Observable<ResponseBean<AllOrderListBean>> getCelearOrderData(@Field("order_id") String order_id,
                                                                      @Field("type") String type);

        /**
         * 0004---签收订单
         */
        @GET("order/confirm-receipt")
        Observable<ResponseBean<SiginOrderBean>> getSignInOrderData(@Query("order_id") String order_id);


        /**
         * 0004---获取订单详情数据
         */
        @GET("order/get-order-info")
        Observable<ResponseBean<OrderDetailsBean>> getOederDetailsData(@Query("order_id") String getOrder_id);
        /**
         * 0004---历史足迹
         */
        @GET("list/get-browse-list")
        Observable<ResponseBean<BrowseListBean>> getBrowseListData(@Query("page") int page,
                                                                   @Query("limit") int limit);

        /**
         * 0004---收藏列表
         */
        @GET("shop/get-collect-list")
        Observable<ResponseBean<CollectionListBean>> getCollectionListData(@Query("page") int page,
                                                                           @Query("limit") int limit);

        /**
         * 0004---品牌列表
         */
        @GET("list/get-brand-list")
        Observable<ResponseBean<List<BrandListBean>>> getBrandList();

        /**
         * 0004---根据品牌筛选商品
         */
        @GET("list/get-brand-goods-list")
        Observable<ResponseBean<CommodityListBean>> getCommodityList(@Query("page") int page,
                                                                     @Query("limit") int limit,
                                                                     @Query("brand_id") String getBrand_id);

        /**
         * 0004--- 搜索页面，搜索商品列表
         */
        @GET("type/get-screen-list")
        Observable<ResponseBean<SearchListListBean>> getSearchListData(@Query("page") int page,
                                                                       @Query("limit") int limit,
                                                                       @Query("goods_name") String getBrand_id);


        /**
         * 0004---获取验证码
         */
        @GET("login/get-sms")
        Observable<ResponseBean<Object>> getVerificationCode(@Query("mobile") String mobile);


        /**
         * 0004---登录
         */
        @FormUrlEncoded
        @POST("login/login")
        Observable<ResponseBean<UserInfoBean>> getCheckCode(@Field("mobile") String mobile,
                                                            @Field("code") String code);

        /**
         * 0004---验证验证码
         */
        @FormUrlEncoded
        @POST("login/check-code")
        Observable<ResponseBean<Object>> getVerifyPhoneNumber(@Field("mobile") String mobile,
                                                              @Field("code") String code);

        /**
         * 0004---修改手机号
         */
        @FormUrlEncoded
        @POST("my/edit-mobile")
        Observable<ResponseBean<UserInfoBean>> getModifyPhoneNumber(@Field("mobile") String mobile,
                                                              @Field("code") String code);


        /**
         * 0004---微信登录
         */
        @FormUrlEncoded
        @POST("login/wechat-app-login")
        Observable<ResponseBean<UserInfoBean>> getWechatLogin(@Field("openid") String openId,
                                                              @Field("user_name") String nickName,
                                                              @Field("img_url") String headUrl);

        /**
         * 0004---获取物流信息
         */
        @GET("order/get-order-logistics")
        Observable<ResponseBean<OrderLogisticsBean>> getOrderLogistics(@Query("order_id") String order_id);


        /**
         * 0004---获取实名认证列表
         */
        @GET("my/get-real-list")
        Observable<ResponseBean<List<RealNameListBean>>> getRealNameListData();

        /**
         * 0004---编辑实名认证默认状态
         */
        @FormUrlEncoded
        @POST("my/edit-real")
        Observable<ResponseBean<List<RealNameListBean>>> getEditRealName(@Field("id") String id,
                                                                         @Field("is_default") String is_default);

        /**
         * 0004---删除实名认证
         */
        @FormUrlEncoded
        @POST("my/del-real")
        Observable<ResponseBean<List<RealNameListBean>>> getDeletRealName(@Field("id") String id);

        /**
         * 0004---下载实名认证详情
         */
        @GET("my/get-real-info")
        Observable<ResponseBean<RealNameDetailsBean>> getRealNameDetails(@Query("id") String id);

        /**
         * 0004---新增实名
         */
        @FormUrlEncoded
        @POST("my/add-real")
        Observable<ResponseBean<List<RealNameListBean>>> getAddRealName(@Field("name") String name,
                                                                        @Field("id_card") String idcard,
                                                                        @Field("is_default") String is_default);

        /**
         * 0004---编辑实名
         */
        @FormUrlEncoded
        @POST("my/edit-real")
        Observable<ResponseBean<List<RealNameListBean>>> getRealNameEdit(@Field("name") String name,
                                                                         @Field("id_card") String idcard,
                                                                         @Field("is_default") String is_default,
                                                                         @Field("id") String getId);


        /**
         * 0004---获取订单数量及用户信息
         */
        @GET("my/get-my-info")
        Observable<ResponseBean<PersonalInformationBean>> getPersonalInformation();

        /**
         * 0004---获取个人信息
         */
        @GET("my/get-user-info")
        Observable<ResponseBean<UserInfo>> getUserInfoData();

        /**
         * 0004---获取评论列表
         */
        @GET("shop/get-comment")
        Observable<ResponseBean<EvaluateListBean>> getEvaluateList(@Query("page") int page,
                                                                   @Query("limit") int limit,
                                                                   @Query("goods_id") String goods_id);

        /**
         * 0004---获取分类商品
         */
        @GET("list/get-type-goods")
        Observable<ResponseBean<TypeGoodsBean>> getTypeGoods(@Query("page") int page,
                                                             @Query("limit") int limit,
                                                             @Query("attr_id") String id);

        /**
         * 0004---一键登录
         */
        @FormUrlEncoded
        @POST("login/get-mobile-login")
        Observable<ResponseBean<UserInfoBean>> getMobileLogin(@Field("access_token") String access_token);


        /**
         * 0004---活动详情页面
         */
        @GET("list/get-active-info")
        Observable<ResponseBean<ProductDetailsBean>> getProductDetailsData(@Query("active_id") String id);


        /**
         * 1004--发表评价-上传图片
         */
        @Multipart
        @POST("public/img")
        Observable<ResponseBean<UpdateImgBean>> postUploadPhotos(@Part MultipartBody.Part img);


        /**
         * 1004--发表评价
         */
        @GET("order/set-appraise")
        Observable<ResponseBean<Object>> multigraph(@Query("image") String imgFiles,
                                                    @Query("order_id") String order_id,
                                                    @Query("rec_id") String rec_id,
                                                    @Query("content") String trim,
                                                    @Query("total_score") String total_score,
                                                    @Query("describe_score") String describe_score,
                                                    @Query("logistics_score") String logistics_score,
                                                    @Query("server_score") String server_score,
                                                    @Query("is_show") String is_show);

        /**
         * 1004--修改个人信息
         */
        @FormUrlEncoded
        @POST("my/set-user-info")
        Observable<ResponseBean<UserInfo>> postPersonalInformation(@Field("img_url") String imgUrl,
                                                                   @Field("user_name") String nicheng,
                                                                   @Field("sex") String sex);


        /**
         * 1004--会员详情
         */
        @GET("member/get-member-config")
        Observable<ResponseBean<MemberBean>> getMemberDetailData();

        /**
         * 1004--购买会员--微信
         */
        @FormUrlEncoded
        @POST("member/buy-member")
        Observable<ResponseBean<WeCatPayBean>> postPayMember(@Field("type") String type,
                                                       @Field("id") String memberId);

        /**
         * 1004--购买会员--支付宝
         */
        @FormUrlEncoded
        @POST("member/buy-member")
        Observable<ResponseBean<ALiPayBean>> postPayMember_2(@Field("type") String type,
                                                             @Field("id") String memberId);


    }
}