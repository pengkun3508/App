package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;

/**
 * @Description:
 * @Time:2020/6/30$
 * @Author:pk$
 */
public interface AboutUsView extends MvpView {
}
