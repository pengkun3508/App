package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.utils.CacheActivity;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.adapter.SearchListAdapter;
import com.jealook.www.surface.bean.SearchListListBean;
import com.jealook.www.surface.mvp.presenter.SearchListPresenter;
import com.jealook.www.surface.mvp.view.SearchListView;
import com.jealook.www.widgat.actionbar.ActionBarSimple;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @Description:搜索页面，进入搜索的商品列表
 * @Time:2020/5/25$
 * @Author:pk$
 */
public class SearchListActivity extends BaseActivity<SearchListPresenter> implements SearchListView {

    static String keyword;
    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;

    SearchListAdapter adapter;
    List<SearchListListBean.ListBean> listBean;

    int mark = 0;
    int page = 1;
    int lastItem = -1;
    int judge = 0;

    public static void startSelf(Context context, String keywords) {
        Intent intent = new Intent(context, SearchListActivity.class);
        context.startActivity(intent);
        keyword = keywords;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.activity_brand;
    }

    @Override
    protected SearchListPresenter initPresenter() {
        return new SearchListPresenter();
    }

    @Override
    protected void initView() {
        CacheActivity.addActivity(SearchListActivity.this);
        StatusBarUtils.setStatusBarMode(getActivity(), true);

        adapter = new SearchListAdapter(this);
        final GridLayoutManager manager5 = new GridLayoutManager(getActivity(), 2);
        recyclerView.setLayoutManager(manager5);
//        recyclerView.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(getActivity(), 0)));
//        recyclerView.addItemDecoration(new SpaceItemDecoration(0, 0));
        recyclerView.setAdapter(adapter);


        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                presenter.getSearchListData(page, 10, keyword);//下载商品详情数据
                judge = 0;
            }
        });


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
                int lastVisibleItem = manager.findLastCompletelyVisibleItemPosition();
                if (adapter.getData().size() - 5 == lastVisibleItem) {
                    if (lastItem != lastVisibleItem) {
                        lastItem = lastVisibleItem;
                        page++;
                        judge = 1;
                        presenter.getSearchListData(page, 10, keyword);//下载商品详情数据
                    }
                } else {
                    if (adapter.getData().size() - lastItem > 10) {
                        lastItem = adapter.getData().size() - 5;
                        page++;
                        judge = 1;
                        presenter.getSearchListData(page, 10, keyword);//下载商品详情数据
                    }
                }
            }
        });

        adapter.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                MoveAbooutActivity_1.startSelf(getActivity(), adapter.getData().get(position).getGoods_id(), adapter.getData().get(position).getSearch_attr());
            }
        });

    }

    @Override
    protected void loadData() {
        presenter.getSearchListData(page, 10, keyword);//下载商品详情数据
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    //成功
    @Override
    public void getSearchListDataSuccess(int code, SearchListListBean data) {
        listBean = data.getList();
        smartRefreshLayout.finishRefresh();
        if (judge == 0) {
            adapter.setData(data.getList());
        } else {
            adapter.addData(data.getList());
        }


    }

    //失败
    @Override
    public void getSearchListDataFail(int code, String msg) {
        Log.e("SearchListActivity", "==code==" + code);
//        if (code == 3000) {
//            SearchListListBean data = new SearchListListBean();
//            adapter.setData(data.getList());
//            presenter.dismissLoading();
//        }
    }
}
