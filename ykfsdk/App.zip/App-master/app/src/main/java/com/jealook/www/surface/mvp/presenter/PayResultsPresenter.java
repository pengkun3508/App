package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.PayResultsView;
import com.jealook.www.surface.mvp.view.ProblemFeedbackView;

public class PayResultsPresenter extends MvpPresenter<PayResultsView> {
}
