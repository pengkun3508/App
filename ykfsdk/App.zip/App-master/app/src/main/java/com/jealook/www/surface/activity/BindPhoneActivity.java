package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.mvp.presenter.BindPhonePresenter;
import com.jealook.www.surface.mvp.view.BindPhoneView;

import butterknife.OnClick;


/**
     * @Description:绑定手机号
     * @Time:2020/4/14 9:37
     * @Author:pk
     */
public class BindPhoneActivity extends BaseActivity<BindPhonePresenter> implements BindPhoneView {

    public static void startSelf(Context context) {
        Intent intent = new Intent(context, BindPhoneActivity.class);
        context.startActivity(intent);
    }
    @Override
    protected int getLayoutId() {
        return R.layout.activity_bind_phone;
    }

    @Override
    protected BindPhonePresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
    }

    @Override
    protected void loadData() {

    }


    @OnClick({R.id.tv_ok})
    @Override
    public void onClick(View v) {
        super.onClick(v);
    }

    @Override
    public boolean onClickWithoutLogin(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.tv_ok:
                finish();
                break;

        }
        return false;
    }
}
