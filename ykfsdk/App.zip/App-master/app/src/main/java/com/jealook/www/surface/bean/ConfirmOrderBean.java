package com.jealook.www.surface.bean;

import java.util.List;

import per.goweii.rxhttp.request.base.BaseBean;

/**
 * @Description:
 * @Time:2020/5/12$
 * @Author:pk$
 */
public class ConfirmOrderBean extends BaseBean {
    /**
     * order_ad : {"value":"","type":"","id":"","photo":"","list":{"goods_id":"","search_attr":"","active_id":"","url":"","text":"","id":""}}
     * goods_price : 150
     * price : 150.00
     * post_fee : 0.00
     * shop_list : [{"product_id":"7256","goods_id":"89","product_price":"75.00","preferential_price":"45.00","goods_attr":"3313|3338|5592","color_id":"3338","search_attr":"3313|3338","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","suppliers_id":"1","goods_name":"中国版 Chouchou日抛 甜橘蜜茶 10枚","bonus_type_id":"0","goods_attr_name":"甜橘蜜茶,10枚,0度","goods_thumb":"http://img.jealook.com/backend/20200603/1591168394_2042.png","number":"1"},{"product_id":"7262","goods_id":"89","product_price":"75.00","preferential_price":"45.00","goods_attr":"3313|3319|3338","color_id":"3338","search_attr":"3313|3338","is_promote":0,"promote_start_date":"1594051200","promote_end_date":"1594656000","suppliers_id":"1","goods_name":"中国版 Chouchou日抛 甜橘蜜茶 10枚","bonus_type_id":"0","goods_attr_name":"甜橘蜜茶,10枚,225度","goods_thumb":"http://img.jealook.com/backend/20200603/1591168394_2042.png","number":"1"}]
     * address_list : [{"address_refer":"北京 北京市 东城区","address":"外婆轰轰轰胡","address_name":"彭堃","mobile":"15129005255","address_id":"128","is_default":"1"}]
     * real_list : [{"id_card":"6****************7","name":"彭堃","is_default":"1","id":"73"}]
     * rec_id : 629,628
     * coupon_price : 0.00
     * bonus_info : {}
     */

    private OrderAdBean order_ad;
    private int goods_price;
    private String price;
    private String post_fee;
    private String rec_id;
    private String coupon_price;
    private BonusInfoBean bonus_info;
    private List<ShopListBean> shop_list;
    private List<AddressListBean> address_list;
    private List<RealListBean> real_list;

    public OrderAdBean getOrder_ad() {
        return order_ad;
    }

    public void setOrder_ad(OrderAdBean order_ad) {
        this.order_ad = order_ad;
    }

    public int getGoods_price() {
        return goods_price;
    }

    public void setGoods_price(int goods_price) {
        this.goods_price = goods_price;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPost_fee() {
        return post_fee;
    }

    public void setPost_fee(String post_fee) {
        this.post_fee = post_fee;
    }

    public String getRec_id() {
        return rec_id;
    }

    public void setRec_id(String rec_id) {
        this.rec_id = rec_id;
    }

    public String getCoupon_price() {
        return coupon_price;
    }

    public void setCoupon_price(String coupon_price) {
        this.coupon_price = coupon_price;
    }

    public BonusInfoBean getBonus_info() {
        return bonus_info;
    }

    public void setBonus_info(BonusInfoBean bonus_info) {
        this.bonus_info = bonus_info;
    }

    public List<ShopListBean> getShop_list() {
        return shop_list;
    }

    public void setShop_list(List<ShopListBean> shop_list) {
        this.shop_list = shop_list;
    }

    public List<AddressListBean> getAddress_list() {
        return address_list;
    }

    public void setAddress_list(List<AddressListBean> address_list) {
        this.address_list = address_list;
    }

    public List<RealListBean> getReal_list() {
        return real_list;
    }

    public void setReal_list(List<RealListBean> real_list) {
        this.real_list = real_list;
    }

    public static class OrderAdBean {
        /**
         * value : 1595212451
         * type : 1598233146
         * id : 101
         * photo : 11
         * list : {}
         */

        private String value;
        private String type;
        private String id;
        private String photo;
        private ListBean list;

        public void setValue(String value) {
            this.value = value;
        }

        public void setType(String type) {
            this.type = type;
        }

        public void setId(String id) {
            this.id = id;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public void setList(ListBean list) {
            this.list = list;
        }

        public String getValue() {
            return value;
        }

        public String getType() {
            return type;
        }

        public String getId() {
            return id;
        }

        public String getPhoto() {
            return photo;
        }

        public ListBean getList() {
            return list;
        }

        public static class ListBean {

            private String goods_id;
            private String search_attr;
            private String active_id;
            private String url;
            private String text;
            private String id;

            public String getGoods_id() {
                return goods_id;
            }

            public void setGoods_id(String goods_id) {
                this.goods_id = goods_id;
            }

            public String getSearch_attr() {
                return search_attr;
            }

            public void setSearch_attr(String search_attr) {
                this.search_attr = search_attr;
            }

            public String getActive_id() {
                return active_id;
            }

            public void setActive_id(String active_id) {
                this.active_id = active_id;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }
        }



    }





    public static class BonusInfoBean {
        /**
         * start_time : 1595212451
         * end_time : 1598233146
         * id : 101
         * discount_id : 11
         * coupon_name : 折扣券-test-2
         * use_shop_type : 3
         * reduced : 6
         * type : 1
         * min_money : 100.00
         */

        private String start_time;
        private String end_time;
        private String id;
        private String discount_id;
        private String coupon_name;
        private String use_shop_type;
        private String reduced;
        private String type;
        private String min_money;

        public String getStart_time() {
            return start_time;
        }

        public void setStart_time(String start_time) {
            this.start_time = start_time;
        }

        public String getEnd_time() {
            return end_time;
        }

        public void setEnd_time(String end_time) {
            this.end_time = end_time;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getDiscount_id() {
            return discount_id;
        }

        public void setDiscount_id(String discount_id) {
            this.discount_id = discount_id;
        }

        public String getCoupon_name() {
            return coupon_name;
        }

        public void setCoupon_name(String coupon_name) {
            this.coupon_name = coupon_name;
        }

        public String getUse_shop_type() {
            return use_shop_type;
        }

        public void setUse_shop_type(String use_shop_type) {
            this.use_shop_type = use_shop_type;
        }

        public String getReduced() {
            return reduced;
        }

        public void setReduced(String reduced) {
            this.reduced = reduced;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getMin_money() {
            return min_money;
        }

        public void setMin_money(String min_money) {
            this.min_money = min_money;
        }
    }

    public static class ShopListBean {
        /**
         * product_id : 7256
         * goods_id : 89
         * product_price : 75.00
         * preferential_price : 45.00
         * goods_attr : 3313|3338|5592
         * color_id : 3338
         * search_attr : 3313|3338
         * is_promote : 0
         * promote_start_date : 1594051200
         * promote_end_date : 1594656000
         * suppliers_id : 1
         * goods_name : 中国版 Chouchou日抛 甜橘蜜茶 10枚
         * bonus_type_id : 0
         * goods_attr_name : 甜橘蜜茶,10枚,0度
         * goods_thumb : http://img.jealook.com/backend/20200603/1591168394_2042.png
         * number : 1
         */

        private String product_id;
        private String goods_id;
        private String product_price;
        private String preferential_price;
        private String goods_attr;
        private String color_id;
        private String search_attr;
        private int is_promote;
        private String promote_start_date;
        private String promote_end_date;
        private String suppliers_id;
        private String goods_name;
        private String bonus_type_id;
        private String goods_attr_name;
        private String goods_thumb;
        private String number;

        public String getProduct_id() {
            return product_id;
        }

        public void setProduct_id(String product_id) {
            this.product_id = product_id;
        }

        public String getGoods_id() {
            return goods_id;
        }

        public void setGoods_id(String goods_id) {
            this.goods_id = goods_id;
        }

        public String getProduct_price() {
            return product_price;
        }

        public void setProduct_price(String product_price) {
            this.product_price = product_price;
        }

        public String getPreferential_price() {
            return preferential_price;
        }

        public void setPreferential_price(String preferential_price) {
            this.preferential_price = preferential_price;
        }

        public String getGoods_attr() {
            return goods_attr;
        }

        public void setGoods_attr(String goods_attr) {
            this.goods_attr = goods_attr;
        }

        public String getColor_id() {
            return color_id;
        }

        public void setColor_id(String color_id) {
            this.color_id = color_id;
        }

        public String getSearch_attr() {
            return search_attr;
        }

        public void setSearch_attr(String search_attr) {
            this.search_attr = search_attr;
        }

        public int getIs_promote() {
            return is_promote;
        }

        public void setIs_promote(int is_promote) {
            this.is_promote = is_promote;
        }

        public String getPromote_start_date() {
            return promote_start_date;
        }

        public void setPromote_start_date(String promote_start_date) {
            this.promote_start_date = promote_start_date;
        }

        public String getPromote_end_date() {
            return promote_end_date;
        }

        public void setPromote_end_date(String promote_end_date) {
            this.promote_end_date = promote_end_date;
        }

        public String getSuppliers_id() {
            return suppliers_id;
        }

        public void setSuppliers_id(String suppliers_id) {
            this.suppliers_id = suppliers_id;
        }

        public String getGoods_name() {
            return goods_name;
        }

        public void setGoods_name(String goods_name) {
            this.goods_name = goods_name;
        }

        public String getBonus_type_id() {
            return bonus_type_id;
        }

        public void setBonus_type_id(String bonus_type_id) {
            this.bonus_type_id = bonus_type_id;
        }

        public String getGoods_attr_name() {
            return goods_attr_name;
        }

        public void setGoods_attr_name(String goods_attr_name) {
            this.goods_attr_name = goods_attr_name;
        }

        public String getGoods_thumb() {
            return goods_thumb;
        }

        public void setGoods_thumb(String goods_thumb) {
            this.goods_thumb = goods_thumb;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }
    }

    public static class AddressListBean {
        /**
         * address_refer : 北京 北京市 东城区
         * address : 外婆轰轰轰胡
         * address_name : 彭堃
         * mobile : 15129005255
         * address_id : 128
         * is_default : 1
         */

        private String address_refer;
        private String address;
        private String address_name;
        private String mobile;
        private String address_id;
        private String is_default;

        public String getAddress_refer() {
            return address_refer;
        }

        public void setAddress_refer(String address_refer) {
            this.address_refer = address_refer;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getAddress_name() {
            return address_name;
        }

        public void setAddress_name(String address_name) {
            this.address_name = address_name;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getAddress_id() {
            return address_id;
        }

        public void setAddress_id(String address_id) {
            this.address_id = address_id;
        }

        public String getIs_default() {
            return is_default;
        }

        public void setIs_default(String is_default) {
            this.is_default = is_default;
        }
    }

    public static class RealListBean {
        /**
         * id_card : 6****************7
         * name : 彭堃
         * is_default : 1
         * id : 73
         */

        private String id_card;
        private String name;
        private String is_default;
        private String id;

        public String getId_card() {
            return id_card;
        }

        public void setId_card(String id_card) {
            this.id_card = id_card;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIs_default() {
            return is_default;
        }

        public void setIs_default(String is_default) {
            this.is_default = is_default;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }
}



