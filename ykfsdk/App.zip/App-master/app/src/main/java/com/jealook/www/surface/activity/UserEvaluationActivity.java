package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.mvp.presenter.AddressPresenter;
import com.jealook.www.surface.mvp.presenter.UserEvaluationPresenter;
import com.jealook.www.surface.mvp.view.AddressView;
import com.jealook.www.surface.mvp.view.UserEvaluationView;

public class UserEvaluationActivity extends BaseActivity<UserEvaluationPresenter> implements UserEvaluationView {


    public static void startSelf(Context context) {
        Intent intent = new Intent(context, UserEvaluationActivity.class);
        context.startActivity(intent);
    }
    @Override
    protected int getLayoutId() {
        return R.layout.activity_user_evaluation;

    }

    @Override
    protected UserEvaluationPresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
    }

    @Override
    protected void loadData() {

    }
}
