package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dm.lib.core.listener.SimpleCallback;
import com.dm.lib.utils.AppInfoUtils;
import com.dm.lib.utils.SPUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.common.Constant;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.surface.dialog.UpdateDialog;
import com.jealook.www.surface.mvp.presenter.AboutUsPresenter;
import com.jealook.www.surface.mvp.view.AboutUsView;
import com.jealook.www.utils.IntoShopUtils;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @Description: 关于我们
 * @Time:2020/6/30$
 * @Author:pk$
 */
public class AboutUsActivity extends BaseActivity<AboutUsPresenter> implements AboutUsView {


    @BindView(R.id.about_pingfen)
    LinearLayout aboutPingfen;
    @BindView(R.id.about_update)
    LinearLayout aboutUpdate;
    @BindView(R.id.about_company)
    LinearLayout aboutCompany;
    @BindView(R.id.about_guize)
    LinearLayout aboutGuize;
    @BindView(R.id.version_no)
    TextView versionNo;

    private UpdateDialog updateDialog = null;
    SignBean signBean;


    public static void startSelf(Context context) {
        Intent intent = new Intent(context, AboutUsActivity.class);
        context.startActivity(intent);

    }


    @Override
    protected int getLayoutId() {
        return R.layout.activity_about_us;
    }

    @Override
    protected AboutUsPresenter initPresenter() {
        return new AboutUsPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        versionNo.setText("V"+AppInfoUtils.getVersionName());

    }

    @Override
    protected void loadData() {

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @OnClick({R.id.about_pingfen, R.id.about_update, R.id.about_company, R.id.about_guize})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.about_pingfen://评分
                IntoShopUtils.toQQDownload(this, "com.jealook.www");
                break;
            case R.id.about_update://更新
                String signBeanSting = SPUtils.getInstance().get(Constant.KEY_SIGN_BEAN, "");
                if (signBeanSting != null && !signBeanSting.equals("")) {
                    try {
                        Log.e("更新版本", "==signBeanSting===" + signBeanSting);
                        signBean = new Gson().fromJson(signBeanSting, SignBean.class);
                        Log.e("更新版本", "==signBean===" + signBean);
                        Log.e("更新版本", "==getVersion===" + signBean.getVersion());
                        Log.e("更新版本", "==getVersion===" + signBean.getVersion());
                        Log.e("更新版本", "==getMust===" + signBean.getVersion().getMust());
                        //1：最新版本；2：强制更新；3：提示更新；4：手动更新
                        if (signBean.getVersion().getMust() == 3) {
                            if (updateDialog == null) {
                                updateDialog = UpdateDialog.with(getActivity(), signBean.getVersion())
                                        .setOnDismissListener(new SimpleCallback<Void>() {
                                            @Override
                                            public void onResult(Void data) {
                                                updateDialog = null;
                                            }
                                        });
                                updateDialog.show();
                            }
                        } else if (signBean.getVersion().getMust() != 2) {
                            Toast.makeText(this, "当前版本为：V" + AppInfoUtils.getVersionName() + "，暂无新版本", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JsonSyntaxException ignore) {
                        Log.e("更新版本", "==JsonSyntaxException===" + ignore);
                    }
                } else {
                    Toast.makeText(this, "当前版本为：V" + AppInfoUtils.getVersionName() + "，暂无新版本", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.about_company://公司信息
                WebActivity.startSelf(getActivity(), "http://shop.jealook.com/v1/html/article-info?id=116");
                break;
            case R.id.about_guize://协议与规则
//                WebActivity.startSelf(getActivity(), "http://shop.jealook.com/v1/html/article-info?id=119");
                ProtocolPrivacyActivity.startSelf(getContext());
                break;
        }
    }


}

