package com.jealook.www.surface.bean;

import java.util.List;

import per.goweii.rxhttp.request.base.BaseBean;

/**
 * @Description:
 * @Time:2020/6/2$
 * @Author:pk$
 */
public class OrderLogisticsBean extends BaseBean {
    /**
     * order_sn : 202005291610479526559614
     * create_time : 2020-05-29 16:10:47
     * traces : [{"AcceptTime":"2020-05-29 16:10:47","AcceptStation":"您提交了订单，请等待系统确认"},{"AcceptTime":"1970-01-01 08:00:00","AcceptStation":"您的订单已经进入仓库准备出库"}]
     */

    private String order_sn;
    private String create_time;
    private List<TracesBean> traces;

    public String getOrder_sn() {
        return order_sn;
    }

    public void setOrder_sn(String order_sn) {
        this.order_sn = order_sn;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public List<TracesBean> getTraces() {
        return traces;
    }

    public void setTraces(List<TracesBean> traces) {
        this.traces = traces;
    }

    public static class TracesBean {
        /**
         * AcceptTime : 2020-05-29 16:10:47
         * AcceptStation : 您提交了订单，请等待系统确认
         */

        private String AcceptTime;
        private String AcceptStation;

        public String getAcceptTime() {
            return AcceptTime;
        }

        public void setAcceptTime(String AcceptTime) {
            this.AcceptTime = AcceptTime;
        }

        public String getAcceptStation() {
            return AcceptStation;
        }

        public void setAcceptStation(String AcceptStation) {
            this.AcceptStation = AcceptStation;
        }
    }
}
