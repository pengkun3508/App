package com.jealook.www.surface.mvp.model.bean;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/4/11
 */
public class ExtraBean {
    /**
     * type : 2
     * data : {"id":"2"}
     */

    private String type;
    private String data;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
