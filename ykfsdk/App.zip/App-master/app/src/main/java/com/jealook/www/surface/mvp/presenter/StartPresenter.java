package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.StartView;


/**
 * 描述：
 *
 * @author Cuizhen
 * @date 2018/9/4
 */
public class StartPresenter extends MvpPresenter<StartView> {
}
