package com.jealook.www.surface.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.surface.activity.UserEvaluationActivity;

import butterknife.BindView;

public class PurchaseAdapter extends BaseStateAdapter<String, PurchaseAdapter.PurchaseHolder> {
    int type;
    public void setType(int type){
        this.type=type;
    }

    @Override
    protected PurchaseHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new PurchaseHolder(inflate(parent, R.layout.rv_item_purchase));
    }

    class PurchaseHolder extends BaseHolder<String> {

        @BindView(R.id.tv_type)
        TextView tvType;
        @BindView(R.id.iv_img)
        ImageView ivImg;
        @BindView(R.id.tv_title)
        TextView tvTitle;
        @BindView(R.id.tv_title_type)
        TextView tvTitleType;
        @BindView(R.id.tv_price)
        TextView tvPrice;
        @BindView(R.id.tv_ko)
        TextView tvKo;

        PurchaseHolder(View itemView) {
            super(itemView);
            tvType=getView(R.id.tv_type);
            ivImg=getView(R.id.iv_img);
            tvTitle=getView(R.id.tv_title);
            tvTitleType=getView(R.id.tv_title_type);
            tvPrice=getView(R.id.tv_price);
            tvKo=getView(R.id.tv_ko);

        }

        @Override
        protected void bindData(String data) {
            if (type==0) {
                tvType.setText("等待买家付款");
                tvKo.setText("付款");
            }else  if (type==1) {
                tvType.setText("进行中");
                tvKo.setText("查看");
            }else  if (type==2) {
                tvType.setText("交易成功");
                tvKo.setText("评价");
                tvKo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        UserEvaluationActivity.startSelf(tvKo.getContext());
                    }
                });
            }
        }


    }
}