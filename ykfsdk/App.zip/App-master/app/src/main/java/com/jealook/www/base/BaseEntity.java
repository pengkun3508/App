package com.jealook.www.base;

import java.io.Serializable;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2018/12/12
 */
public class BaseEntity implements Serializable {
}
