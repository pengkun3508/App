package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.utils.UserInfoBean;

public interface MainView extends MvpView {
    void getMainSuccess(int code, UserInfoBean data);

    void getMainFail(int code, String msg);
}
