package com.jealook.www.surface.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.utils.ImageLoader;

/**
 * @Description:
 * @Time:2020/5/6$
 * @Author:pk$
 */
public class CommentImgAdapter extends BaseStateAdapter<String, CommentImgAdapter.CommentImgHolderr> {
    Context context;

    public CommentImgAdapter(Context context) {
        super();
        this.context = context;
    }

    @Override
    protected CommentImgHolderr getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new CommentImgHolderr(inflate(parent, R.layout.details_imag_item));
    }

    class CommentImgHolderr extends BaseHolder<String> {

        ImageView details_img;

        CommentImgHolderr(View itemView) {
            super(itemView);
            details_img = getView(R.id.details_img);
        }

        @Override
        protected void bindData(String data) {

            Log.e("评论图片", "==评论图片==" + data);
            details_img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            ImageLoader.image(context,details_img,data);

//            Glide.with(context)
//                    .load(data)
//                    .into(details_img);

        }


    }

}


