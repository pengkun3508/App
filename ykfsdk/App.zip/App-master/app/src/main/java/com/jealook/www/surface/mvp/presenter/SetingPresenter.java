package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.SetingView;
import com.jealook.www.surface.mvp.view.StartView;

public class SetingPresenter extends MvpPresenter<SetingView> {
}
