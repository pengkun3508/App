package com.jealook.www.surface.mvp.model.bean;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/4/11
 */
public class BannerDataBean {
    private String  id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
