package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.surface.bean.SearchListBean;

public interface SearchView extends MvpView {
    void getSearchDataSuccess(int code, SearchListBean data);

    void getSearchDataFail(int code, String msg);
}
