package com.jealook.www.surface.fragment;


import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.sdk.android.man.MANService;
import com.alibaba.sdk.android.man.MANServiceProvider;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseFragment;
import com.jealook.www.common.Constant;
import com.jealook.www.event.LoginDataEvent;
import com.jealook.www.event.MyPersonalJudgeEvent;
import com.jealook.www.event.PostWechatEvent;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.activity.AboutUsActivity;
import com.jealook.www.surface.activity.AddressActivity;
import com.jealook.www.surface.activity.AllOrderActivity;
import com.jealook.www.surface.activity.BrowseActivity;
import com.jealook.www.surface.activity.CollectionActivity;
import com.jealook.www.surface.activity.CouponActivity;
import com.jealook.www.surface.activity.EditDataActivity;
import com.jealook.www.surface.activity.LoginActivity;
import com.jealook.www.surface.activity.MemberActivity;
import com.jealook.www.surface.activity.ModifyPhoneActivity;
import com.jealook.www.surface.activity.ProblemFeedbackActivity;
import com.jealook.www.surface.activity.RealNameActivity;
import com.jealook.www.surface.bean.PersonalInformationBean;
import com.jealook.www.surface.mvp.presenter.MyFragmentPresenter;
import com.jealook.www.surface.mvp.view.MyFragmentView;
import com.jealook.www.utils.AppUtils;
import com.jealook.www.utils.CacheActivity;
import com.jealook.www.utils.ImageLoader;
import com.jealook.www.utils.UserInfoBean;
import com.jealook.www.utils.UserUtils;
import com.makeramen.roundedimageview.RoundedImageView;
import com.mobile.auth.gatewayauth.AuthRegisterXmlConfig;
import com.mobile.auth.gatewayauth.AuthUIConfig;
import com.mobile.auth.gatewayauth.PhoneNumberAuthHelper;
import com.mobile.auth.gatewayauth.TokenResultListener;
import com.mobile.auth.gatewayauth.model.TokenRet;
import com.mobile.auth.gatewayauth.ui.AbstractPnsViewDelegate;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.ByteArrayOutputStream;

import butterknife.BindView;
import butterknife.OnClick;


/**
 * @Description:我的
 * @Time:2020/4/1 17:02
 * @Author:pk
 */
public class MyFragment extends BaseFragment<MyFragmentPresenter> implements MyFragmentView {

    @BindView(R.id.cat_avatar)
    RoundedImageView catAvatar;//头像
    @BindView(R.id.sign_register_text)
    TextView signRegisterText;//登录、注册
    @BindView(R.id.youhuiquan_layout)
    LinearLayout youhuiquanLayout;//优惠券
    @BindView(R.id.all_order_text)
    TextView allOrderText;//查看全部订单
    @BindView(R.id.daifukuan_layout)
    LinearLayout daifukuanLayout;//代付款
    @BindView(R.id.daifahuo_layout)
    LinearLayout daifahuoLayout;//代发货
    @BindView(R.id.daishouhuo_layout)
    LinearLayout daishouhuoLayout;//待收货
    @BindView(R.id.daipingjia_layout)
    LinearLayout daipingjiaLayout;//待评价
    @BindView(R.id.tuihuanhuo_layout)
    LinearLayout tuihuanhuoLayout;//退换货
    @BindView(R.id.me_shoucang)
    LinearLayout meShoucang;//我的收藏
    @BindView(R.id.me_address)
    LinearLayout meAddress;//收货地址
    @BindView(R.id.me_realname)
    LinearLayout meRealname;//实名认证
    @BindView(R.id.me_wenti)
    LinearLayout meWenti;//问题反馈
    @BindView(R.id.me_guanyu)
    LinearLayout meGuanyu;//关于我们
    @BindView(R.id.me_share)
    LinearLayout meShare;//分享

    @BindView(R.id.my_member_add)
    TextView myMemberAdd;//立即开通
    @BindView(R.id.my_member_date)
    TextView myMemberDate;//到期时间

    UserInfoBean userInfoBean;
    @BindView(R.id.daifukuan_text)
    TextView daifukuanText;//待付款数量
    @BindView(R.id.daifahuo_text)
    TextView daifahuoText;//待发货数量
    @BindView(R.id.daishouhuo_text)
    TextView daishouhuoText;//待收货数量
    @BindView(R.id.daipingjia_text)
    TextView daipingjiaText;//待评价数量
    @BindView(R.id.tuihuanhuo_text)
    TextView tuihuanhuoText;//退换货数量
    @BindView(R.id.my_collect_count)
    TextView myCollectCount;//收藏数量
    @BindView(R.id.my_points_count)
    TextView myPointsCount;//积分数量
    @BindView(R.id.my_browse_count)
    TextView myBrowseCount;//浏览数量
    @BindView(R.id.my_discount_count)
    TextView myDiscountCount;//优惠券数量
    @BindView(R.id.my_browse_layout)
    LinearLayout myBrowseLayout;//浏览历史


    private int mScreenWidthDp;
    private int mScreenHeightDp;
    private PhoneNumberAuthHelper mAlicomAuthHelper;
    private TokenResultListener mTokenListener;

    private IWXAPI wxAPI;

    public PopupWindow popupwindow;


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_me_1;
    }

    @Override
    protected MyFragmentPresenter initPresenter() {
        return new MyFragmentPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        ImageLoader.userIcon(getActivity(), catAvatar, UserUtils.getInstance().getUserInfo().getImg_url());
//        if (UserUtils.getInstance().getUserInfo().getUser_name().equals("登录/注册")) {
//            signRegisterText.setText(UserUtils.getInstance().getUserInfo().getUser_name());
//        }

        wxAPI = WXAPIFactory.createWXAPI(getActivity(), Constant.WECHAT_APPID, true);
        wxAPI.registerApp(Constant.WECHAT_APPID);

        inits();

    }


    @Override
    protected void loadData() {
//        presenter.getAppUpdate();//下载时间
        presenter.getPersonalInformation();//下载数据

    }


    @OnClick({R.id.cat_avatar, R.id.sign_register_text, R.id.youhuiquan_layout, R.id.all_order_text, R.id.daifukuan_layout, R.id.daifahuo_layout, R.id.daishouhuo_layout,
            R.id.me_realname, R.id.daipingjia_layout, R.id.tuihuanhuo_layout, R.id.me_shoucang, R.id.me_address, R.id.me_wenti, R.id.me_guanyu, R.id.me_share, R.id.my_member_add,
            R.id.my_browse_layout})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.cat_avatar://头像s
            case R.id.sign_register_text://登录注册
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    EditDataActivity.startSelf(getContext());
                } else {
                    showLoadingDialog();
                    mAlicomAuthHelper.getLoginToken(getActivity(), 0);
                }
                break;
            case R.id.youhuiquan_layout://优惠券
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    CouponActivity.startSelf(getContext());
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.all_order_text://查看全部订单
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    AllOrderActivity.startSelf(getContext(), 0);
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.daifukuan_layout://代付款
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    AllOrderActivity.startSelf(getContext(), 1);
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.daifahuo_layout://代发货
                break;
            case R.id.daishouhuo_layout://待收货
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    AllOrderActivity.startSelf(getContext(), 2);
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.daipingjia_layout://待评价
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    AllOrderActivity.startSelf(getContext(), 3);
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.tuihuanhuo_layout://退换货
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    AllOrderActivity.startSelf(getContext(), 4);
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.me_shoucang://我的收藏
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    CollectionActivity.startSelf(getContext());
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.me_address://收货地址
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    AddressActivity.startSelf(getActivity(), "1");
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.me_realname://实名认证
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    RealNameActivity.startSelf(getActivity(), "1");
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.me_wenti://问题反馈
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    ProblemFeedbackActivity.startSelf(getContext());
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.me_guanyu://关于我们
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    AboutUsActivity.startSelf(getContext());
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.me_share://分享
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    return;
                } else {
                    initmPopupWindowView();
                    popupwindow.showAtLocation(getActivity().getWindow().getDecorView(), Gravity.CENTER, 0, 0);
                }

                break;
            case R.id.my_member_add://立即开通会员
                if (!UserUtils.getInstance().getUserId().equals("")) {
                    MemberActivity.startSelf(getContext(), "1");//会员购买入口
                } else {
                    Toast.makeText(getActivity(), "您还未登录，请先登录", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.my_browse_layout://浏览历史
                BrowseActivity.startSelf(getActivity());
                break;
        }
    }

    private void initmPopupWindowView() {
        LinearLayout wx_py_btn, wx_pyq_btn;

        TextView share_cancel_btn;
        // // 获取自定义布局文件pop.xml的视图
        View customView = getLayoutInflater().inflate(R.layout.share_layout, null, false);
        wx_py_btn = customView.findViewById(R.id.wx_py_btn);//好友
        wx_pyq_btn = customView.findViewById(R.id.wx_pyq_btn);//朋友圈
        share_cancel_btn = customView.findViewById(R.id.share_cancel_btn);//取消

        // 创建PopupWindow实例,先宽度，后高度
        popupwindow = new PopupWindow(customView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        // 设置动画效果 [R.style.AnimationFade 是自己事先定义好的]
//        popupwindow.setAnimationStyle(R.style.AnimationFade);
        // 自定义view添加触摸事件
        customView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
                return false;
            }
        });

        //初始化一个WXWebpageObject，填写url
        WXWebpageObject webpage = new WXWebpageObject();

        if (!UserUtils.getInstance().getUserId().equals("")) {//已登录
            webpage.webpageUrl = "http://h5.jealook.com/share/index.html?code=" + UserUtils.getInstance().getUserId();
        } else {//未登录
            webpage.webpageUrl = "http://h5.jealook.com/share/index.html?code=";
        }


        //用 WXWebpageObject 对象初始化一个 WXMediaMessage 对象
        WXMediaMessage msg = new WXMediaMessage(webpage);
        msg.title = "Jealook美瞳商城 ";
        msg.description = "一家专业销售隐形眼镜彩片的电商购物平台，涵盖众多知名隐形眼镜品牌，款式全、数量多、物美价廉，秉承“正品、价优、快速”的理念，足不出户即可享受方便、快捷的购物体验。";
        Bitmap thumbBmp = BitmapFactory.decodeResource(getResources(), R.drawable.jeal_shear_logo);
        // Bitmap thumbBmp = BitmapFactory.decodeResource(getActivity().getResources(), R.mipmap.ic_launcher);
        Log.e("分享", "==thumbBmp==" + thumbBmp);
        msg.thumbData = bmpToByteArray(thumbBmp, true);

        //构造一个Req
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("webpage");
        req.message = msg;


        //微信好友
        wx_py_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                req.scene = SendMessageToWX.Req.WXSceneSession;//分享通道
                req.userOpenId = UserUtils.getInstance().getUserId();//分享人的ID
                wxAPI.sendReq(req);
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
            }
        });
        //微信朋友圈
        wx_pyq_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                req.scene = SendMessageToWX.Req.WXSceneTimeline;//分享通道
                req.userOpenId = UserUtils.getInstance().getUserId();//分享人的ID
                wxAPI.sendReq(req);
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
            }
        });
        //取消
        share_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (popupwindow != null && popupwindow.isShowing()) {
                    popupwindow.dismiss();
                    popupwindow = null;
                }
            }
        });


    }

    public static byte[] bmpToByteArray1(final Bitmap bmp, final boolean needRecycle) {
        int i;
        int j;
        if (bmp.getHeight() > bmp.getWidth()) {
            i = bmp.getWidth();
            j = bmp.getWidth();
        } else {
            i = bmp.getHeight();
            j = bmp.getHeight();
        }

        Bitmap localBitmap = Bitmap.createBitmap(i, j, Bitmap.Config.RGB_565);
        Canvas localCanvas = new Canvas(localBitmap);

        while (true) {
            localCanvas.drawBitmap(bmp, new Rect(0, 0, i, j), new Rect(0, 0, i, j), null);
            if (needRecycle)
                bmp.recycle();
            ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
            localBitmap.compress(Bitmap.CompressFormat.PNG, 10,
                    localByteArrayOutputStream);
            localBitmap.recycle();
            byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
            try {
                localByteArrayOutputStream.close();
                return arrayOfByte;
            } catch (Exception e) {
                //F.out(e);
            }
            i = bmp.getHeight();
            j = bmp.getHeight();
        }
    }

    public static byte[] bmpToByteArray(final Bitmap bmp, final boolean needRecycle) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, output);
        if (needRecycle) {
            bmp.recycle();
        }
        byte[] result = output.toByteArray();
        try {
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String buildTransaction(final String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis())
                : type + System.currentTimeMillis();
    }


    //其他登录-接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(LoginDataEvent event) {

//        ImageLoader.userIcon(getActivity(), catAvatar, event.getUserInfoBean().getImg_url());
//        if (event.getUserInfoBean().getUser_name().equals("")) {
//            signRegisterText.setText("用户名为空");
//        } else {
//            signRegisterText.setText(event.getUserInfoBean().getUser_name());
//        }
//        daifukuanText.setText(event.getUserInfoBean().getObligationcount());
//        daishouhuoText.setText(event.getUserInfoBean().getReceivingcount());
//        daipingjiaText.setText(event.getUserInfoBean().getCommentcount());
//        tuihuanhuoText.setText(event.getUserInfoBean().getReplacementcount());


    }

    /**
     * @Description:下载时间成功
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {

    }

    /**
     * @Description:下载时间失败
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    /**
     * @Description:获取订单数量及用户信息成功
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getPersonalInformationSuccess(int code, PersonalInformationBean data) {
        catAvatar.setScaleType(ImageView.ScaleType.FIT_XY);
        ImageLoader.userIcon(getActivity(), catAvatar, data.getUser().getImg_url());
        Log.e("获取订单数量及用户信息成功", "==code=123=" + code);
        if (data.getUser().getUser_name().equals("")) {
            signRegisterText.setText("用户名为空");

        } else {
            signRegisterText.setText(data.getUser().getUser_name());
        }

        if (data.getUser().getIs_member() == 1) {//会员
            myMemberDate.setText(data.getUser().getMember_end_time());
            myMemberAdd.setVisibility(View.GONE);
        } else if (data.getUser().getIs_member() == 1) {//不是会员
            myMemberDate.setText("加入会员 领取会员红包");
            myMemberAdd.setVisibility(View.VISIBLE);
        }


        //待付款
        if (Integer.parseInt(data.getOrder_count().getObligationcount()) > 0) {
            daifukuanText.setVisibility(View.VISIBLE);
            daifukuanText.setText(data.getOrder_count().getObligationcount());
        } else {
            daifukuanText.setVisibility(View.GONE);
        }
//        //待发货
//        if (Integer.parseInt(data.getOrder_count().getObligationcount()) > 0) {
//            daifahuoText.setVisibility(View.VISIBLE);
//            daifahuoText.setText(data.getOrder_count().getPendingcount());
//        } else {
//            daifahuoText.setVisibility(View.GONE);
//        }
        //待收货
        if (Integer.parseInt(data.getOrder_count().getReceivingcount()) > 0) {
            daishouhuoText.setVisibility(View.VISIBLE);
            daishouhuoText.setText(data.getOrder_count().getReceivingcount());//待收货
        } else {
            daishouhuoText.setVisibility(View.GONE);
        }
        //待评价
        if (Integer.parseInt(data.getOrder_count().getCommentcount()) > 0) {
            daipingjiaText.setVisibility(View.VISIBLE);
            daipingjiaText.setText(data.getOrder_count().getCommentcount());//待评价
        } else {
            daipingjiaText.setVisibility(View.GONE);
        }
        //退换货
        if (Integer.parseInt(data.getOrder_count().getReplacementcount()) > 0) {
            tuihuanhuoText.setVisibility(View.VISIBLE);
            tuihuanhuoText.setText(data.getOrder_count().getReplacementcount());//退换货
        } else {
            tuihuanhuoText.setVisibility(View.GONE);
        }

        myCollectCount.setText(data.getCollect_count());//收藏数量
        myPointsCount.setText(data.getPoints());//积分数量
        myBrowseCount.setText(data.getBrowse_count());//浏览数量
        myDiscountCount.setText(data.getDiscount_count());//优惠券数量

    }

    /**
     * @Description:获取订单数量及用户信息失败
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getPersonalInformationFail(int code, String msg) {
        Log.e("获取订单数量及用户信息失败", "==code==" + code);
        if (code == 4001) {//未登录
            signRegisterText.setText("登录/注册");
            daifukuanText.setText("0");
            daifahuoText.setText("0");
            daishouhuoText.setText("0");
            daipingjiaText.setText("0");
            tuihuanhuoText.setText("0");

            daifukuanText.setVisibility(View.GONE);
            daifahuoText.setVisibility(View.GONE);
            daishouhuoText.setVisibility(View.GONE);
            daipingjiaText.setVisibility(View.GONE);
            tuihuanhuoText.setVisibility(View.GONE);


            myCollectCount.setText("0");//收藏数量
            myPointsCount.setText("0");//积分数量
            myBrowseCount.setText("0");//浏览数量
            myDiscountCount.setText("0");//优惠券数量


            catAvatar.setImageResource(R.mipmap.my_me_hear);
//            catAvatar.setBackground(getResources().getDrawable(R.mipmap.ic_defult_avater));
//            catAvatar.setBackgroundResource(R.mipmap.ic_defult_avater);
        }


    }

    /**
     * @Description:一键登录成功
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getMobileLoginSuccess(int code, UserInfoBean data) {
        UserUtils.getInstance().login(data);
        // 用户登录埋点
        MANService manService = MANServiceProvider.getService();
        manService.getMANAnalytics().updateUserAccount("usernick", data.getUser_id());
//        new LoginDataEvent(data).post();
//        new MainHomeActivityEvent("2").post();
        presenter.getPersonalInformation();//下载
        mAlicomAuthHelper.quitLoginPage();
//        finish();


    }

    /**
     * @Description:一键登录失败
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getMobileLoginFail(int code, String msg) {

    }


    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(PostWechatEvent event) {
        Log.e("MyFragment", "==登录回调==");

        presenter.getWechatLogin(event.getOpenId(), event.getNickName(), event.getHeadUrl());
    }

    /**
     * @Description:微信登录成功
     * @Time:2020/5/12 13:35
     * @Author:pk
     */
    @Override
    public void getCheckCodeSuccess(int code, UserInfoBean data) {
        UserUtils.getInstance().login(data);
        // 用户登录埋点
        MANService manService = MANServiceProvider.getService();
        manService.getMANAnalytics().updateUserAccount("usernick", data.getUser_id());
        Log.e("微信登录成功", "==手机号===" + data.getMobile());

        if (!data.getMobile().equals("") && data.getMobile() != null) {//绑定手机号
            presenter.getPersonalInformation();//下载

        } else {//未绑定手机号
            ModifyPhoneActivity.startSelf(getActivity(), "2");
        }

        CacheActivity.finishActivity();
        mAlicomAuthHelper.quitLoginPage();


    }

    /**
     * Description:微信登录失败
     * Time:2020/5/12 13:35
     * Author:pk
     */
    @Override
    public void getCheckCodeFail(int code, String msg) {

    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.getPersonalInformation();//下载数据
    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }

    //接收消息
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(MyPersonalJudgeEvent event) {
        Log.e("MyFragment", "=首页传递消息==");
        int getJupdg = event.getJupdg();
//        if (getJupdg == 1) {
//            presenter.getAppUpdate();//下载时间
        presenter.getPersonalInformation();//下载时间
//        }
    }


    /**
     * 一键登录
     */
    private void inits() {
        /*
         *   1.init get token callback Listener
         */
        mTokenListener = new TokenResultListener() {
            @Override
            public void onTokenSuccess(final String ret) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.e("xxxxxx", "onTokenSuccess:" + ret);

                        /*
                         *   setText just show the result for get token。
                         *   use ret to verfiy number。
                         */
//                        mAlicomAuthHelper.hideLoginLoading();
                        dismissLoadingDialog();
                        TokenRet tokenRet = null;
                        try {
                            tokenRet = JSON.parseObject(ret, TokenRet.class);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        configLoginTokenPortDialog();


                        if (tokenRet != null && ("600024").equals(tokenRet.getCode())) {
                            Log.e("获取到的Token值", "===终端自检成功:\n==Token值===" + ret);
                        }

                        if (tokenRet != null && ("600001").equals(tokenRet.getCode())) {
                            Log.e("获取到的Token值", "===唤起授权页成功:\n==Token值===" + ret);
                        }

                        if (tokenRet != null && ("600000").equals(tokenRet.getCode())) {
                            String token = tokenRet.getToken();

                            Log.e("获取到的Token值", "===获取token成功:\n==Token值=11==" + ret);
                            presenter.getMobileLogin(token);

                            //将Token值

                        }
                    }
                });
            }

            @Override
            public void onTokenFailed(final String ret) {
                Log.e("xxxxxx", "onTokenFailed:" + ret);
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        /*
                         *  setText just show the result for get token
                         *  do something when getToken failed, such as use sms verify code.
                         */
//                        hideLoadingDialog();
                        dismissLoadingDialog();
//                        Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
                        Log.e("获取到的Token值", "===获取token失败:\n==Token值=22==" + ret);
                        mAlicomAuthHelper.quitLoginPage();
                        LoginActivity.startSelf(getActivity());
                    }
                });
            }
        };
        /*
         *   2.init AlicomAuthHelper with tokenListener
         */
        mAlicomAuthHelper = PhoneNumberAuthHelper.getInstance(getActivity(), mTokenListener);
        mAlicomAuthHelper.setAuthListener(mTokenListener);
        /*
         *   3.set debugMode when app is in debug mode, sdk will print log in debug mode
         */
        mAlicomAuthHelper.setLoggerEnable(true);//设置SDK是否开启日
        mAlicomAuthHelper.setAuthSDKInfo(Constant.LONIG_PHONE_NUMBER_KEY);//设置秘钥


    }


    private void configLoginTokenPortDialog() {
//        initDynamicView();
        mAlicomAuthHelper.removeAuthRegisterXmlConfig();
        mAlicomAuthHelper.removeAuthRegisterViewConfig();
        int authPageOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
        if (Build.VERSION.SDK_INT == 26) {
            authPageOrientation = ActivityInfo.SCREEN_ORIENTATION_BEHIND;
        }
        updateScreenSize(authPageOrientation);
        int dialogWidth = (int) (mScreenWidthDp * 0.8f);
        int dialogHeight = (int) (mScreenHeightDp * 0.65f);
        mAlicomAuthHelper.addAuthRegisterXmlConfig(new AuthRegisterXmlConfig.Builder()
                .setLayout(R.layout.login_item_layou_1, new AbstractPnsViewDelegate() {
                    @Override
                    public void onViewCreated(View view) {
                        findViewById(R.id.login_btn1).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {//其他号码登录
                                mAlicomAuthHelper.hideLoginLoading();
                                LoginActivity.startSelf(getActivity());
                                mAlicomAuthHelper.quitLoginPage();
                            }
                        });

                        findViewById(R.id.login_wechat).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                login();//微信登陆

                            }
                        });
                    }
                })
                .build());

//        mAlicomAuthHelper.addAuthRegisterXmlConfig(new AuthRegisterXmlConfig.Builder()
//                .setLayout(R.layout.login_item_layou_2, new AbstractPnsViewDelegate() {
//                    @Override
//                    public void onViewCreated(View view) {
//                        findViewById(R.id.login_wechat).setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//                                mAlicomAuthHelper.hideLoginLoading();
//                                login();//微信登陆
//                                mAlicomAuthHelper.quitLoginPage();
//                            }
//                        });
////                        findViewById(R.id.login_qq).setOnClickListener(new View.OnClickListener() {
////                            @Override
////                            public void onClick(View v) {
////
////                            }
////                        });
////                        findViewById(R.id.login_weibo).setOnClickListener(new View.OnClickListener() {
////                            @Override
////                            public void onClick(View v) {
////
////                            }
////                        });
//                    }
//                })
//                .build());


        int logBtnOffset = dialogHeight / 2;


        mAlicomAuthHelper.setAuthUIConfig(new AuthUIConfig.Builder()
                .setAppPrivacyOne("《隐私政策》", "http://shop.jealook.com/v1/html/article-info?id=117")
                .setAppPrivacyTwo("《用户协议》", "http://shop.jealook.com/v1/html/article-info?id=119")
                .setAppPrivacyColor(Color.BLACK, Color.parseColor("#A08FBB"))
                .setPrivacyState(true)
                .setCheckboxHidden(true)
                .setNavHidden(false)
                .setNavColor(getResources().getColor(R.color.them))
                .setWebNavColor(Color.parseColor("#A08FBB"))//设置协议顶部导航栏背景色
                .setStatusBarColor(Color.parseColor("#A08FBB"))//设置状态栏颜色
                .setLightColor(false)
                .setAuthPageActIn("in_activity", "out_activity")
                .setAuthPageActOut("in_activity", "out_activity")
                .setVendorPrivacyPrefix("《")
                .setVendorPrivacySuffix("》")

                .setLogBtnWidth(dialogWidth - 30)
                .setLogBtnMarginLeftAndRight(15)
                .setNavReturnHidden(true)//隐藏导航栏按钮
                .setLogBtnOffsetY(logBtnOffset + 60)
                .setNumFieldOffsetY(logBtnOffset)
                .setPageBackgroundPath("login_bg")
                .setLogBtnTextSize(18)
                .setDialogBottom(false)
                .setScreenOrientation(authPageOrientation)
                .setNavText("")
                .setSloganText("")
                .setSloganTextColor(Color.parseColor("#00000000"))
                .setNumberColor(Color.parseColor("#A08FBB"))
                .setNumberSize(27)
                .setSwitchAccHidden(true)
                .setLogBtnText("本机号码一键登录")
                .setLogBtnBackgroundPath("classify_list_item")
                .setLogBtnHeight(40)
                .setPrivacyOffsetY_B(110)
                .create());

    }


    private void updateScreenSize(int authPageScreenOrientation) {
        int screenHeightDp = AppUtils.px2dp(getActivity().getApplicationContext(), AppUtils.getPhoneHeightPixels(getActivity()));
        int screenWidthDp = AppUtils.px2dp(getActivity().getApplicationContext(), AppUtils.getPhoneWidthPixels(getActivity()));
        int rotation = getActivity().getWindowManager().getDefaultDisplay().getRotation();
        if (authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_BEHIND) {
            authPageScreenOrientation = getActivity().getRequestedOrientation();
        }
        if (authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                || authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                || authPageScreenOrientation == ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT) {
            rotation = Surface.ROTATION_180;
        }
        switch (rotation) {
            case Surface.ROTATION_180:
                mScreenWidthDp = screenWidthDp;
                mScreenHeightDp = screenHeightDp;
                break;
        }
    }


    /**
     * 微信登录(三个步骤)
     * 1.微信授权登录
     * 2.根据授权登录code 获取该用户token
     * 3.根据token获取用户资料
     */
    public void login() {
//        SendAuth.Req req = new SendAuth.Req();
//        req.scope = "snsapi_userinfo";
//        req.state = String.valueOf(System.currentTimeMillis());
//        wxAPI.sendReq(req);

        if (!wxAPI.isWXAppInstalled()) {
            Toast.makeText(getActivity(), "您的设备未安装微信客户端", Toast.LENGTH_SHORT).show();
        } else {
            final SendAuth.Req req = new SendAuth.Req();
            req.scope = "snsapi_userinfo";
            req.state = String.valueOf(System.currentTimeMillis());
            wxAPI.sendReq(req);
        }

    }

    /**
     * 微信分享(三个步骤)
     * 1.微信授权登录
     * 2.根据授权登录code 获取该用户token
     * 3.根据token获取用户资料
     */
    public void share() {
//        SendAuth.Req req = new SendAuth.Req();
//        req.scope = "snsapi_userinfo";
//        req.state = String.valueOf(System.currentTimeMillis());
//        wxAPI.sendReq(req);

        if (!wxAPI.isWXAppInstalled()) {
            Toast.makeText(getActivity(), "您的设备未安装微信客户端", Toast.LENGTH_SHORT).show();
        } else {
            final SendAuth.Req req = new SendAuth.Req();
            req.scope = "snsapi_userinfo";
            req.state = String.valueOf(System.currentTimeMillis());
            wxAPI.sendReq(req);
            mAlicomAuthHelper.quitLoginPage();

        }

    }


}
