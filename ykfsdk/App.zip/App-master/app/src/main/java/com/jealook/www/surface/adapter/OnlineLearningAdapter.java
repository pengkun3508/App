package com.jealook.www.surface.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;

/**
 * 描述：
 *
 * @author yanbo
 * @date 2019-09-10
 */
public class OnlineLearningAdapter  extends BaseStateAdapter<String, OnlineLearningAdapter.OnlineLearningHolder> {


    @Override
    protected OnlineLearningHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new OnlineLearningHolder(inflate(parent, R.layout.rv_item_online_learning));
    }

    class OnlineLearningHolder extends BaseHolder<String> {

        ImageView ivVideoImg;
        TextView tvVideoTitle;
        TextView tvVideoTime;


        OnlineLearningHolder(View itemView) {
            super(itemView);

            ivVideoImg=getView(R.id.iv_video_img);
            tvVideoTitle=getView(R.id.tv_video_title);
            tvVideoTime=getView(R.id.tv_video_time);
        }

        @Override
        protected void bindData(String data) {
//            mClassTitls.setText(data.getName());
//            ImageLoader.image(mIcons.getContext(),mIcons,data.getImg());
//            mAddPeopleNumbers.setText(MessageFormat.format("{0}人已加入", data.getCount()));
        }


    }

}
