package com.jealook.www.surface.mvp.presenter;

import android.util.Log;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.http.RequestBackListener;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.surface.bean.TypeGoodsBean;
import com.jealook.www.surface.mvp.model.MainRequest;
import com.jealook.www.surface.mvp.view.RecommendView;

/**
 * @Description:
 * @Time:2020/4/14$
 * @Author:pk$
 */
public class RecommendPresenter extends MvpPresenter<RecommendView> {

    public void getTypeGoods(int page, int limit, String iD) {
        addToRxLife(MainRequest.getTypeGoods(page, limit, iD, new RequestBackListener<TypeGoodsBean>() {
            @Override
            public void onStart() {
//                showLoading();
            }

            @Override
            public void onSuccess(int code, TypeGoodsBean data) {
                if (isAttachView())
                    getBaseView().getTypeGoodsSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getTypeGoodsFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onFinish() {
//                dismissLoading();
            }
        }));

    }
}
