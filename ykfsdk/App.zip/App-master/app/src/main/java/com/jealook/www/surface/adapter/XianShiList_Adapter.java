package com.jealook.www.surface.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.http.model.HomeDataBean;


/**
 * @Description:
 * @Time:2020/3/30$
 * @Author:pk$
 */
public class XianShiList_Adapter extends BaseStateAdapter<HomeDataBean.DiscountBean, XianShiList_Adapter.XianShiListHolder> {


    private static Context context;
    private static long mHour;
    private static long mMin;
    private static long mSecond;
    private static String mHours;

    String mMins;
    String mSeconds;


    public XianShiList_Adapter(Context contexts) {
        context = contexts;
    }

    public static void setDatas(String time) {
        mHours = time;

    }

    @Override
    protected XianShiListHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new XianShiListHolder(inflate(parent, R.layout.xianshilist_item));
    }

    class XianShiListHolder extends BaseHolder<HomeDataBean.DiscountBean> {

        TextView xianshi_name;
        ImageView xianshi_img;
        TextView xianshi_jiage;
        TextView xianshi_yuanjia;
        TextView xianshi_hour;
        TextView xianshi_min;
        TextView xianshi_second;

        XianShiListHolder(View itemView) {
            super(itemView);
            xianshi_name = getView(R.id.xianshi_name);
            xianshi_img = getView(R.id.xianshi_img);
            xianshi_jiage = getView(R.id.xianshi_jiage);
            xianshi_yuanjia = getView(R.id.xianshi_yuanjia);
            xianshi_hour = getView(R.id.xianshi_hour);
            xianshi_min = getView(R.id.xianshi_min);
            xianshi_second = getView(R.id.xianshi_second);
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void bindData(HomeDataBean.DiscountBean data) {

            xianshi_name.setText(data.getGoods_name());
            Glide.with(context).load(data.getGoods_thumb())
                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(20)))
                    .into(xianshi_img);
            xianshi_jiage.setText("￥" + data.getPreferential_price());
            xianshi_yuanjia.setText(" ￥" + data.getProduct_price());
            xianshi_yuanjia.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);

            xianshi_hour.setText(mHours + "");


        }


    }
}
