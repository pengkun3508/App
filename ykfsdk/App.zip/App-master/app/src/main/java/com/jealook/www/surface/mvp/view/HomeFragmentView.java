package com.jealook.www.surface.mvp.view;


import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.http.model.VersionBean;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/3/7
 */
public interface HomeFragmentView extends MvpView {

    void getAppUpdateSuccess(int code, SignBean version);

    void getAppUpdateFail(int code, String msg);

    void getHomeDataSuccess(int code, HomeDataBean data);

    void getHomeDataFail(int code, String msg);
}
