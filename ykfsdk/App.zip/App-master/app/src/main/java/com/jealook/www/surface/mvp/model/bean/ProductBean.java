package com.jealook.www.surface.mvp.model.bean;

public class ProductBean {

    /**
     * goods_attr : 132|133|134
     * product_id : 275
     * product_sn : AS4977324481630
     * product_number : 0
     * product_price : 78.00
     * preferential_price : 68.00
     * color_id : 133
     * search_attr : 133|134
     * attr_name : 0度 Antiquebeige 20枚
     */

    private String goods_attr;
    private String product_id;
    private String product_sn;
    private String product_number;
    private String product_price;
    private String preferential_price;
    private String color_id;
    private String search_attr;
    private String attr_name;

    public String getAttr_name() {
        return attr_name;
    }

    public void setAttr_name(String attr_name) {
        this.attr_name = attr_name;
    }


    public String getGoods_attr() {
        return goods_attr;
    }

    public void setGoods_attr(String goods_attr) {
        this.goods_attr = goods_attr;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProduct_sn() {
        return product_sn;
    }

    public void setProduct_sn(String product_sn) {
        this.product_sn = product_sn;
    }

    public String getProduct_number() {
        return product_number;
    }

    public void setProduct_number(String product_number) {
        this.product_number = product_number;
    }

    public String getProduct_price() {
        return product_price;
    }

    public void setProduct_price(String product_price) {
        this.product_price = product_price;
    }

    public String getPreferential_price() {
        return preferential_price;
    }

    public void setPreferential_price(String preferential_price) {
        this.preferential_price = preferential_price;
    }

    public String getColor_id() {
        return color_id;
    }

    public void setColor_id(String color_id) {
        this.color_id = color_id;
    }

    public String getSearch_attr() {
        return search_attr;
    }

    public void setSearch_attr(String search_attr) {
        this.search_attr = search_attr;
    }
}
