package com.jealook.www.surface.fragment;

import android.graphics.Rect;
import android.view.View;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.DisplayInfoUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.http.model.SignBean;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.jealook.www.R;
import com.jealook.www.base.BaseFragment;
import com.jealook.www.common.Config;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.activity.MoveAboutActivity;
import com.jealook.www.surface.adapter.HomeTabAdapter;
import com.jealook.www.surface.dialog.ScreenDialog;
import com.jealook.www.surface.mvp.presenter.HomeFragmentPresenter;
import com.jealook.www.surface.mvp.view.HomeFragmentView;
import com.jealook.www.utils.SmartRefreshHelper;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @Description:分类--全部
 * @Time:2020/4/1 12:13
 * @Author:pk
 */

public class HomeTab2Fragment extends BaseFragment<HomeFragmentPresenter> implements HomeFragmentView {

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;
    @BindView(R.id.classify_zonghe)
    LinearLayout classifyZonghe;
    @BindView(R.id.classify_xiaoliang)
    LinearLayout classifyXiaoliang;
    @BindView(R.id.classify_xinpin)
    LinearLayout classifyXinpin;
    @BindView(R.id.classify_jiage)
    LinearLayout classifyJiage;
    @BindView(R.id.classify_shaixuan)
    LinearLayout classifyShaixuan;
    private HomeTabAdapter homeTabAdapter;
    private SmartRefreshHelper<String> mSmartRefreshHelper;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home_tab2;
    }

    @Override
    protected HomeFragmentPresenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        homeTabAdapter = new HomeTabAdapter();
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setHasFixedSize(true);
        final int divider = (int) DisplayInfoUtils.getInstance().dp2px(5);
        RecyclerView.ItemDecoration gridItemDecoration = new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                GridLayoutManager layoutManager = (GridLayoutManager) parent.getLayoutManager();
                final GridLayoutManager.LayoutParams lp = (GridLayoutManager.LayoutParams) view.getLayoutParams();
                final int spanCount = layoutManager.getSpanCount();
                int layoutPosition = ((RecyclerView.LayoutParams) view.getLayoutParams()).getViewLayoutPosition();
                if (lp.getSpanSize() != spanCount) {
                    //左边间距
                    if (layoutPosition % 2 == 1) {
                        outRect.left = divider / 2;
                    } else {
                        outRect.right = divider / 2;
                    }
                }
                outRect.top = divider;
            }
        };
        recyclerView.addItemDecoration(gridItemDecoration);
        recyclerView.setAdapter(homeTabAdapter);
//        mSmartRefreshHelper = SmartRefreshHelper.with(smartRefreshLayout, homeTabAdapter)
//                .setPerPageCount(Config.ONE_PAGE_ITEM_MAX_COUNT_DEFAULT)
//                .init(new SmartRefreshHelper.RefreshCallback() {
//                    @Override
//                    public void doRequestData(int page) {
//                        mSmartRefreshHelper.onSuccess(2000, getData());
//
//                    }
//                });
        homeTabAdapter.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
                MoveAboutActivity.startSelf(getActivity());//详情页面
            }
        });

    }

    @Override
    protected void loadData() {
        mSmartRefreshHelper.requestFirstPage(false);

    }

    public List<String> getData() {
        List<String> strings = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            strings.add("1");
        }
        return strings;
    }

    @OnClick({R.id.classify_zonghe, R.id.classify_xiaoliang, R.id.classify_xinpin, R.id.classify_jiage, R.id.classify_shaixuan})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.classify_zonghe://综合
                break;
            case R.id.classify_xiaoliang://销量
                break;
            case R.id.classify_xinpin://新品
                break;
            case R.id.classify_jiage://价格
                break;
            case R.id.classify_shaixuan://筛选
//                ScreenDialog.with(getActivity()).show();
                break;
        }
    }

    @Override
    public void getAppUpdateSuccess(int code, SignBean version) {

    }

    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    @Override
    public void getHomeDataSuccess(int code, HomeDataBean data) {

    }

    @Override
    public void getHomeDataFail(int code, String msg) {

    }
}
