package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.surface.bean.ProductDetailsBean;

public interface ProductDetailsView extends MvpView {
    void getProductDetailsSuccess(int code, ProductDetailsBean data);

    void getProductDetailsFail(int code, String msg);
}
