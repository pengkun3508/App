package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.AboutView;
import com.jealook.www.surface.mvp.view.AddressView;

public class AboutPresenter extends MvpPresenter<AboutView> {
}