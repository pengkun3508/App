package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.BindPhoneView;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019-12-24
 */
public class BindPhonePresenter extends MvpPresenter<BindPhoneView> {
}
