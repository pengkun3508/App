package com.jealook.www.surface.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;

import butterknife.BindView;

public class OnlineCustomerServiceAdapter extends BaseStateAdapter<String, OnlineCustomerServiceAdapter.OnlineCustomerServiceHolder> {




    @Override
    protected OnlineCustomerServiceHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new OnlineCustomerServiceHolder(inflate(parent, R.layout.rv_item_online_customer_service));
    }

    class OnlineCustomerServiceHolder extends BaseHolder<String> {
        @BindView(R.id.tv_title_l)
        TextView tvTitleL;
        @BindView(R.id.tv_title_r)
        TextView tvTitleR;

        OnlineCustomerServiceHolder(View itemView) {
            super(itemView);
            tvTitleL=getView(R.id.tv_title_l);
            tvTitleR=getView(R.id.tv_title_r);
        }

        @Override
        protected void bindData(String data) {
            if (getAdapterPosition()%2==0) {
                tvTitleL.setVisibility(View.VISIBLE);
                tvTitleR.setVisibility(View.GONE);
            }else {
                tvTitleL.setVisibility(View.GONE);
                tvTitleR.setVisibility(View.VISIBLE);
            }


        }


    }
}