package com.jealook.www.surface.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.utils.DeviceIdUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.App;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.http.model.AllOrderListBean;
import com.jealook.www.http.model.OrderDetailsBean;
import com.jealook.www.http.model.SiginOrderBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.adapter.OrderDetailsAdapter;
import com.jealook.www.surface.mvp.presenter.OrderDetailsPresenter;
import com.jealook.www.surface.mvp.view.OrderDetailsView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @Description:订单详情
 * @Time:2020/4/14 9:43
 * @Author:pk
 */
public class OrderDetailsActivity extends BaseActivity<OrderDetailsPresenter> implements OrderDetailsView {


    private static String getOrder_id;
    String getOrder_amount;
    int getStatus;
    String sdktoken;
    private static final int BAIDU_READ_PHONE_STATE = 100;
    @BindView(R.id.order_details_address_name)
    TextView orderDetailsAddressName;
    @BindView(R.id.order_details_phone)
    TextView orderDetailsPhone;
    @BindView(R.id.order_details_address_addres)
    TextView orderDetailsAddressAddres;
    @BindView(R.id.order_details_address_idcar)
    TextView orderDetailsAddressIdcar;
    @BindView(R.id.order_details_shiming_name)
    TextView orderDetailsShimingName;
    @BindView(R.id.order_details_id_number)
    TextView orderDetailsIdNumber;
    @BindView(R.id.order_details_recycler)
    RecyclerView orderDetailsRecycler;
    @BindView(R.id.order_details_express)
    TextView orderDetailsExpress;
    @BindView(R.id.order_details_shop_price)
    TextView orderDetailsShopPrice;
    @BindView(R.id.order_details_express_price)
    TextView orderDetailsExpressPrice;
    @BindView(R.id.order_details_counpon_price)
    TextView orderDetailsCounponPrice;
    @BindView(R.id.order_details_toal_price)
    TextView orderDetailsToalPrice;
    @BindView(R.id.order_details_oeder_sn)
    TextView orderDetailsOederSn;
    @BindView(R.id.order_kefu_btn)
    TextView orderKefuBtn;
    @BindView(R.id.order_quxiao_btn)
    TextView orderQuxiaoBtn;
    @BindView(R.id.order_pay_btn)
    TextView orderPayBtn;
    @BindView(R.id.order_shouhuo_btn)
    TextView orderShouhuoBtn;
    @BindView(R.id.order_tuihuan_btn)
    TextView orderTuihuanBtn;
    @BindView(R.id.orderdetails_postscript)
    TextView orderdetailsPostscript;

    OrderDetailsAdapter adapter;
    @BindView(R.id.order_see_wuliu)
    TextView orderSeeWuliu;//查看物流


    @Override
    protected int getLayoutId() {
        return R.layout.activity_order_details_1;
    }


    public static void startSelf(Context context, String getOrder_ids) {
        Intent intent = new Intent(context, OrderDetailsActivity.class);
        context.startActivity(intent);
        getOrder_id = getOrder_ids;
    }

    @Override
    protected OrderDetailsPresenter initPresenter() {
        return new OrderDetailsPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
//        viewLin.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        orderDetailsRecycler.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        });
        adapter = new OrderDetailsAdapter(this);
        orderDetailsRecycler.setAdapter(adapter);
    }

    @Override
    protected void loadData() {
//        presenter.getAppUpdate();//下载时间
        presenter.getOederDetailsData(getOrder_id);//下载数据

    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.getOederDetailsData(getOrder_id);//下载数据
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {
        presenter.getOederDetailsData(getOrder_id);//下载数据
    }

    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    /**
     * @Description:下载详情成功
     * @Time:2020/5/8 14:22
     * @Author:pk
     */
    @Override
    public void getOederDetailsSuccess(int code, OrderDetailsBean data) {
        adapter.setData(data.getShop_list());

        getOrder_id = data.getOrder_id();
        getStatus = data.getStatus();
        adapter.setOrder_Id(getOrder_id, getStatus);
        getOrder_amount = data.getOrder_amount();
        adapter.notifyDataSetChanged();
        OrderDetailsBean.AddressBean getAddress = data.getAddress();//地址数据集
        OrderDetailsBean.RealBean getReal = data.getReal();//实名认证集

        orderDetailsAddressName.setText(getAddress.getAddress_name());
        orderDetailsPhone.setText(getAddress.getMobile());
        orderDetailsAddressAddres.setText(getAddress.getAddress_refer() + getAddress.getAddress());
        orderDetailsAddressIdcar.setText(getAddress.getAddress_id());

        orderDetailsShimingName.setText(getReal.getName());
        orderDetailsIdNumber.setText(getReal.getId_card());
        orderdetailsPostscript.setText(data.getPostscript());
        orderDetailsShopPrice.setText("￥" + data.getGoods_amount());
        orderDetailsExpressPrice.setText("￥" + data.getShipping_fee());
        orderDetailsCounponPrice.setText("￥" + data.getBonus());
        orderDetailsToalPrice.setText("￥" + data.getOrder_amount());
        orderDetailsOederSn.setText("订单编号：" + data.getOrder_sn());

        if (data.getStatus() == 1) {//待付款
            orderQuxiaoBtn.setVisibility(View.VISIBLE);//取消订单
            orderPayBtn.setVisibility(View.VISIBLE);//支付订单
            orderSeeWuliu.setVisibility(View.GONE);//查看物流
            orderShouhuoBtn.setVisibility(View.GONE);//确认收货
            orderTuihuanBtn.setVisibility(View.GONE);//退换货
        } else if (data.getStatus() == 2) {//待收货
            orderQuxiaoBtn.setVisibility(View.GONE);//取消订单
            orderPayBtn.setVisibility(View.GONE);//支付订单
            orderSeeWuliu.setVisibility(View.VISIBLE);//查看物流
            orderShouhuoBtn.setVisibility(View.VISIBLE);//确认收货
            orderTuihuanBtn.setVisibility(View.GONE);//退换货

        } else if (data.getStatus() == 3) {//待评价
            orderQuxiaoBtn.setVisibility(View.GONE);//取消订单
            orderPayBtn.setVisibility(View.GONE);//支付订单
            orderSeeWuliu.setVisibility(View.GONE);//查看物流
            orderShouhuoBtn.setVisibility(View.GONE);//确认收货
            orderTuihuanBtn.setVisibility(View.GONE);//退换货

        } else if (data.getStatus() == 4) {//退换货
            orderQuxiaoBtn.setVisibility(View.GONE);//取消订单
            orderPayBtn.setVisibility(View.GONE);//支付订单
            orderSeeWuliu.setVisibility(View.GONE);//查看物流
            orderShouhuoBtn.setVisibility(View.GONE);//确认收货
            orderTuihuanBtn.setVisibility(View.VISIBLE);//退换货

        } else if (data.getStatus() == 5) {
            orderQuxiaoBtn.setVisibility(View.GONE);//取消订单
            orderPayBtn.setVisibility(View.GONE);//支付订单
            orderSeeWuliu.setVisibility(View.GONE);//查看物流
            orderShouhuoBtn.setVisibility(View.GONE);//确认收货
            orderTuihuanBtn.setVisibility(View.GONE);//退换货

        }


    }

    /**
     * @Description:下载详情失败
     * @Time:2020/5/8 14:22
     * @Author:pk
     */
    @Override
    public void getOederDetailsFail(int code, String msg) {

    }

    /**
     * @Description:取消订单成功
     * @Time:2020/5/8 14:22
     * @Author:pk
     */
    @Override
    public void getCelearOrderSuccess(int code, AllOrderListBean data) {
        finish();

    }

    /**
     * @Description:取消订单失败
     * @Time:2020/5/8 14:22
     * @Author:pk
     */
    @Override
    public void getCelearOrderFail(int code, String msg) {

    }

    /**
     * @Description:签收成功
     * @Time:2020/5/8 14:22
     * @Author:pk
     */
    @Override
    public void getSignInOrderSuccess(int code, SiginOrderBean data) {
        orderQuxiaoBtn.setVisibility(View.GONE);//取消订单
        orderPayBtn.setVisibility(View.GONE);//支付订单
        orderShouhuoBtn.setVisibility(View.GONE);//确认收货
        orderTuihuanBtn.setVisibility(View.GONE);//退换货
    }

    /**
     * @Description:签收失败
     * @Time:2020/5/8 14:22
     * @Author:pk
     */
    @Override
    public void getSignInOrderFail(int code, String msg) {

    }

    @OnClick({R.id.order_kefu_btn, R.id.order_quxiao_btn, R.id.order_pay_btn, R.id.order_see_wuliu, R.id.order_shouhuo_btn, R.id.order_tuihuan_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.order_kefu_btn:
                if (Build.VERSION.SDK_INT >= 23) {
                    showContacts();
                } else {
                    CustomerService();
                }
                break;
            case R.id.order_quxiao_btn://取消订单
                presenter.getCelearOrderData(getOrder_id, getStatus + "");
                break;
            case R.id.order_pay_btn://支付
                String recId = "";
                String goods_id = "";
                String product_id = "";
                String num = "";
                String real_id = "";
                String address_id = "";
                String type = "";
                String confirmMessage = "";
                PayOrderActivity.startSelf(this, recId, goods_id, product_id, num, real_id, address_id, type, confirmMessage, getOrder_id, getOrder_amount, "");

                break;
            case R.id.order_see_wuliu://查看物流
                LogisticsActivity.startSelf(this, getOrder_id);
                break;
            case R.id.order_shouhuo_btn://确认收货
                presenter.getSignInOrderData(getOrder_id);
                break;
            case R.id.order_tuihuan_btn:
                break;
        }
    }

    public void showContacts() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "没有权限,请手动开启定位权限", Toast.LENGTH_SHORT).show();
            // 申请一个（或多个）权限，并提供用于回调返回的获取码（用户定义）
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, BAIDU_READ_PHONE_STATE);
        } else {
            CustomerService();
        }
    }

    @SuppressLint("MissingPermission")
    public void CustomerService() {
        TelephonyManager TelephonyMgr = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
//        sdktoken = TelephonyMgr.getDeviceId();
        sdktoken = App.getDeviceId;
        Log.e("获取Token值", "===sdktoken====" + sdktoken);
        if (TextUtils.isEmpty(sdktoken)) {
            sdktoken = DeviceIdUtils.getId();
        }

//        UdeskSDKManager.getInstance().initApiKey(this, "ali-8fbe83.udesk.cn", "63ce4fc962cfe796cb60ace665215188", "b2c735f0dc0fb7ca");
//        UdeskSDKManager.getInstance().entryChat(getApplicationContext(), makeBuilder().build(), sdktoken);
    }


//    private UdeskConfig.Builder makeBuilder() {
//        UdeskConfig.Builder builder = new UdeskConfig.Builder();
//        builder.setUdeskTitlebarBgResId(R.color.them) //设置标题栏TitleBar的背景色
//                .setUdeskTitlebarMiddleTextResId(R.color.white) //设置标题栏TitleBar，左右两侧文字的颜色
//                .setUdeskTitlebarRightTextResId(R.color.white) //设置标题栏TitleBar，右侧文字的颜色
//                .setUdeskIMLeftTextColorResId(R.color.udesk_color_im_text_left1) //设置IM界面，左侧文字的字体颜色
//                .setUdeskIMRightTextColorResId(R.color.udesk_color_im_text_right1) // 设置IM界面，右侧文字的字体颜色
//                .setUdeskIMAgentNickNameColorResId(R.color.udesk_color_im_left_nickname1) //设置IM界面，左侧客服昵称文字的字体颜色
//                .setUdeskIMCustomerNickNameColorResId(R.color.udesk_color_im_right_nickname1) //设置IM界面，右侧用户昵称文字的字体颜色
//                .setUdeskIMTimeTextColorResId(R.color.udesk_color_im_time_text1) // 设置IM界面，时间文字的字体颜色
//                .setUdeskIMTipTextColorResId(R.color.udesk_color_im_tip_text1) //设置IM界面，提示语文字的字体颜色，比如客服转移
//                .setUdeskbackArrowIconResId(R.mipmap.back_white) // 设置返回箭头图标资源id
//                .setUdeskCommityBgResId(R.color.them) //咨询商品item的背景颜色
//                .setUdeskCommityTitleColorResId(R.color.udesk_color_im_commondity_title1) // 商品介绍Title的字样颜色
//                .setUdeskCommitysubtitleColorResId(R.color.udesk_color_im_commondity_subtitle1)// 商品咨询页面中，商品介绍子Title的字样颜色
//                .setUdeskCommityLinkColorResId(R.color.them) //商品咨询页面中，发送链接的字样颜色
//                .setUdeskProductLeftBgResId(R.drawable.udesk_im_txt_left_default) //商品消息背景
//                .setUdeskProductRightBgResId(R.drawable.udesk_im_item_bg_right) //商品消息背景
//                .setAgentId("", true)//1设置指订客服，每次进入都必须重新指定;2指定是否只通过设定agentId进入会话的分配, 不再要机器人, 设置导航等判断
//                .setUdeskProductMaxLines(2) //商品消息名称最大显示行数
//                .setUserSDkPush(true) // 配置 是否使用推送服务  true 表示使用  false表示不使用
//                .setOnlyUseRobot(false)//配置是否只使用机器人功能 只使用机器人功能,只使用机器人功能;  其它功能不使用。
//                .setUdeskQuenuMode(true ? UdeskConfig.UdeskQueueFlag.CANNEL_MARK : UdeskConfig.UdeskQueueFlag.Mark)  //  配置放弃排队的策略
//                .setUseVoice(true) // 是否使用录音功能  true表示使用 false表示不使用
//                .setUsephoto(true) //是否使用发送图片的功能  true表示使用 false表示不使用
//                .setUsecamera(true) //是否使用拍照的功能  true表示使用 false表示不使用
//                .setUsefile(true) //是否使用上传文件功能  true表示使用 false表示不使用
////                .setUseMap(true) //是否使用发送位置功能  true表示使用 false表示不使用
////                .setUseMapSetting(UdeskConfig.UdeskMapType.GaoDe, LocationActivity.class, new ILocationMessageClickCallBack() {
////                    @Override
////                    public void luanchMap(Context context, double latitude, double longitude, String selctLoactionValue) {
////                        Intent intent = new Intent();
////                        intent.putExtra(UdeskConfig.UdeskMapIntentName.Position, selctLoactionValue);
////                        intent.putExtra(UdeskConfig.UdeskMapIntentName.Latitude, latitude);
////                        intent.putExtra(UdeskConfig.UdeskMapIntentName.Longitude, longitude);
////                        intent.setClass(context, ShowSelectLocationActivity.class);
////                        context.startActivity(intent);
////                    }
////                })
//                .setUseEmotion(true) //是否使用表情 true表示使用 false表示不使用
//                .setUseMore(true) // 是否使用更多控件 展示出更多功能选项 true表示使用 false表示不使用
//                .setUseNavigationSurvy(true) //设置是否使用导航UI中的满意度评价UI rue表示使用 false表示不使用
//                .setUseSmallVideo(true)  //设置是否需要小视频的功能 rue表示使用 false表示不使用
//                .setScaleImg(true) //上传图片是否使用原图 还是缩率图
//                .setScaleMax(1024) // 缩放图 设置最大值，如果超出则压缩，否则不压缩
//                .setOrientation(true ? UdeskConfig.OrientationValue.portrait :
//                        (true ? UdeskConfig.OrientationValue.user : UdeskConfig.OrientationValue.portrait)) //设置默认屏幕显示习惯
//                .setUserForm(true) //在没有请求到管理员在后端对sdk使用配置下，在默认的情况下，是否需要表单留言，true需要， false 不需要
//                .setDefaultUserInfo(getdefaultUserInfo()) // 创建用户基本信息
////                .setDefinedUserTextField(getDefinedUserTextField()) //创建用户自定义的文本信息
////                .setDefinedUserRoplist(getDefinedUserRoplist()) //创建用户自定义的列表信息
////                .setFirstMessage(firstMessage.getText().toString()) //设置带入一条消息  会话分配就发送给客服
////                .setCustomerUrl(customerUrl.getText().toString()) //设置客户的头像地址
////                .setRobot_modelKey(robot_modelKey.getText().toString()) // udesk 机器人常见问题 对应的Id值
////                .setConcatRobotUrlWithCustomerInfo(robpt_customer_info.getText().toString())
////                .setCommodity(false ? createCommodity() : null)//配置发送商品链接的mode
////                .setProduct(false ? createProduct() : null)//配置发送商品链接的mode
////                .setExtreFunctions(getExtraFunctions(), new IFunctionItemClickCallBack() {//自定义发送内容
////                    @Override
////                    public void callBack(Context context, UdeskViewMode udeskViewMode, int id, String name) {
////                        if (id == 22) {
////                            udeskViewMode.sendCommodityMessage(createCommodity());
////                        } else if (id == 23) {
////                            UdeskSDKManager.getInstance().disConnectXmpp();
////                        } else if (id == 24) {
////                            udeskViewMode.sendProductMessage(createProduct());
////                        } else if (id == 25) {
////                            sendCustomerOrder();
////                        } else if (id == 26) {
////                            sendTrace();
////                        }
////                    }
////                })//在more 展开面板中设置额外的功能按钮
//                .setNavigations(true, getNavigations(), new INavigationItemClickCallBack() {
//                    @Override
//                    public void callBack(Context context, UdeskViewMode udeskViewMode, NavigationMode navigationMode, String currentView) {
//                        if (navigationMode.getId() == 1) {
//                            udeskViewMode.sendProductMessage(createProduct());
//                        } else if (navigationMode.getId() == 2) {
//                            udeskViewMode.sendTxtMessage("www.jealook.com");
//                        }
//                    }
//                })//设置是否使用导航UI true表示使用 false表示不使用
////                .setRobotNavigations(true, getRobotNavigations(), new INavigationItemClickCallBack() {
////                    @Override
////                    public void callBack(Context context, UdeskViewMode udeskViewMode, NavigationMode navigationMode, String currentView) {
////                        if (TextUtils.equals(currentView, UdeskConst.CurrentFragment.robot)) {
////                            if (navigationMode.getId() == 1) {
////                                udeskViewMode.sendTxtMessage("robot导航");
////                            } else if (navigationMode.getId() == 2) {
////                                udeskViewMode.getRobotApiData().onShowProductClick(createReplyProduct());
////                            }
////                        }
////                    }
////                })//设置是否使用机器人导航UI true表示使用 false表示不使用
//
////                .setTxtMessageClick(new ITxtMessageWebonCliclk() {
////                    @Override
////                    public void txtMsgOnclick(String url) {
////                        Toast.makeText(getApplicationContext(), "对文本消息中的链接消息处理设置回调", Toast.LENGTH_SHORT).show();
////                    }
////                })   //如果需要对文本消息中的链接消息处理可以设置该回调，点击事件的拦截回调。 包含表情的不会拦截回调。
////                .setFormCallBack(new IUdeskFormCallBack() {
////                    @Override
////                    public void toLuachForm(Context context) {
////                        Toast.makeText(getApplicationContext(), "不用udesk系统提供的留言功能", Toast.LENGTH_SHORT).show();
////                    }
////                })//离线留言表单的回调接口：  如果不用udesk系统提供的留言功能，可以设置该接口  回调使用自己的处理流程
//                .setStructMessageCallBack(new IUdeskStructMessageCallBack() {
//
//                    @Override
//                    public void structMsgCallBack(Context context, String josnValue) {
//                        Toast.makeText(getApplicationContext(), "结构化消息控件点击事件回调", Toast.LENGTH_SHORT).show();
//                    }
//                })//设置结构化消息控件点击事件回调接口.
//                .setChannel("Android")
//                .isShowCustomerNickname(true)//设置是否显示昵称
//                .isShowCustomerHead(true) //设置是否显示头像
//                .setPreSendRobotMessages("你好呀......"); //设置带入一条消息  进入机器人界面自动发送
//
//        return builder;
//    }


}
