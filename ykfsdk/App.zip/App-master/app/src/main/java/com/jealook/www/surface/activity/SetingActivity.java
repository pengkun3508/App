package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.dm.lib.utils.StatusBarUtils;
import com.flyco.roundview.RoundTextView;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.mvp.presenter.SetingPresenter;
import com.jealook.www.surface.mvp.view.SetingView;
import com.jealook.www.widgat.actionbar.ActionBarSimple;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
     * @Description:设置页面
     * @Time:2020/4/14 9:45
     * @Author:pk
     */
public class SetingActivity extends BaseActivity<SetingPresenter> implements SetingView {


    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.ll_fee)
    LinearLayout llFee;
    @BindView(R.id.ll_about)
    LinearLayout llAbout;
    @BindView(R.id.view_lin)
    View viewLin;
    @BindView(R.id.tv_out)
    RoundTextView tvOut;

    public static void startSelf(Context context) {
        Intent intent = new Intent(context, SetingActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_seting;
    }

    @Override
    protected SetingPresenter initPresenter() {
        return new SetingPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        viewLin.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override
    protected void loadData() {

    }

    @OnClick({R.id.ll_fee, R.id.ll_about, R.id.tv_out, R.id.ll_bind})
    @Override
    public void onClick(View v) {
        super.onClick(v);
    }

    @Override
    public boolean onClickWithoutLogin(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.ll_fee:
                UserEvaluationActivity.startSelf(getContext());
                break;
            case R.id.ll_bind:
                ChangePhoneActivity.startSelf(getContext());
                break;
            case R.id.tv_out:
                LoginActivity.startSelf(getContext());
                break;
            case R.id.ll_about:
                AboutActivity.startSelf(getContext());
                break;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }
}
