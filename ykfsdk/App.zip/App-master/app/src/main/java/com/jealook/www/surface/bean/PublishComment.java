package com.jealook.www.surface.bean;

import java.util.List;

import per.goweii.rxhttp.request.base.BaseBean;

/**
 * @Description:
 * @Time:2020/5/21$
 * @Author:pk$
 */
public class PublishComment extends BaseBean {
    /**
     * color_id : 555
     * product_id : 2038
     * product_number : 22
     * product_price : 145.00
     * preferential_price : 130.50
     * color : 棕色
     * search_attr : 529|555
     * goods_sn : JLH1000019
     * goods_id : 19
     * is_promote : 1
     * promote_start_date : 1586707200
     * promote_end_date : 1590940800
     * suppliers_id : 2
     * shop_name : 日本Ever color日抛型
     * brand_name : Evercolor
     * surplus_time : 889329
     * shop_attr_name : Chiff on Brown 20枚
     * details : ["http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730343570977.jpg","http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730360906215.jpg","http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730365219048.jpg","http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730370185767.jpg","http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730383990510.jpg","http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730388824407.jpg","http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730393659939.jpg","http://admin.jealook.com/ueditor/php/upload/image/20200401/1585730398819703.jpg"]
     * banner : ["http://img.jealook.com/backend/20200401/1585733834_1322.png","http://img.jealook.com/backend/20200401/1585733834_8566.png"]
     * origin : 中国台湾
     * toss_period : 日抛
     * textures : 水胶
     * base_curve : 8.7
     * water_content : 42.5%
     * diameter : 14.5mm
     * coloring_diameter : 14.2
     * life_span : 5年(具体见包装）
     * is_show : 0
     */

    private String color_id;
    private String product_id;
    private String product_number;
    private String product_price;
    private String preferential_price;
    private String color;
    private String search_attr;
    private String goods_sn;
    private String goods_id;
    private int is_promote;
    private String promote_start_date;
    private String promote_end_date;
    private String suppliers_id;
    private String shop_name;
    private String brand_name;
    private int surplus_time;
    private String shop_attr_name;
    private String origin;
    private String toss_period;
    private String textures;
    private String base_curve;
    private String water_content;
    private String diameter;
    private String coloring_diameter;
    private String life_span;
    private int is_show;
    private List<String> details;
    private List<String> banner;

    public String getColor_id() {
        return color_id;
    }

    public void setColor_id(String color_id) {
        this.color_id = color_id;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProduct_number() {
        return product_number;
    }

    public void setProduct_number(String product_number) {
        this.product_number = product_number;
    }

    public String getProduct_price() {
        return product_price;
    }

    public void setProduct_price(String product_price) {
        this.product_price = product_price;
    }

    public String getPreferential_price() {
        return preferential_price;
    }

    public void setPreferential_price(String preferential_price) {
        this.preferential_price = preferential_price;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSearch_attr() {
        return search_attr;
    }

    public void setSearch_attr(String search_attr) {
        this.search_attr = search_attr;
    }

    public String getGoods_sn() {
        return goods_sn;
    }

    public void setGoods_sn(String goods_sn) {
        this.goods_sn = goods_sn;
    }

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public int getIs_promote() {
        return is_promote;
    }

    public void setIs_promote(int is_promote) {
        this.is_promote = is_promote;
    }

    public String getPromote_start_date() {
        return promote_start_date;
    }

    public void setPromote_start_date(String promote_start_date) {
        this.promote_start_date = promote_start_date;
    }

    public String getPromote_end_date() {
        return promote_end_date;
    }

    public void setPromote_end_date(String promote_end_date) {
        this.promote_end_date = promote_end_date;
    }

    public String getSuppliers_id() {
        return suppliers_id;
    }

    public void setSuppliers_id(String suppliers_id) {
        this.suppliers_id = suppliers_id;
    }

    public String getShop_name() {
        return shop_name;
    }

    public void setShop_name(String shop_name) {
        this.shop_name = shop_name;
    }

    public String getBrand_name() {
        return brand_name;
    }

    public void setBrand_name(String brand_name) {
        this.brand_name = brand_name;
    }

    public int getSurplus_time() {
        return surplus_time;
    }

    public void setSurplus_time(int surplus_time) {
        this.surplus_time = surplus_time;
    }

    public String getShop_attr_name() {
        return shop_attr_name;
    }

    public void setShop_attr_name(String shop_attr_name) {
        this.shop_attr_name = shop_attr_name;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getToss_period() {
        return toss_period;
    }

    public void setToss_period(String toss_period) {
        this.toss_period = toss_period;
    }

    public String getTextures() {
        return textures;
    }

    public void setTextures(String textures) {
        this.textures = textures;
    }

    public String getBase_curve() {
        return base_curve;
    }

    public void setBase_curve(String base_curve) {
        this.base_curve = base_curve;
    }

    public String getWater_content() {
        return water_content;
    }

    public void setWater_content(String water_content) {
        this.water_content = water_content;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    public String getColoring_diameter() {
        return coloring_diameter;
    }

    public void setColoring_diameter(String coloring_diameter) {
        this.coloring_diameter = coloring_diameter;
    }

    public String getLife_span() {
        return life_span;
    }

    public void setLife_span(String life_span) {
        this.life_span = life_span;
    }

    public int getIs_show() {
        return is_show;
    }

    public void setIs_show(int is_show) {
        this.is_show = is_show;
    }

    public List<String> getDetails() {
        return details;
    }

    public void setDetails(List<String> details) {
        this.details = details;
    }

    public List<String> getBanner() {
        return banner;
    }

    public void setBanner(List<String> banner) {
        this.banner = banner;
    }
}
