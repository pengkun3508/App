package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.http.model.ShopCartListBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.bean.ModifyTypeBean;

/**
 * 描述：
 *
 * @author Yanbo
 * @date 2019/3/7
 */
public interface VideonFragmentView extends MvpView {

    void getAppUpdateSuccess(int code, VersionBean version);

    void getAppUpdateFail(int code, String msg);

    void getShopListDataSuccess(int code, ShopCartListBean data);

    void getShopListDataFail(int code, String msg);

    void getAddAndReduceSuccess(int code, ShopCartListBean data);

    void getAddAndReduceFail(int code, String msg);

    void getDeleteDataSuccess(int code, ShopCartListBean data);

    void getDeleteDataFail(int code, String msg);

    void getTypeShopSuccess(int code, MoveDataBean data);

    void getTypeShopFail(int code, String msg);

    void getModifyTypeSuccess(int code, ModifyTypeBean data);

    void getModifyTypeFail(int code, String msg);

    void getSelectShoppingSuccess(int code, ShopCartListBean data);

    void getSelectShoppingFail(int code, String msg);

    void getConfirmOrderSuccess(int code, ConfirmOrderBean data);

    void getConfirmOrderFail(int code, String msg);
}
