package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;

/**
 * @Description:
 * @Time:2020/7/13$
 * @Author:pk$
 */
public interface ProtocolPrivacyView extends MvpView {
}
