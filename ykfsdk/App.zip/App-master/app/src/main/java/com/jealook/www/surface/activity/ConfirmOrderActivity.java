package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.utils.StatusBarUtils;
import com.flyco.roundview.RoundTextView;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.event.AddressListBean_2Event;
import com.jealook.www.event.Address_KeyDown;
import com.jealook.www.event.CancelYouHuiQuanEvent;
import com.jealook.www.event.CouponEvent;
import com.jealook.www.event.RealName_2Event;
import com.jealook.www.http.model.AddressListBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.adapter.ConfirmOrderAdapter;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.bean.RealNameListBean;
import com.jealook.www.surface.mvp.presenter.ConfirmOrderPresenter;
import com.jealook.www.surface.mvp.view.ConfirmOrderView;
import com.jealook.www.utils.CacheActivity;
import com.jealook.www.utils.DoubleOperationUtils;
import com.jealook.www.widgat.actionbar.ActionBarSimple;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @Description:确认下单
 * @Time:2020/4/2 15:26
 * @Author:pk
 */
public class ConfirmOrderActivity extends BaseActivity<ConfirmOrderPresenter> implements ConfirmOrderView {

    @BindView(R.id.view_lin)
    View viewLin;
    @BindView(R.id.order_realname_2)
    RelativeLayout orderRealname2;
    @BindView(R.id.order_realname_1)
    RelativeLayout orderRealname1;
    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.rl_address_1)
    RelativeLayout rlAddress1;
    @BindView(R.id.rl_address_2)
    RelativeLayout rlAddress2;
    @BindView(R.id.tv_ko)
    RoundTextView tvKo;
    Context context;
    static String recId = "";
    static String goods_id = "";
    static String product_id = "";
    static String num = "";
    static String order_id = "";
    @BindView(R.id.confirm_address_name)
    TextView confirmAddressName;
    @BindView(R.id.confirm_address_phone)
    TextView confirmAddressPhone;
    @BindView(R.id.confirm_address_address)
    TextView confirmAddressAddress;
    @BindView(R.id.confirm_realname_name)
    TextView confirmRealnameName;
    @BindView(R.id.confirm_realname_idcard)
    TextView confirmRealnameIdcard;
    @BindView(R.id.confirm_recycler)
    RecyclerView confirmRecycler;
    @BindView(R.id.order_yhq_money)
    TextView orderYhqMoney;
    @BindView(R.id.confirm_order_price)
    TextView confirmOrderPrice;
    @BindView(R.id.confirm_order_fee)
    TextView confirmOrderFee;
    @BindView(R.id.confirm_order_toale_price)
    TextView confirmOrderToalePrice;

    ConfirmOrderAdapter confirmOrderAdapter;
    ConfirmOrderBean confirmOrderBean;
    String address_id = "";
    String real_id = "";
    @BindView(R.id.confirm_message)
    EditText confirmMessage;

    String payPrice;
    @BindView(R.id.id_1)
    ImageView id1;
    @BindView(R.id.id_2)
    ImageView id2;
    @BindView(R.id.bottom_layout)
    LinearLayout bottomLayout;
    @BindView(R.id.scrollview)
    ScrollView scrollview;
    @BindView(R.id.order_conpon_layout)
    RelativeLayout orderConponLayout;

    String bonus_id = "";//优惠券ID

    @BindView(R.id.order_yhq_jine_money)
    TextView orderYhqJineMoney;
    @BindView(R.id.order_conpon_jine_layout)
    RelativeLayout orderConponJineLayout;
    @BindView(R.id.confirm_shuifei)
    TextView confirmShuifei;
    @BindView(R.id.queren_deils_text)
    TextView querenDeilsText;
    @BindView(R.id.layout_queren_deils)
    LinearLayout layoutQuerenDeils;
    @BindView(R.id.suifei_layout)
    RelativeLayout suifeiLayout;

    RealNameListBean realBean = null;//实名认证Bean
    AddressListBean addressBean = null;//地址Bean

    public static void startSelf(Context context, String recIds, String goods_ids, String product_ids, String nums) {
        Intent intent = new Intent(context, ConfirmOrderActivity.class);
        context.startActivity(intent);
        recId = recIds;
        goods_id = goods_ids;
        product_id = product_ids;
        num = nums;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_confirm_order;
    }

    @Override
    protected ConfirmOrderPresenter initPresenter() {
        return new ConfirmOrderPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        CacheActivity.addActivity(ConfirmOrderActivity.this);
        int heights = bottomLayout.getHeight();
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMarginEnd(heights + 20);
        scrollview.setLayoutParams(layoutParams);

//        viewLin.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
//        final GridLayoutManager manager1 = new GridLayoutManager(getActivity(), 1);
//        confirmRecycler.setLayoutManager(manager1);
//        confirmRecycler.addItemDecoration(new SpacesItemDecoration(DensityUtils.dp2px(getActivity(), 3)));
//        confirmRecycler.addItemDecoration(new SpaceItemDecoration(0, 0));
//        confirmRecycler.setNestedScrollingEnabled(false);
//        confirmRecycler.setHasFixedSize(true);
        confirmRecycler.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false) {
            @Override
            public boolean canScrollVertically() {

                return false;
            }
        });

        confirmOrderAdapter = new ConfirmOrderAdapter(this);
        confirmRecycler.setAdapter(confirmOrderAdapter);


    }

    @Override
    protected void loadData() {
//        presenter.getAppUpdate();//下载时间
        presenter.getConfirmOrderData(recId, goods_id, product_id, num);

    }

    @Override
    protected void onResume() {
        super.onResume();
//        presenter.getConfirmOrderData(recId, goods_id, product_id, num);
    }

    /**
     * 下载时间成功
     *
     * @param code
     * @param version
     */
    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {
    }

    /**
     * 下载时间失败
     *
     * @param code
     * @param
     */
    @Override
    public void getAppUpdateFail(int code, String msg) {

    }

    /**
     * 下载确认订单成功
     *
     * @param code
     * @param
     */
    @Override
    public void getConfirmOrderSuccess(int code, ConfirmOrderBean data) {
//        rlAddress2  -- 无地址布局
//        rlAddress1  --有地址布局
//        orderRealname1   ==无实名认证布局
//        order_realname_2://有数据--实名认证

        confirmOrderBean = data;
        confirmOrderPrice.setText("￥" + data.getGoods_price());
        payPrice = data.getPrice();
        confirmOrderToalePrice.setText(data.getPrice());
        confirmOrderFee.setText("￥" + data.getPost_fee());
        orderYhqJineMoney.setText("￥" + data.getCoupon_price());
//        double divNumber = DoubleOperationUtils.div(1.091, Double.valueOf(data.getPrice()));
//        Log.e("==下载确认订单成功==", "==税费111==" + divNumber);
//        double mulNumber = DoubleOperationUtils.mul(0.091, divNumber);
//        Log.e("==下载确认订单成功==", "==税费222==" + mulNumber);
//        double resultNumber = DoubleOperationUtils.round(mulNumber, 2);
//        confirmShuifei.setText("已包含商品税费：¥" + resultNumber);//税费
//        Log.e("==下载确认订单成功==", "==税费==" + resultNumber);

        Log.e("==下载确认订单成功qaz==", "==getId==" + data.getBonus_info().getId());

        if (data.getBonus_info().getId() != null) {
            bonus_id = data.getBonus_info().getId();
            Log.e("==下载确认订单成功qaz==", "==getCoupon_name==" + data.getBonus_info().getCoupon_name());
//            orderYhqMoney.setText("满" + data.getBonus_info().getMin_goods_amount() + "减" + data.getBonus_info().getType_money() + "元");
            orderYhqMoney.setText(data.getBonus_info().getCoupon_name());

        } else {
            orderYhqMoney.setText("未选择优惠券");
        }


        double divNumber = Double.valueOf(data.getPrice()) / 1.091;
        Log.e("==下载确认订单成功==", "==税费111==" + divNumber);
        double mulNumber = divNumber * 0.091;
        Log.e("==下载确认订单成功==", "==税费222==" + mulNumber);
        double resultNumber = DoubleOperationUtils.round(mulNumber, 2);


        ;

        if (data.getShop_list().get(0).getSuppliers_id().equals("1")) {//自营
            suifeiLayout.setVisibility(View.GONE);
        } else if (data.getShop_list().get(0).getSuppliers_id().equals("2")) {//海淘
            suifeiLayout.setVisibility(View.VISIBLE);
        }
        confirmShuifei.setText("¥" + resultNumber);//税费
        Log.e("==下载确认订单成功==", "==税费==" + resultNumber);

        Log.e("==下载确认订单成功==", "==getList().getId==" + data.getOrder_ad().getList().getId());

        if (!data.getOrder_ad().getList().getId().equals("") && data.getOrder_ad().getList().getId() != null) {
            layoutQuerenDeils.setVisibility(View.VISIBLE);
            querenDeilsText.setText(data.getOrder_ad().getList().getText());
        } else {
            layoutQuerenDeils.setVisibility(View.GONE);
        }


        confirmOrderAdapter.setData(data.getShop_list());
        if (data.getAddress_list().size() > 0) {
            rlAddress1.setVisibility(View.VISIBLE);
            rlAddress2.setVisibility(View.GONE);
            for (int i = 0; i < data.getAddress_list().size(); i++) {
                if (data.getAddress_list().get(i).getIs_default().equals("1")) {//默认值
                    confirmAddressName.setText(data.getAddress_list().get(i).getAddress_name());
                    confirmAddressPhone.setText(data.getAddress_list().get(i).getMobile());
                    confirmAddressAddress.setText(data.getAddress_list().get(i).getAddress_refer() + " " + data.getAddress_list().get(i).getAddress());
                    address_id = data.getAddress_list().get(i).getAddress_id();
                    break;
                }
            }
        } else {
            address_id = "";
            rlAddress1.setVisibility(View.GONE);
            rlAddress2.setVisibility(View.VISIBLE);
        }
        if (data.getReal_list().size() > 0) {//有实名认证信息
            orderRealname2.setVisibility(View.VISIBLE);
            orderRealname1.setVisibility(View.GONE);
            for (int i = 0; i < data.getReal_list().size(); i++) {
                if (data.getReal_list().get(i).getIs_default().equals("1")) {//默认值
                    confirmRealnameName.setText(data.getReal_list().get(i).getName());
                    confirmRealnameIdcard.setText(data.getReal_list().get(i).getId_card());
                    real_id = data.getReal_list().get(i).getId();
                    break;
                }
            }
        } else {
            real_id = "";
            orderRealname2.setVisibility(View.GONE);
            orderRealname1.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 下载确认订单失败
     *
     * @param code
     * @param
     */
    @Override
    public void getConfirmOrderFail(int code, String msg) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @OnClick({R.id.order_realname_2, R.id.order_realname_1, R.id.rl_address_1, R.id.rl_address_2, R.id.order_conpon_layout, R.id.tv_ko})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.order_realname_2://有数据--实名认证
                RealNameActivity.startSelf(this, "0");
                break;
            case R.id.order_realname_1:// 无数据  --实名认证
                RealNameActivity.startSelf(this, "0");
                break;
            case R.id.rl_address_1://有数据  --地址
                AddressActivity.startSelf(this, "0");
                break;
            case R.id.rl_address_2://无数据  --地址
                AddressActivity.startSelf(this, "0");
                break;
            case R.id.order_conpon_layout://优惠券列表
//                CouponActivity_1.startSelf(getContext(), getRed_list);

                CouponActivity_1.startSelf(getContext(), recId, goods_id, product_id, num);
                break;
            case R.id.tv_ko://提交订单
                String type = "";
                Log.e("提交订单", "==address_id==" + address_id);
                Log.e("提交订单", "==real_id==" + real_id);
                if (Double.valueOf(confirmOrderToalePrice.getText().toString().trim()) > 5000) {
                    Toast.makeText(this, "海淘商品单笔订单不能超过5000元", Toast.LENGTH_SHORT).show();
                } else {
                    if (address_id.equals("")) {
                        Toast.makeText(this, "请先选择收货地址信息", Toast.LENGTH_SHORT).show();
                    } else if (real_id.equals("")) {
                        Toast.makeText(this, "请先选择实名认证信息", Toast.LENGTH_SHORT).show();
                    } else {
                        if (!bonus_id.equals("")) {
                            PayOrderActivity.startSelf(this, recId, goods_id, product_id, num, real_id, address_id, type, confirmMessage.getText().toString(), order_id, payPrice, bonus_id);
                        } else {
                            PayOrderActivity.startSelf(this, recId, goods_id, product_id, num, real_id, address_id, type, confirmMessage.getText().toString(), order_id, payPrice, bonus_id);
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }


    //接收消息--系统返回键
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(Address_KeyDown event) {
        Log.e("Address_KeyDown", "==系统返回键==");
        presenter.getConfirmOrderData(recId, goods_id, product_id, num);
    }


    //接收消息--优惠券--取消
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(CancelYouHuiQuanEvent event) {
        Log.e("", "==实名接收消息==");
        String mark = event.getMark();
        presenter.getConfirmOrderData1(recId, goods_id, product_id, num, mark);

    }

    //接收消息--实名
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(RealName_2Event event) {
        Log.e("接收消息", "==实名接收消息==" + event.getRealNameBean());
        orderRealname2.setVisibility(View.VISIBLE);
        orderRealname1.setVisibility(View.GONE);
        realBean = event.getRealNameBean();
        confirmRealnameName.setText(realBean.getName());
        confirmRealnameIdcard.setText(realBean.getId_card());
        real_id = realBean.getId();
    }

    //接收消息--地址
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(AddressListBean_2Event event) {
        Log.e("接收消息", "==地址接收消息==" + event.getAddressListBean());
        rlAddress1.setVisibility(View.VISIBLE);//有地址
        rlAddress2.setVisibility(View.GONE);//无地址
        addressBean = event.getAddressListBean();
        confirmAddressName.setText(addressBean.getAddress_name());
        confirmAddressPhone.setText(addressBean.getMobile());
        confirmAddressAddress.setText(addressBean.getAddress());
        address_id = addressBean.getAddress_id();
    }

    //接收消息--优惠券
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(CouponEvent event) {
        Log.e("CouponEvent", "==优惠券接收消息==" + event.getData());

        //判断实名是否存在
        if (realBean != null) {
            confirmRealnameName.setText(realBean.getName());
            confirmRealnameIdcard.setText(realBean.getId_card());
            real_id = realBean.getId();
        }
        //判断地址是否存在
        if (realBean != null) {
            confirmAddressName.setText(addressBean.getAddress_name());
            confirmAddressPhone.setText(addressBean.getMobile());
            confirmAddressAddress.setText(addressBean.getAddress());
            address_id = addressBean.getAddress_id();
        }


        ConfirmOrderBean data = event.getData();
        confirmOrderBean = data;
        orderYhqMoney.setText(data.getBonus_info().getCoupon_name());
        bonus_id = data.getBonus_info().getId();

        confirmOrderPrice.setText("￥" + data.getGoods_price());
        payPrice = data.getPrice();
        confirmOrderToalePrice.setText(data.getPrice());
        confirmOrderFee.setText("￥" + data.getPost_fee());
        orderYhqJineMoney.setText("￥" + data.getCoupon_price());
        double divNumber = Double.valueOf(data.getPrice()) / 1.091;
        Log.e("==优惠券接收消息==", "==税费111==" + divNumber);
        double mulNumber = divNumber * 0.091;
        Log.e("==优惠券接收消息==", "==税费222==" + mulNumber);
        double resultNumber = DoubleOperationUtils.round(mulNumber, 2);
        confirmShuifei.setText("¥" + resultNumber);//税费
        Log.e("==优惠券接收消息==", "==税费==" + resultNumber);

        confirmOrderAdapter.setData(data.getShop_list());
//        if (data.getAddress_list().size() > 0) {
//            rlAddress1.setVisibility(View.VISIBLE);
//            rlAddress2.setVisibility(View.GONE);
//            for (int i = 0; i < data.getAddress_list().size(); i++) {
//                if (data.getAddress_list().get(i).getIs_default().equals("1")) {//默认值
//                    confirmAddressName.setText(data.getAddress_list().get(i).getAddress_name());
//                    confirmAddressPhone.setText(data.getAddress_list().get(i).getMobile());
//                    confirmAddressAddress.setText(data.getAddress_list().get(i).getAddress_refer() + " " + data.getAddress_list().get(i).getAddress());
//                    address_id = data.getAddress_list().get(i).getAddress_id();
//                    break;
//                }
//            }
//        } else {
//            address_id = "";
//            rlAddress1.setVisibility(View.GONE);
//            rlAddress2.setVisibility(View.VISIBLE);
//        }
//        if (data.getReal_list().size() > 0) {//有实名认证信息
//            orderRealname2.setVisibility(View.VISIBLE);
//            orderRealname1.setVisibility(View.GONE);
//            for (int i = 0; i < data.getReal_list().size(); i++) {
//                if (data.getReal_list().get(i).getIs_default().equals("1")) {//默认值
//                    confirmRealnameName.setText(data.getReal_list().get(i).getName());
//                    confirmRealnameIdcard.setText(data.getReal_list().get(i).getId_card());
//                    real_id = data.getReal_list().get(i).getId();
//                    break;
//                }
//            }
//        } else {
//            real_id = "";
//            orderRealname2.setVisibility(View.GONE);
//            orderRealname1.setVisibility(View.VISIBLE);
//        }

    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (resultCode == 1) {
//            AddressListBean bean = (AddressListBean) data.getSerializableExtra("bean");
//            confirmAddressName.setText(bean.getAddress_name());
//            confirmAddressPhone.setText(bean.getMobile());
//            confirmAddressAddress.setText(bean.getAddress());
//            address_id = bean.getAddress_id();
//        }
//    }


}


