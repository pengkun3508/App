package com.jealook.www.surface.mvp.presenter;

import android.util.Log;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.http.RequestBackListener;
import com.jealook.www.http.model.CommodityListBean;
import com.jealook.www.surface.bean.SearchListListBean;
import com.jealook.www.surface.mvp.model.MainRequest;
import com.jealook.www.surface.mvp.view.SearchListView;

/**
 * @Description:
 * @Time:2020/5/25$
 * @Author:pk$
 */
public class SearchListPresenter extends MvpPresenter<SearchListView> {

    public void getSearchListData(int page, int limit, String keyword) {

        addToRxLife(MainRequest.getSearchListData(page, limit, keyword, new RequestBackListener<SearchListListBean>() {
            @Override
            public void onStart() {
//                showLoading();
            }

            @Override
            public void onSuccess(int code, SearchListListBean data) {
                if (isAttachView())
                    getBaseView().getSearchListDataSuccess(code, data);
            }

            @Override
            public void onFailed(int code, String msg) {
                Log.e("code", "code===" + code);
                Log.e("msg", "msg===" + msg);
                if (isAttachView())
                    getBaseView().getSearchListDataFail(code, msg);
            }

            @Override
            public void onNoNet() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onFinish() {
//                dismissLoading();
            }
        }));

    }
}
