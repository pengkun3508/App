package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.event.CancelYouHuiQuanEvent;
import com.jealook.www.event.CouponEvent;
import com.jealook.www.http.model.AlreadyCouponListBean;
import com.jealook.www.http.model.NotCouponListBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.adapter.CouponAdapter_1;
import com.jealook.www.surface.adapter.CouponYesAdapter_1;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.mvp.presenter.CouponPresenter;
import com.jealook.www.surface.mvp.view.CouponView;
import com.jealook.www.widgat.actionbar.ActionBarSimple;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @Description:我的优惠券
 * @Time:2020/4/1 18:15
 * @Author:pk
 */
public class CouponActivity_1 extends BaseActivity<CouponPresenter> implements CouponView, CouponAdapter_1.ItemBtnClickListener, CouponYesAdapter_1.ItemBtnClickListener {
    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.imageButton1)
    RadioButton imageButton1;//未使用
    @BindView(R.id.imageButton2)
    RadioButton imageButton2;//已使用
    @BindView(R.id.all_view)
    View allView;
    @BindView(R.id.ziying_view)
    View ziyingView;


    TextView coupon_btn;

    static String recId = "";
    static String goods_id = "";
    static String product_id = "";
    static String num = "";

    private CouponAdapter_1 adapter;
    CouponYesAdapter_1 yesAdapter;
    String getType_id;//优惠券ID
    String str;//拼接的满减券


    public static void startSelf(Context context, String recIds, String goods_ids, String product_ids, String nums) {
        Intent intent = new Intent(context, CouponActivity_1.class);
        context.startActivity(intent);
        recId = recIds;
        goods_id = goods_ids;
        product_id = product_ids;
        num = nums;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_coupon;
    }

    @Override
    protected CouponPresenter initPresenter() {
        return new CouponPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        actionBar.getTvRight().setText("取消");
        actionBar.getTvRight().setVisibility(View.VISIBLE);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CouponAdapter_1(this, this);
        yesAdapter = new CouponYesAdapter_1(this, this);
        recyclerView.setAdapter(adapter);

        //取消优惠券
        actionBar.getTvRight().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CancelYouHuiQuanEvent("-1").post();
                finish();

            }
        });

    }

    @Override
    protected void loadData() {
        presenter.getCouponListData1(recId, product_id, product_id, num);//已领取列表数据

//        presenter.getCouponListData(recId, product_id, product_id, num);//未领取列表数据

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @OnClick({R.id.imageButton1, R.id.imageButton2})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.imageButton1://未领取
                allView.setBackgroundColor(getResources().getColor(R.color.white));
                ziyingView.setBackgroundColor(getResources().getColor(R.color.them));
                presenter.getCouponListData("", "", "", "");//下载列表数据
                break;
            case R.id.imageButton2://已领取
                allView.setBackgroundColor(getResources().getColor(R.color.them));
                ziyingView.setBackgroundColor(getResources().getColor(R.color.white));
                presenter.getCouponListData1(recId, product_id, product_id, num);//已领取列表数据
                break;

        }
    }

    /**
     * 领取---优惠券按钮
     *
     * @param type_id
     * @param
     */
    @Override
    public void onBtnClickListener(String type_id, TextView coupon_btns, int pos) {
        Log.e("领取优惠券", "==type_id==" + type_id);
//        coupon_btn = coupon_btns;
//        if (adapter.getData().get(pos).getType().equals("1")) {//领取优惠券
//            Log.e("领取优惠券", "==mark=111===" + adapter.getData().get(pos).getType());
//            presenter.getCollectCoupons(type_id);
//        } else if (adapter.getData().get(pos).getType().equals("2")) {//使用
//            Log.e("领取优惠券", "==mark=222===" + adapter.getData().get(pos).getType());
//
//            getType_id = adapter.getData().get(pos).getId();
//            str = "满" + adapter.getData().get(pos).getMin_money() + "减" + adapter.getData().get(pos).getReduced() + "元";
//            presenter.getConfirmOrderData1(recId, goods_id, product_id, num, adapter.getData().get(pos).getId());
//
//        }

        presenter.getCollectCoupons(type_id);

    }

    /**
     * 使用---优惠券按钮
     *
     * @param type_id
     * @param
     */
    @Override
    public void onBtnClickListener_1(String type_id, View coupon_btn, int pos) {
        presenter.getConfirmOrderData1(recId, goods_id, product_id, num, yesAdapter.getData().get(pos).getId());
    }

    @Override
    public void getAppUpdateSuccess(int code, VersionBean version) {

    }

    @Override
    public void getAppUpdateFail(int code, String msg) {

    }


    /**
     * @Description:下载列表数据成功--未领取
     * @Time:2020/5/8 9:33
     * @Author:pk
     */
    @Override
    public void getCouponListSuccess(int code, List<NotCouponListBean> data) {
        recyclerView.setAdapter(adapter);
        yesAdapter.clearData();
        adapter.setData(data);
        adapter.notifyDataSetChanged();

    }

    /**
     * @Description:下载列表数据失败--未领取
     * @Time:2020/5/8 9:33
     * @Author:pk
     */
    @Override
    public void getCouponListFail(int code, String msg) {

    }

    /**
     * @Description:下载列表数据成功--已领取
     * @Time:2020/5/8 9:33
     * @Author:pk
     */
    @Override
    public void getCouponList1Success(int code, List<AlreadyCouponListBean> data) {
        recyclerView.setAdapter(yesAdapter);
        adapter.clearData();
        yesAdapter.setData(data);
        yesAdapter.notifyDataSetChanged();
    }

    /**
     * @Description:下载列表数据失败--已领取
     * @Time:2020/5/8 9:33
     * @Author:pk
     */
    @Override
    public void getCouponList1Fail(int code, String msg) {

    }

    //领取优惠券成功
    @Override
    public void getCollectCouponsSuccess(int code, Object data) {
//        coupon_btn.setVisibility(View.INVISIBLE);
        Toast.makeText(this, "领取成功", Toast.LENGTH_SHORT).show();
        presenter.getCouponListData(recId, product_id, product_id, num);//下载列表数据
    }

    @Override
    public void getCollectCouponsFail(int code, String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    //使用优惠券成功
    @Override
    public void getConfirmOrderSuccess(int code, ConfirmOrderBean data) {
        new CouponEvent(getType_id, str, data).post();
        finish();


    }

    @Override
    public void getConfirmOrderFail(int code, String msg) {

    }


}
