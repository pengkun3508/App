package com.jealook.www.surface.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dm.lib.core.adapter.rv.state.BaseHolder;
import com.dm.lib.core.adapter.rv.state.BaseStateAdapter;
import com.jealook.www.R;
import com.jealook.www.http.model.OrderDetailsBean;
import com.jealook.www.surface.activity.PublishCommentActivity;
import com.jealook.www.utils.ImageLoader;

/**
 * @Description:
 * @Time:2020/5/8$
 * @Author:pk$
 */
public class OrderDetailsAdapter extends BaseStateAdapter<OrderDetailsBean.ShopListBean, OrderDetailsAdapter.OrderDetailsHolder> {

    Context context;
    String order_id;
    int getStatus;

    public OrderDetailsAdapter(Context context) {
        super();
        this.context = context;
    }

    @Override
    protected OrderDetailsHolder getViewHolder(@NonNull ViewGroup parent, int holderType) {
        return new OrderDetailsHolder(inflate(parent, R.layout.order_details_item));
    }


    public void setOrder_Id(String order_ids, int getStatuss) {
        order_id = order_ids;
        getStatus = getStatuss;
    }

    class OrderDetailsHolder extends BaseHolder<OrderDetailsBean.ShopListBean> {

        ImageView order_item_image;
        TextView order_item_name, order_item_type, order_item_number, order_item_price, order_pingjia_btn;

        OrderDetailsHolder(View itemView) {
            super(itemView);
            order_item_image = getView(R.id.order_item_image);
            order_item_name = getView(R.id.order_item_name);
            order_item_type = getView(R.id.order_item_type);
            order_item_number = getView(R.id.order_item_number);
            order_item_price = getView(R.id.order_item_price);
            order_pingjia_btn = getView(R.id.order_pingjia_btn);

        }

        @Override
        protected void bindData(OrderDetailsBean.ShopListBean data) {
            ImageLoader.image(context, order_item_image, data.getGoods_thumb());
            order_item_name.setText(data.getGoods_name());
            order_item_type.setText(data.getGoods_attr_name());
            order_item_number.setText(data.getNumber());
            order_item_price.setText(data.getProduct_price());
            if (getStatus == 3) {//评价状态
                if (data.getComment_id().equals("0")) {//判断是否评价状态
                    order_pingjia_btn.setVisibility(View.VISIBLE);
                } else {
                    order_pingjia_btn.setVisibility(View.GONE);
                }
            } else {
                order_pingjia_btn.setVisibility(View.GONE);
            }


            /**
             * 评价
             */
            order_pingjia_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.e("OrderDetailsAdapter", "点击评价===");
                    PublishCommentActivity.startSelf(context, data.getGoods_id(), data.getSearch_attr(), order_id, data.getRec_id());


                }
            });

        }


    }
}