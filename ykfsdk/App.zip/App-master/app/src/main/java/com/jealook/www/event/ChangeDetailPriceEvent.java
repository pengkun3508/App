package com.jealook.www.event;

import com.dm.lib.core.eventbas.BaseEvent;

/**
 * @Description:
 * @Time:2020/6/18$
 * @Author:pk$
 */
public class ChangeDetailPriceEvent extends BaseEvent {


    String price;
    String attr_name;

    public ChangeDetailPriceEvent(String prices, String attr_names) {
        // TODO Auto-generated constructor stub
        price = prices;
        attr_name = attr_names;
    }

    public String getPrice() {
        return price;
    }

    public String getAttr_name() {
        return attr_name;
    }


}
