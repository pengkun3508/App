package com.jealook.www.surface.fragment;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.DisplayInfoUtils;
import com.dm.lib.utils.StatusBarUtils;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.jealook.www.R;
import com.jealook.www.base.BaseFragment;
import com.jealook.www.common.Config;
import com.jealook.www.surface.activity.OrderDetailsActivity;
import com.jealook.www.surface.activity.ProductDetailsActivity;
import com.jealook.www.surface.adapter.HomeTabAdapter;
import com.jealook.www.surface.adapter.PurchaseAdapter;
import com.jealook.www.surface.mvp.presenter.HomeFragmentPresenter;
import com.jealook.www.surface.mvp.presenter.Purchase1Presenter;
import com.jealook.www.surface.mvp.view.HomeFragmentView;
import com.jealook.www.surface.mvp.view.Purchase1View;
import com.jealook.www.utils.SmartRefreshHelper;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

public class Purchase1Fragment extends BaseFragment<Purchase1Presenter> implements Purchase1View {

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.smart_refresh_layout)
    SmartRefreshLayout smartRefreshLayout;
    private PurchaseAdapter adapter;
    private SmartRefreshHelper<String> mSmartRefreshHelper;
    private int type;
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_purchase;
    }

    public static Fragment Purchase1Fragment(int type){
        Purchase1Fragment purchase1Fragment=new Purchase1Fragment();
        Bundle args=new Bundle(1);
        args.putInt("type",type);
        purchase1Fragment.setArguments(args);
        return purchase1Fragment;
    }
    @Override
    protected Purchase1Presenter initPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        type=getArguments().getInt("type");
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new PurchaseAdapter();
        adapter.setType(type);
        recyclerView.setAdapter(adapter);
        mSmartRefreshHelper = SmartRefreshHelper.with(smartRefreshLayout, adapter)
                .setPerPageCount(Config.ONE_PAGE_ITEM_MAX_COUNT_DEFAULT)
                .init(new SmartRefreshHelper.RefreshCallback() {
                    @Override
                    public void doRequestData(int page) {
                        mSmartRefreshHelper.onSuccess(2000,  getData());

                    }
                });
        adapter.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
//                OrderDetailsActivity.startSelf(getContext(),);
            }
        });

    }



    @Override
    protected void loadData() {
        mSmartRefreshHelper.requestFirstPage(false);

    }

    public List<String> getData() {
        List<String> strings = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            strings.add("1");
        }
        return strings;
    }
}
