package com.jealook.www.event;

import com.dm.lib.core.eventbas.BaseEvent;

import java.util.List;

/**
 * @Description:
 * @Time:2020/5/6$
 * @Author:pk$
 */
public class ShopTypeDataEvent extends BaseEvent {
    List<String> getBanner;
    String getProduct_number;
    String getProduct_price;
    String jupdg;
    String mark;

    public ShopTypeDataEvent(String jupdgs, List<String> getBanners) {
        // TODO Auto-generated constructor stub
        getBanner = getBanners;
        jupdg = jupdgs;
    }

    public List<String> getBanner() {
        return getBanner;
    }

    public String getjupdg() {
        return jupdg;
    }

    public ShopTypeDataEvent(String marks, String getProduct_numbers, String getProduct_prices) {
        // TODO Auto-generated constructor stub
        getProduct_number = getProduct_numbers;
        getProduct_price = getProduct_prices;
        mark = marks;
    }
    public String getmarks() {
        return mark;
    }

    public String getProduct_number() {
        return getProduct_number;
    }

    public String getProduct_price() {
        return getProduct_price;
    }

}
