package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.bean.ClassifyBean;
import com.jealook.www.surface.bean.ConfirmOrderBean;

public interface ConfirmOrderView extends MvpView {

    void getAppUpdateSuccess(int code, VersionBean version);

    void getAppUpdateFail(int code, String msg);

    void getConfirmOrderSuccess(int code, ConfirmOrderBean data);

    void getConfirmOrderFail(int code, String msg);
}
