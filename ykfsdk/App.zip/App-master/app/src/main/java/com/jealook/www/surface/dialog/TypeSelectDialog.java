package com.jealook.www.surface.dialog;

import android.animation.Animator;
import android.app.Activity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.utils.ToastMaker;
import com.jealook.www.R;
import com.jealook.www.event.ChangeDetailPriceEvent;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.surface.activity.PhotoViewActivity_1;
import com.jealook.www.surface.adapter.TypeSelectAdapter;
import com.jealook.www.surface.mvp.model.bean.ProductBean;
import com.jealook.www.utils.ImageLoader;

import java.util.List;

import per.goweii.anylayer.AnimHelper;
import per.goweii.anylayer.AnyLayer;

/**
 * @Description:商品详情，规格选择
 * @Time:2020/4/3$
 * @Author:pk$
 */
public class TypeSelectDialog {

    static AnyLayer mAnyLayer;
    private static Activity mActivity;
    private MoveDataBean moveDataBean;
    List<String> getBanner;
    String getBannerUrl;
    static ImageView type_img;
    static TextView type_price;
    static TextView type_number;
    static TextView tv_num;
    static TextView tv_reduce;
    static TextView tv_plus;
    TextView add_shops;
    private static String url;
    AddShopCarClickListener addShopCarClickListener;
    ProductBean productBean;
    String getAttr_name;
    String mark;
    String goods_attr = "";
    String getProduct_id;


    public static TypeSelectDialog with(Activity activity, MoveDataBean moveDataBeas, String goods_attr, String mark, AddShopCarClickListener addShopCarClickListener) {
        return new TypeSelectDialog(activity, moveDataBeas, goods_attr, mark, addShopCarClickListener);
    }

    public TypeSelectDialog(Activity activity, MoveDataBean moveDataBeas, String goods_attrs, String marks, AddShopCarClickListener addShopCarClickListener) {
        this.mActivity = activity;
        this.moveDataBean = moveDataBeas;
        this.goods_attr = goods_attrs;
        this.addShopCarClickListener = addShopCarClickListener;
        this.mark = marks;
    }

    public static void setUrl(String urls) {
        url = urls;
        ImageLoader.image(mActivity, type_img, urls);
        type_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhotoViewActivity_1.startSelf((Activity) mActivity, urls);
            }
        });


    }

    public void show() {
        mAnyLayer = AnyLayer.with(mActivity)
                .contentView(R.layout.dialog_type_select)
                .bindData(new AnyLayer.IDataBinder() {
                    @Override
                    public void bind(AnyLayer anyDialog) {
                        MoveDataBean.InfoBean getInfo = moveDataBean.getInfo();
                        List<ProductBean> getProduct = moveDataBean.getProduct();
                        RecyclerView recyclerView = anyDialog.getView(R.id.recyclerView);
                        recyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
                        String getSearch_attr = getInfo.getSearch_attr();
                        if (goods_attr != null && !goods_attr.equals("")) {
                            getSearch_attr = goods_attr;
                        }
                        TypeSelectAdapter typeSelectAdapter = new TypeSelectAdapter(getSearch_attr, getProduct, moveDataBean.getAttr());
                        recyclerView.setAdapter(typeSelectAdapter);
                        typeSelectAdapter.setData(moveDataBean.getAttr());
                        typeSelectAdapter.setOnTypeSelectItemClick(new TypeSelectAdapter.OnTypeSelectItemClick() {
                            @Override
                            public void onTypeClick(ProductBean productBeans) {
                                if (productBeans == null) {
                                    return;
                                }
                                productBeans.getProduct_price();
                                productBean = productBeans;
                                type_number.setText("库存" + productBeans.getProduct_number() + "件");
                                type_price.setText("￥" + productBeans.getProduct_price());
                                getProduct_id = productBean.getProduct_id();
                                Log.e("getAttr_name", "==getAttr_name==" + productBeans.getAttr_name());
                                getAttr_name = productBeans.getAttr_name();
                                new ChangeDetailPriceEvent(productBeans.getProduct_price(), productBeans.getAttr_name()).post();
                            }
                        });

                        type_img = anyDialog.getView(R.id.type_img);
                        type_price = anyDialog.getView(R.id.type_price);
                        type_number = anyDialog.getView(R.id.type_number);
                        add_shops = anyDialog.getView(R.id.add_shops);
                        tv_reduce = anyDialog.getView(R.id.tv_reduce);
                        tv_num = anyDialog.getView(R.id.tv_num);
                        tv_plus = anyDialog.getView(R.id.tv_plus);
                        getBanner = getInfo.getBanner();
                        if (getBanner.size() > 1) {
                            getBannerUrl = getBanner.get(1);
                        } else {
                            getBannerUrl = getBanner.get(0);
                        }

                        ImageLoader.image(mActivity, type_img, getBannerUrl);
                        type_price.setText("￥" + getInfo.getProduct_price());
                        type_number.setText("库存" + getInfo.getProduct_number() + "件");
                        type_img.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                PhotoViewActivity_1.startSelf((Activity) mActivity, getBannerUrl);
                            }
                        });


                        //加号
                        tv_plus.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                if (productBean != null) {
                                    int s = Integer.valueOf(tv_num.getText().toString()) + 1;
                                    if (s <= Integer.parseInt(productBean.getProduct_number())) {
                                        tv_num.setText(s + "");
                                    } else {
                                        Toast.makeText(mActivity, "数量已超过库存", Toast.LENGTH_SHORT).show();
                                    }
                                } else {
                                    Toast.makeText(mActivity, "请先选择完产品", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });
                        //减号
                        tv_reduce.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Integer.valueOf(tv_num.getText().toString()) == 1) {
                                    ToastMaker.showShort("亲，我是有底线的~");
                                    return;
                                }

                                if (productBean != null) {
                                    int s = Integer.valueOf(tv_num.getText().toString()) - 1;
                                    tv_num.setText(s + "");
                                } else {
                                    Toast.makeText(mActivity, "请先选择完产品", Toast.LENGTH_SHORT).show();
                                }


                            }
                        });


                        //确定
                        add_shops.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                if (productBean != null) {
                                    addShopCarClickListener.onBtnClickListener(moveDataBean.getInfo().getGoods_id(), getProduct_id, tv_num.getText().toString().trim(), productBean.getAttr_name(), mark);
                                } else {
                                    Toast.makeText(mActivity, "请先选择完产品", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });

                    }
                })
                .backgroundColorRes(R.color.dialog_bg)
                .gravity(Gravity.BOTTOM)
                .contentAnim(new AnyLayer.IAnim() {
                    @Override
                    public Animator inAnim(View target) {
                        return AnimHelper.createBottomAlphaInAnim(target);
                    }

                    @Override
                    public Animator outAnim(View target) {
                        return AnimHelper.createBottomAlphaOutAnim(target);
                    }
                });
        mAnyLayer.show();


    }

    public static void dismiss() {
        mAnyLayer.dismiss();
    }


    public interface AddShopCarClickListener {
        void onBtnClickListener(String goods_id, String product_id, String num, String getAttr_name, String mmake);
    }


}
