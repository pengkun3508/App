package com.jealook.www.surface.mvp.view;

import com.dm.lib.core.mvp.MvpView;
import com.jealook.www.http.model.AlreadyCouponListBean;
import com.jealook.www.http.model.CouponListBean;
import com.jealook.www.http.model.NotCouponListBean;
import com.jealook.www.http.model.VersionBean;
import com.jealook.www.surface.bean.ConfirmOrderBean;

import java.util.List;

/**
 * @Description:
 * @Time:2020/5/8$
 * @Author:pk$
 */
public interface CouponView extends MvpView {
    void getAppUpdateSuccess(int code, VersionBean version);

    void getAppUpdateFail(int code, String msg);

    void getCouponListSuccess(int code, List<NotCouponListBean> data);

    void getCouponListFail(int code, String msg);

    void getCollectCouponsSuccess(int code, Object data);

    void getCollectCouponsFail(int code, String msg);

    void getConfirmOrderSuccess(int code, ConfirmOrderBean data);

    void getConfirmOrderFail(int code, String msg);

    void getCouponList1Success(int code, List<AlreadyCouponListBean> data);

    void getCouponList1Fail(int code, String msg);
}
