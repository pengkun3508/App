package com.jealook.www.surface.mvp.model;

import android.util.Log;

import com.jealook.www.http.BaseRequest;
import com.jealook.www.http.ProjectApi;
import com.jealook.www.http.RequestBackListener;
import com.jealook.www.http.ResponseBean;
import com.jealook.www.http.model.AddressListBean;
import com.jealook.www.http.model.AllOrderListBean;
import com.jealook.www.http.model.AlreadyCouponListBean;
import com.jealook.www.http.model.BrandListBean;
import com.jealook.www.http.model.CollectionListBean;
import com.jealook.www.http.model.CommodityListBean;
import com.jealook.www.http.model.HomeDataBean;
import com.jealook.www.http.model.LimitedBean;
import com.jealook.www.http.model.MoveDataBean;
import com.jealook.www.http.model.NotCouponListBean;
import com.jealook.www.http.model.OrderDetailsBean;
import com.jealook.www.http.model.ShopCartListBean;
import com.jealook.www.http.model.SiginOrderBean;
import com.jealook.www.http.model.SignBean;
import com.jealook.www.surface.bean.ALiPayBean;
import com.jealook.www.surface.bean.BrowseListBean;
import com.jealook.www.surface.bean.ClassifyBean;
import com.jealook.www.surface.bean.ClassifyTypeBean;
import com.jealook.www.surface.bean.ConfirmOrderBean;
import com.jealook.www.surface.bean.EvaluateListBean;
import com.jealook.www.surface.bean.MemberBean;
import com.jealook.www.surface.bean.ModifyTypeBean;
import com.jealook.www.surface.bean.OrderLogisticsBean;
import com.jealook.www.surface.bean.PersonalInformationBean;
import com.jealook.www.surface.bean.ProductDetailsBean;
import com.jealook.www.surface.bean.PublishComment;
import com.jealook.www.surface.bean.RealNameDetailsBean;
import com.jealook.www.surface.bean.RealNameListBean;
import com.jealook.www.surface.bean.SearchListBean;
import com.jealook.www.surface.bean.SearchListListBean;
import com.jealook.www.surface.bean.TypeGoodsBean;
import com.jealook.www.surface.bean.UpdateImgBean;
import com.jealook.www.surface.bean.UserInfo;
import com.jealook.www.surface.bean.WeCatPayBean;
import com.jealook.www.surface.mvp.model.bean.AddressDetailsBean;
import com.jealook.www.utils.UserInfoBean;

import java.io.File;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * 描述：
 *
 * @author Cuizhen
 * @date 2018/9/4
 */
public class MainRequest extends BaseRequest {

    /**
     * 获取系统时间
     */
    public static Disposable time(final RequestBackListener<SignBean> listener) {
        return request(ProjectApi.api().getSign(), listener);
    }

//    /**
//     * 下载更新版本
//     *
//     * @param listener
//     * @return
//     */
//    public static Disposable getAppUpdate(final RequestBackListener<SignBean> listener) {
//        return requestWithSign(new RequestCallback<SignBean>() {
//            @Override
//            public Observable<ResponseBean<SignBean>> request(boolean isAppForceUpdate) {
//                return ProjectApi.api().getSign();
//            }
//        }, listener);
//    }

    /**
     * 下载更新版本
     *
     * @param listener
     * @return
     */
    public static Disposable getAppUpdate(final RequestBackListener<SignBean> listener) {
        return request(ProjectApi.api().getSign(), listener);
    }

    /**
     * 获取首页数据
     * 这是没有参数的请求
     *
     * @param listener
     * @return
     */
    public static Disposable getHomeindex(final RequestBackListener<HomeDataBean> listener) {
        return requestWithSign(new RequestCallback<HomeDataBean>() {
            @Override
            public Observable<ResponseBean<HomeDataBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getHomeData();
            }
        }, listener);
    }

    /**
     * 获取搜索列表数据
     *
     * @param listener
     * @return
     */
    public static Disposable getSearchData(final RequestBackListener<SearchListBean> listener) {
        return requestWithSign(new RequestCallback<SearchListBean>() {
            @Override
            public Observable<ResponseBean<SearchListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getSearchData();
            }
        }, listener);
    }


    /**
     * 获取商品详情数据
     *
     * @param listener
     * @return
     */
    public static Disposable getMoveindex(String goods_id, String search_attr, final RequestBackListener<MoveDataBean> listener) {
        return requestWithSign(new RequestCallback<MoveDataBean>() {
            @Override
            public Observable<ResponseBean<MoveDataBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getMoveData(goods_id, search_attr);
            }
        }, listener);
    }

    /**
     * 获取限时列表数据
     *
     * @param listener
     * @return
     */
    public static Disposable getLimitedindex(int page, int limite, final RequestBackListener<LimitedBean> listener) {
        return requestWithSign(new RequestCallback<LimitedBean>() {
            @Override
            public Observable<ResponseBean<LimitedBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getLimitedData(page, limite);
            }
        }, listener);
    }

    /**
     * 获取分类筛选的数据
     *
     * @param listener
     * @return
     */
    public static Disposable getClassifyindex(String goods_name, int page, int limit, int type, String sort_key, String sort_value, String str, final RequestBackListener<ClassifyBean> listener) {
        return requestWithSign(new RequestCallback<ClassifyBean>() {
            @Override
            public Observable<ResponseBean<ClassifyBean>> request(boolean isAppForceUpdate) {
                Log.e("getClassifyindex", "==获取分类筛选的数据==" + str);
                return ProjectApi.api().getClassifyData(goods_name, page, limit, type, sort_key, sort_value, str);
            }
        }, listener);
    }

    /**
     * 获取筛选项
     *
     * @param listener
     * @return
     */
    public static Disposable getTypeList(final RequestBackListener<List<ClassifyTypeBean>> listener) {
        return requestWithSign(new RequestCallback<List<ClassifyTypeBean>>() {
            @Override
            public Observable<ResponseBean<List<ClassifyTypeBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getTypeList();
            }
        }, listener);
    }

    /**
     * 获取地址列表数据
     *
     * @param listener
     * @return
     */
    public static Disposable getAddressindex(final RequestBackListener<List<AddressListBean>> listener) {
        return requestWithSign(new RequestCallback<List<AddressListBean>>() {
            @Override
            public Observable<ResponseBean<List<AddressListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getAddressData();
            }
        }, listener);
    }

    /**
     * 获取详细地址数据
     *
     * @param listener
     * @return
     */
    public static Disposable getAddressDetails(String getAddress_id, final RequestBackListener<AddressDetailsBean> listener) {
        return requestWithSign(new RequestCallback<AddressDetailsBean>() {
            @Override
            public Observable<ResponseBean<AddressDetailsBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getAddressDetails(getAddress_id);
            }
        }, listener);
    }


    /**
     * 编辑地址
     *
     * @return
     */
    public static Disposable getEditressindex(String pId, String cId, String dId, String name, String phone, String address, String getIs_default,
                                              String getAddress_id, final RequestBackListener<List<AddressListBean>> listener) {
        return requestWithSign(new RequestCallback<List<AddressListBean>>() {
            @Override
            public Observable<ResponseBean<List<AddressListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getEditressindex(pId, cId, dId, name, phone, address, getIs_default, getAddress_id);
            }
        }, listener);
    }

    /**
     * 编辑地址
     *
     * @return
     */
    public static Disposable getEditressindex_1(String getIs_default, String getAddress_id, final RequestBackListener<List<AddressListBean>> listener) {
        return requestWithSign(new RequestCallback<List<AddressListBean>>() {
            @Override
            public Observable<ResponseBean<List<AddressListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getEditressindex_1(getIs_default, getAddress_id);
            }
        }, listener);
    }

    /**
     * 新增地址
     *
     * @return
     */
    public static Disposable getAddAddressindex(String pId, String cId, String dId, String name, String phone, String address, String getIs_default,
                                                final RequestBackListener<List<AddressListBean>> listener) {
        return requestWithSign(new RequestCallback<List<AddressListBean>>() {
            @Override
            public Observable<ResponseBean<List<AddressListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getAddAddressindex(pId, cId, dId, name, phone, address, getIs_default);
            }
        }, listener);
    }

    /**
     * 删除地址
     *
     * @return
     */
    public static Disposable getDeleteAddressindex(String address_id,
                                                   final RequestBackListener<List<AddressListBean>> listener) {
        return requestWithSign(new RequestCallback<List<AddressListBean>>() {
            @Override
            public Observable<ResponseBean<List<AddressListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getDeleteAddressindex(address_id);
            }
        }, listener);
    }


    /**
     * 意见反馈
     *
     * @return
     */
    public static Disposable postFeedBack(String str,String imgUrl, final RequestBackListener<Object> listener) {
        return requestWithSign(new RequestCallback<Object>() {
            @Override
            public Observable<ResponseBean<Object>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().postFeedBack(str,imgUrl);
            }
        }, listener);
    }


    /**
     * 收藏商品
     *
     * @return
     */
    public static Disposable getMoveCollectionShop(String goods_id, String mark,
                                                   final RequestBackListener<Object> listener) {
        return requestWithSign(new RequestCallback<Object>() {
            @Override
            public Observable<ResponseBean<Object>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getMoveCollectionShop(goods_id, mark);
            }
        }, listener);
    }


    /**
     * 添加购物车
     *
     * @return
     */
    public static Disposable getAddShopCar(String goods_id, String product_id, String num,
                                           final RequestBackListener<Object> listener) {
        return requestWithSign(new RequestCallback<Object>() {
            @Override
            public Observable<ResponseBean<Object>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getAddShopCar(goods_id, product_id, num);
            }
        }, listener);
    }

    /**
     * 购物车列表
     *
     * @return
     */
    public static Disposable getShopListData(int type, final RequestBackListener<ShopCartListBean> listener) {
        return requestWithSign(new RequestCallback<ShopCartListBean>() {
            @Override
            public Observable<ResponseBean<ShopCartListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getShopListData(type);
            }
        }, listener);
    }


    /**
     * 购物车加减数量
     *
     * @return
     */
    public static Disposable getAddAndReduce(int mark, String number, String getRec_id,
                                             final RequestBackListener<ShopCartListBean> listener) {
        return requestWithSign(new RequestCallback<ShopCartListBean>() {
            @Override
            public Observable<ResponseBean<ShopCartListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getAddAndReduce(mark, number, getRec_id);
            }
        }, listener);
    }

    /**
     * 删除购物车数据
     *
     * @return
     */
    public static Disposable getDeleteData(String getRec_id, String is_all,
                                           final RequestBackListener<ShopCartListBean> listener) {
        return requestWithSign(new RequestCallback<ShopCartListBean>() {
            @Override
            public Observable<ResponseBean<ShopCartListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getDeleteData(getRec_id, is_all);
            }
        }, listener);
    }

    /**
     * 修改商品规格
     *
     * @return
     */
    public static Disposable getModifyType(int mark, String getRec_id, String num, String product_id,
                                           final RequestBackListener<ModifyTypeBean> listener) {
        return requestWithSign(new RequestCallback<ModifyTypeBean>() {
            @Override
            public Observable<ResponseBean<ModifyTypeBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getModifyType(mark, getRec_id, num, product_id);
            }
        }, listener);
    }


    /**
     * 选择商品类型
     *
     * @return
     */
    public static Disposable getTypeShopData(String goods_id, final RequestBackListener<MoveDataBean> listener) {
        return requestWithSign(new RequestCallback<MoveDataBean>() {
            @Override
            public Observable<ResponseBean<MoveDataBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getTypeShopData(goods_id);
            }
        }, listener);
    }

    /**
     * 全选改变状态
     *
     * @return
     */
    public static Disposable getSelectShopping(int mark, String rec_id, int is_check, int is_all,
                                               final RequestBackListener<ShopCartListBean> listener) {
        return requestWithSign(new RequestCallback<ShopCartListBean>() {
            @Override
            public Observable<ResponseBean<ShopCartListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getSelectShopping(mark, rec_id, is_check, is_all);
            }
        }, listener);
    }


    /**
     * 确认订单
     *
     * @return
     */
    public static Disposable getConfirmOrderData(String recId, String goods_id, String product_id, String num,
                                                 final RequestBackListener<ConfirmOrderBean> listener) {
        return requestWithSign(new RequestCallback<ConfirmOrderBean>() {
            @Override
            public Observable<ResponseBean<ConfirmOrderBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getConfirmOrderData(recId, goods_id, product_id, num);
            }
        }, listener);
    }

    /**
     * 使用优惠券后
     *
     * @return
     */
    public static Disposable getConfirmOrderData1(String recId, String goods_id, String product_id, String num, String type_id,
                                                  final RequestBackListener<ConfirmOrderBean> listener) {
        return requestWithSign(new RequestCallback<ConfirmOrderBean>() {
            @Override
            public Observable<ResponseBean<ConfirmOrderBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getConfirmOrderData1(recId, goods_id, product_id, num, type_id);
            }
        }, listener);
    }

    /**
     * 提交订单--微信支付
     *
     * @return
     */
    public static Disposable postSubmitOrder(String recIds, String goods_ids, String product_ids, String nums, String real_ids,
                                             String address_ids, String types, String confirmMessages, String order_ids, String bonus_id,
                                             final RequestBackListener<WeCatPayBean> listener) {
        return requestWithSign(new RequestCallback<WeCatPayBean>() {
            @Override
            public Observable<ResponseBean<WeCatPayBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().postSubmitOrder(recIds, goods_ids, product_ids, nums, real_ids, address_ids, types, confirmMessages, order_ids, bonus_id);
            }
        }, listener);
    }

    /**
     * 提交订单--支付宝支付
     *
     * @return
     */
    public static Disposable postALiSubmitOrder(String recIds, String goods_ids, String product_ids, String nums, String real_ids,
                                                String address_ids, String types, String confirmMessages, String order_ids, String bonus_id,
                                                final RequestBackListener<ALiPayBean> listener) {
        return requestWithSign(new RequestCallback<ALiPayBean>() {
            @Override
            public Observable<ResponseBean<ALiPayBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().postALiSubmitOrder(recIds, goods_ids, product_ids, nums, real_ids, address_ids, types, confirmMessages, order_ids, bonus_id);
            }
        }, listener);
    }


    /**
     * 优惠券未领取列表
     *
     * @return
     */
    public static Disposable getCouponListData(String recIds, String goods_ids, String product_ids, String nums, final RequestBackListener<List<NotCouponListBean>> listener) {
        return requestWithSign(new RequestCallback<List<NotCouponListBean>>() {
            @Override
            public Observable<ResponseBean<List<NotCouponListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getCouponListData(recIds, goods_ids, product_ids, nums);
            }
        }, listener);
    }

    /**
     * 优惠券已领取列表
     *
     * @return
     */
    public static Disposable getCouponListData1(String recIds, String goods_ids, String product_ids, String nums, final RequestBackListener<List<AlreadyCouponListBean>> listener) {
        return requestWithSign(new RequestCallback<List<AlreadyCouponListBean>>() {
            @Override
            public Observable<ResponseBean<List<AlreadyCouponListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getCouponListData1(recIds, goods_ids, product_ids, nums);
            }
        }, listener);
    }

    /**
     * 领取优惠券
     *
     * @return
     */
    public static Disposable getCollectCoupons(String type_id, final RequestBackListener<Object> listener) {
        return requestWithSign(new RequestCallback<Object>() {
            @Override
            public Observable<ResponseBean<Object>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getCollectCoupons(type_id);
            }
        }, listener);
    }


    /**
     * 订单列表
     *
     * @return
     */
    public static Disposable getOrderListData(int page, int limit, int type, final RequestBackListener<AllOrderListBean> listener) {
        return requestWithSign(new RequestCallback<AllOrderListBean>() {
            @Override
            public Observable<ResponseBean<AllOrderListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getOrderListData(page, limit, type);
            }
        }, listener);
    }

    /**
     * 取消订单
     *
     * @return
     */
    public static Disposable getCelearOrderData(String order_id, String type, final RequestBackListener<AllOrderListBean> listener) {
        return requestWithSign(new RequestCallback<AllOrderListBean>() {
            @Override
            public Observable<ResponseBean<AllOrderListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getCelearOrderData(order_id, type);
            }
        }, listener);
    }

    /**
     * 签收订单
     *
     * @return
     */
    public static Disposable getSignInOrderData(String order_id, final RequestBackListener<SiginOrderBean> listener) {
        return requestWithSign(new RequestCallback<SiginOrderBean>() {
            @Override
            public Observable<ResponseBean<SiginOrderBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getSignInOrderData(order_id);
            }
        }, listener);
    }


    /**
     * 订单详情
     *
     * @return
     */
    public static Disposable getOederDetailsData(String getOrder_id, final RequestBackListener<OrderDetailsBean> listener) {
        return requestWithSign(new RequestCallback<OrderDetailsBean>() {
            @Override
            public Observable<ResponseBean<OrderDetailsBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getOederDetailsData(getOrder_id);
            }
        }, listener);
    }

    /**
     * 评论页面数据
     *
     * @param listener
     * @return
     */
    public static Disposable getPublicComment(String goods_id, String search_attr, final RequestBackListener<PublishComment> listener) {
        return requestWithSign(new RequestCallback<PublishComment>() {
            @Override
            public Observable<ResponseBean<PublishComment>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getPublicComment(goods_id, search_attr);
            }
        }, listener);
    }

    /**
     * 历史足迹
     *
     * @return
     */
    public static Disposable getBrowseListData(int page, int limit, final RequestBackListener<BrowseListBean> listener) {
        return requestWithSign(new RequestCallback<BrowseListBean>() {
            @Override
            public Observable<ResponseBean<BrowseListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getBrowseListData(page, limit);
            }
        }, listener);
    }

    /**
     * 收藏列表
     *
     * @return
     */
    public static Disposable getCollectionListData(int page, int limit, final RequestBackListener<CollectionListBean> listener) {
        return requestWithSign(new RequestCallback<CollectionListBean>() {
            @Override
            public Observable<ResponseBean<CollectionListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getCollectionListData(page, limit);
            }
        }, listener);
    }

    /**
     * 品牌列表
     *
     * @return
     */
    public static Disposable getBrandList(final RequestBackListener<List<BrandListBean>> listener) {
        return requestWithSign(new RequestCallback<List<BrandListBean>>() {
            @Override
            public Observable<ResponseBean<List<BrandListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getBrandList();
            }
        }, listener);
    }


    /**
     * 品牌列表--商品列表
     *
     * @return
     */
    public static Disposable getCommodityList(int page, int limit, String getBrand_id, final RequestBackListener<CommodityListBean> listener) {
        return requestWithSign(new RequestCallback<CommodityListBean>() {
            @Override
            public Observable<ResponseBean<CommodityListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getCommodityList(page, limit, getBrand_id);
            }
        }, listener);
    }

    /**
     * 搜索页面--搜索商品列表
     *
     * @return
     */
    public static Disposable getSearchListData(int page, int limit, String keyword, final RequestBackListener<SearchListListBean> listener) {
        return requestWithSign(new RequestCallback<SearchListListBean>() {
            @Override
            public Observable<ResponseBean<SearchListListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getSearchListData(page, limit, keyword);
            }
        }, listener);
    }


    /**
     * 获取验证码
     *
     * @return
     */
    public static Disposable getVerificationCode(String mobile, final RequestBackListener<Object> listener) {
        return requestWithSign(new RequestCallback<Object>() {
            @Override
            public Observable<ResponseBean<Object>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getVerificationCode(mobile);
            }
        }, listener);
    }


    /**
     * 获取验证码
     *
     * @return
     */
    public static Disposable getCheckCode(String mobile, String code, final RequestBackListener<UserInfoBean> listener) {
        return requestWithSign(new RequestCallback<UserInfoBean>() {
            @Override
            public Observable<ResponseBean<UserInfoBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getCheckCode(mobile, code);
            }
        }, listener);
    }


    /**
     * 验证验证码
     *
     * @return
     */
    public static Disposable getVerifyPhoneNumber(String mobile, String code, final RequestBackListener<Object> listener) {
        return requestWithSign(new RequestCallback<Object>() {
            @Override
            public Observable<ResponseBean<Object>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getVerifyPhoneNumber(mobile, code);
            }
        }, listener);
    }

    /**
     * 修改手机号
     *
     * @return
     */
    public static Disposable getModifyPhoneNumber(String mobile, String code, final RequestBackListener<UserInfoBean> listener) {
        return requestWithSign(new RequestCallback<UserInfoBean>() {
            @Override
            public Observable<ResponseBean<UserInfoBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getModifyPhoneNumber(mobile, code);
            }
        }, listener);
    }


    /**
     * 微信登录
     *
     * @return
     */
    public static Disposable getWechatLogin(String openId, String nickName, String headUrl, final RequestBackListener<UserInfoBean> listener) {
        return requestWithSign(new RequestCallback<UserInfoBean>() {
            @Override
            public Observable<ResponseBean<UserInfoBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getWechatLogin(openId, nickName, headUrl);
            }
        }, listener);
    }

    /**
     * 获取物流信息
     *
     * @return
     */
    public static Disposable getOrderLogistics(String order_id, final RequestBackListener<OrderLogisticsBean> listener) {
        return requestWithSign(new RequestCallback<OrderLogisticsBean>() {
            @Override
            public Observable<ResponseBean<OrderLogisticsBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getOrderLogistics(order_id);
            }
        }, listener);
    }


    /**
     * 获取实名认证列表
     *
     * @return
     */
    public static Disposable getRealNameListData(final RequestBackListener<List<RealNameListBean>> listener) {
        return requestWithSign(new RequestCallback<List<RealNameListBean>>() {
            @Override
            public Observable<ResponseBean<List<RealNameListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getRealNameListData();
            }
        }, listener);
    }


    /**
     * 编辑实名认证为默认
     *
     * @return
     */
    public static Disposable getEditRealName(String id, String is_default, final RequestBackListener<List<RealNameListBean>> listener) {
        return requestWithSign(new RequestCallback<List<RealNameListBean>>() {
            @Override
            public Observable<ResponseBean<List<RealNameListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getEditRealName(id, is_default);
            }
        }, listener);
    }

    /**
     * 删除实名认证
     *
     * @return
     */
    public static Disposable getDeletRealName(String id, final RequestBackListener<List<RealNameListBean>> listener) {
        return requestWithSign(new RequestCallback<List<RealNameListBean>>() {
            @Override
            public Observable<ResponseBean<List<RealNameListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getDeletRealName(id);
            }
        }, listener);
    }

    /**
     * 下载实名认证为详情
     *
     * @return
     */
    public static Disposable getRealNameDetails(String id, final RequestBackListener<RealNameDetailsBean> listener) {
        return requestWithSign(new RequestCallback<RealNameDetailsBean>() {
            @Override
            public Observable<ResponseBean<RealNameDetailsBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getRealNameDetails(id);
            }
        }, listener);
    }

    /**
     * 新增实名
     *
     * @return
     */
    public static Disposable getAddRealName(String name, String idcard, String is_default, final RequestBackListener<List<RealNameListBean>> listener) {
        return requestWithSign(new RequestCallback<List<RealNameListBean>>() {
            @Override
            public Observable<ResponseBean<List<RealNameListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getAddRealName(name, idcard, is_default);
            }
        }, listener);
    }

    /**
     * 修改实名
     *
     * @return
     */
    public static Disposable getRealNameEdit(String name, String idcard, String getIs_default, String getId, final RequestBackListener<List<RealNameListBean>> listener) {
        return requestWithSign(new RequestCallback<List<RealNameListBean>>() {
            @Override
            public Observable<ResponseBean<List<RealNameListBean>>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getRealNameEdit(name, idcard, getIs_default, getId);
            }
        }, listener);
    }

    /**
     * 获取个人信息以及订单数量
     *
     * @return
     */
    public static Disposable getPersonalInformation(final RequestBackListener<PersonalInformationBean> listener) {
        return requestWithSign(new RequestCallback<PersonalInformationBean>() {
            @Override
            public Observable<ResponseBean<PersonalInformationBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getPersonalInformation();
            }
        }, listener);
    }


    /**
     * 获取个人信息
     *
     * @return
     */
    public static Disposable getUserInfoData(final RequestBackListener<UserInfo> listener) {
        return requestWithSign(new RequestCallback<UserInfo>() {
            @Override
            public Observable<ResponseBean<UserInfo>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getUserInfoData();
            }
        }, listener);
    }


    /**
     * 获取个人信息
     *
     * @return
     */
    public static Disposable getEvaluateList(int page, int limit, String goods_id, final RequestBackListener<EvaluateListBean> listener) {
        return requestWithSign(new RequestCallback<EvaluateListBean>() {
            @Override
            public Observable<ResponseBean<EvaluateListBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getEvaluateList(page, limit, goods_id);
            }
        }, listener);
    }

    /**
     * 获取个人信息
     *
     * @return
     */
    public static Disposable getTypeGoods(int page, int limit, String iD, final RequestBackListener<TypeGoodsBean> listener) {
        return requestWithSign(new RequestCallback<TypeGoodsBean>() {
            @Override
            public Observable<ResponseBean<TypeGoodsBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getTypeGoods(page, limit, iD);
            }
        }, listener);
    }


    /**
     * 获取个人信息
     *
     * @return
     */
    public static Disposable getMobileLogin(String token, final RequestBackListener<UserInfoBean> listener) {
        return requestWithSign(new RequestCallback<UserInfoBean>() {
            @Override
            public Observable<ResponseBean<UserInfoBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getMobileLogin(token);
            }
        }, listener);
    }

    /**
     * 获取个人信息
     *
     * @return
     */
    public static Disposable getProductDetailsData(String id, final RequestBackListener<ProductDetailsBean> listener) {
        return requestWithSign(new RequestCallback<ProductDetailsBean>() {
            @Override
            public Observable<ResponseBean<ProductDetailsBean>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().getProductDetailsData(id);
            }
        }, listener);
    }


    /**
     * 1004--发表评价-上传图片
     */
    public static Disposable postUploadPhotos(final File imgFiles, final RequestBackListener<UpdateImgBean> listener) {
        return requestWithSign(new RequestCallback<UpdateImgBean>() {
            @Override
            public Observable<ResponseBean<UpdateImgBean>> request(boolean isAppForceUpdate) {
                MultipartBody.Part asda = filesToMultipartBodyParts(imgFiles, "img");
                Log.e("postUploadPhotos", "==asda==" + asda);
                return ProjectApi.api().postUploadPhotos(asda);
            }
        }, listener);

    }


    /**
     * 1004--发表评论
     */
    public static Disposable multigraph(final String imgUrl, String order_id, String rec_id, String trim, String total_score, String describe_score, String logistics_score, String server_score, String is_show
            , final RequestBackListener<Object> listener) {
        return requestWithSign(new RequestCallback<Object>() {
            @Override
            public Observable<ResponseBean<Object>> request(boolean isAppForceUpdate) {

                return ProjectApi.api().multigraph(imgUrl, order_id, rec_id, trim, total_score, describe_score, logistics_score, server_score, is_show);
            }
        }, listener);
    }


    /**
     * 1004--会员详情
     */
    public static Disposable getMemberDetailData(final RequestBackListener<MemberBean> listener) {
        return requestWithSign(new RequestCallback<MemberBean>() {
            @Override
            public Observable<ResponseBean<MemberBean>> request(boolean isAppForceUpdate) {

                return ProjectApi.api().getMemberDetailData();
            }
        }, listener);
    }

    /**
     * 1004--购买会员--微信
     */
    public static Disposable postPayMember(String type, String memberId, final RequestBackListener<WeCatPayBean> listener) {
        return requestWithSign(new RequestCallback<WeCatPayBean>() {
            @Override
            public Observable<ResponseBean<WeCatPayBean>> request(boolean isAppForceUpdate) {

                return ProjectApi.api().postPayMember(type, memberId);
            }
        }, listener);
    }

    /**
     * 1004--购买会员--支付宝
     */
    public static Disposable postPayMember_2(String type, String memberId, final RequestBackListener<ALiPayBean> listener) {
        return requestWithSign(new RequestCallback<ALiPayBean>() {
            @Override
            public Observable<ResponseBean<ALiPayBean>> request(boolean isAppForceUpdate) {

                return ProjectApi.api().postPayMember_2(type, memberId);
            }
        }, listener);
    }


    /**
     * 1004--修改个人信息
     */
    public static Disposable postPersonalInformation(String imgUrl, String nicheng, String sex, final RequestBackListener<UserInfo> listener) {
        return requestWithSign(new RequestCallback<UserInfo>() {
            @Override
            public Observable<ResponseBean<UserInfo>> request(boolean isAppForceUpdate) {
                return ProjectApi.api().postPersonalInformation(imgUrl, nicheng, sex);


            }
        }, listener);

    }


    private static MultipartBody.Part filesToMultipartBodyParts(File files, String key) {

        RequestBody requestBody = RequestBody.create(MediaType.parse("image/png"), files);
        MultipartBody.Part part = MultipartBody.Part.createFormData(key, files.getName(), requestBody);

//        List<MultipartBody.Part> parts = new ArrayList<>(files.size());
//        for (File file : files) {
//            RequestBody requestBody = RequestBody.create(MediaType.parse("image/png"), file);
//            MultipartBody.Part part = MultipartBody.Part.createFormData(key, file.getName(), requestBody);
//            parts.add(part);
//        }
        return part;
    }


}
