package com.jealook.www.surface.mvp.presenter;

import com.dm.lib.core.mvp.MvpPresenter;
import com.jealook.www.surface.mvp.view.MyFragmentView;
import com.jealook.www.surface.mvp.view.OnlineCustomerServiceView;

public class OnlineCustomerServicePresenter extends MvpPresenter<OnlineCustomerServiceView> {
}
