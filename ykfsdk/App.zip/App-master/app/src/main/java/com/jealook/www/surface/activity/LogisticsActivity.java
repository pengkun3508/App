package com.jealook.www.surface.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dm.lib.core.adapter.rv.OnClickListener;
import com.dm.lib.utils.StatusBarUtils;
import com.jealook.www.R;
import com.jealook.www.base.BaseActivity;
import com.jealook.www.surface.adapter.LogisticsAdapter;
import com.jealook.www.surface.bean.OrderLogisticsBean;
import com.jealook.www.surface.mvp.presenter.LogisticsPresenter;
import com.jealook.www.surface.mvp.view.LogisticsView;
import com.jealook.www.widgat.actionbar.ActionBarSimple;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @Description:查看物流
 * @Time:2020/4/14 9:42
 * @Author:pk
 */
public class LogisticsActivity extends BaseActivity<LogisticsPresenter> implements LogisticsView {
    @BindView(R.id.action_bar)
    ActionBarSimple actionBar;
    @BindView(R.id.order_logistics_sn)
    TextView orderLogisticsSn;
    @BindView(R.id.order_logistics_time)
    TextView orderLogisticsTime;
    @BindView(R.id.order_logistics_recycler)
    RecyclerView orderLogisticsRecycler;

    private LogisticsAdapter adapter;
    private static String order_id;

    public static void startSelf(Context context, String order_ids) {
        Intent intent = new Intent(context, LogisticsActivity.class);
        context.startActivity(intent);
        order_id = order_ids;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_logistics;
    }

    @Override
    protected LogisticsPresenter initPresenter() {
        return new LogisticsPresenter();
    }

    @Override
    protected void initView() {
        StatusBarUtils.setStatusBarMode(getActivity(), true);
        orderLogisticsRecycler.setLayoutManager(new LinearLayoutManager(getContext()));
        orderLogisticsRecycler.setNestedScrollingEnabled(false);
        orderLogisticsRecycler.setHasFixedSize(true);
        adapter = new LogisticsAdapter();
        orderLogisticsRecycler.setAdapter(adapter);
        adapter.addOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view, int position) {
//                ProductDetailsActivity.startSelf(getContext());
            }
        });

    }

    @Override
    protected void loadData() {
        presenter.getOrderLogistics(order_id);

    }

    public List<String> getData() {
        List<String> strings = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            strings.add("1");
        }
        return strings;
    }


    /**
     * 获取物流信息成功
     *
     * @param code
     * @param data
     */
    @Override
    public void getOrderLogisticsSuccess(int code, OrderLogisticsBean data) {
        orderLogisticsSn.setText(data.getOrder_sn());
        orderLogisticsTime.setText(data.getCreate_time());
        adapter.setData(data.getTraces());


    }

    /**
     * 获取物流信息失败
     *
     * @param code
     * @param
     */
    @Override
    public void getOrderLogisticsFail(int code, String msg) {


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }
}
